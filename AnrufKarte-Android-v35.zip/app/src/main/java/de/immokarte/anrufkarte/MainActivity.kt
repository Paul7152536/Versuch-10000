package de.immokarte.anrufkarte

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.BackupManager
import de.immokarte.anrufkarte.data.CsvImporter
import de.immokarte.anrufkarte.data.CustomerEntity
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.PropertyEntity
import de.immokarte.anrufkarte.databinding.ActivityMainBinding
import de.immokarte.anrufkarte.reminder.AlarmScheduler
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allCustomers: List<CustomerWithProperties> = emptyList()
    private var unlocked = false

    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { checkPermissionState() }

    private val pickCsv =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { importCsv(it) } }

    private val pickBackupToImport =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { importBackup(it) } }

    private val pickBackupLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? -> uri?.let { exportBackup(it) } }

    private val pickCsvExportLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? -> uri?.let { exportCsv(it) } }

    private val editCustomer =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) loadCustomers()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.visibility = android.view.View.INVISIBLE

        authenticateThenInit()
    }

    private fun authenticateThenInit() {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            // Kein PIN/Muster/Biometrie auf dem Gerät eingerichtet — App-Sperre übersprungen.
            unlocked = true
            initApp()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true
                initApp()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (!unlocked) finish()
            }
        })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Anruf-Karte entsperren")
            .setSubtitle("Schützt die Kundendaten")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(promptInfo)
    }

    private fun initApp() {
        binding.root.visibility = android.view.View.VISIBLE

        binding.tvPermissionStatus.setOnClickListener { requestNeededPermissions() }
        binding.btnContacts.setOnClickListener {
            startActivity(Intent(this, ContactsActivity::class.java))
        }
        binding.btnWeekPlan.setOnClickListener {
            startActivity(Intent(this, WeekPlanActivity::class.java))
        }
        binding.btnAddCustomer.setOnClickListener { editCustomer.launch(Intent(this, CustomerEditActivity::class.java)) }
        binding.btnSettings.setOnClickListener { showSettingsDialog() }

        updateGreeting()
        checkPermissionState()
        loadCustomers()
        AlarmScheduler.scheduleDaily(this)
        checkBackupReminder()
        handleShortcutIntent(intent)
        ensureSimServiceRunningIfConfigured()
    }

    /** Kurze Tageszeit-Begrüßung über dem Titel — kostet nichts, macht das
     *  Dashboard etwas persönlicher. */
    private fun updateGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        binding.tvGreeting.text = when {
            hour < 11 -> "Guten Morgen"
            hour < 18 -> "Guten Tag"
            else -> "Guten Abend"
        }
    }

    private fun ensureSimServiceRunningIfConfigured() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        if (prefs.getInt("overlay_sim_subscription_id", -1) >= 0) {
            val serviceIntent = Intent(this, de.immokarte.anrufkarte.call.SimCallStateService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (unlocked) handleShortcutIntent(intent)
    }

    private fun handleShortcutIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data?.let { importSharedFile(it) }
            Intent.ACTION_SEND -> (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { importSharedFile(it) }
        }
        when (intent?.getStringExtra("shortcut_action")) {
            "new_contact" -> editCustomer.launch(Intent(this, CustomerEditActivity::class.java))
            "import_csv" -> pickCsv.launch(arrayOf("text/comma-separated-values", "text/csv", "text/*"))
        }
    }

    private fun importSharedFile(uri: Uri) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val count = runCatching {
                withContext(Dispatchers.IO) { BackupManager.import(this@MainActivity, uri, dao) }
            }.getOrNull()
            if (count == null || count == 0) {
                Toast.makeText(this@MainActivity, "Datei konnte nicht als Kontakt gelesen werden.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@MainActivity, "$count Kontakt${if (count == 1) "" else "e"} übernommen.", Toast.LENGTH_LONG).show()
                loadCustomers()
            }
        }
    }

    private fun checkBackupReminder() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val lastBackup = prefs.getLong("last_backup_at", 0L)
        val sevenDays = 7 * 24 * 60 * 60 * 1000L
        if (System.currentTimeMillis() - lastBackup > sevenDays) {
            binding.tvBackupReminder.visibility = android.view.View.VISIBLE
            binding.tvBackupReminder.text = if (lastBackup == 0L)
                "💾 Noch kein Backup gemacht — jetzt sichern?" else
                "💾 Letztes Backup ist über eine Woche her — jetzt sichern?"
        } else {
            binding.tvBackupReminder.visibility = android.view.View.GONE
        }
        binding.tvBackupReminder.setOnClickListener { pickBackupLocation.launch("anruf-karte-backup.json") }
    }

    override fun onResume() {
        super.onResume()
        if (unlocked) checkPermissionState()
        if (unlocked) loadCustomers()
        de.immokarte.anrufkarte.call.IncomingCallSignal.setListener { info -> updateIncomingCallBanner(info) }
    }

    override fun onPause() {
        super.onPause()
        de.immokarte.anrufkarte.call.IncomingCallSignal.setListener(null)
    }

    /** Reserveweg zum System-Overlay: Ist die App gerade offen, kann Samsungs
     *  eigene Anruf-Oberfläche das Overlay-Fenster komplett verdecken —
     *  deshalb hier zusätzlich als Banner direkt in der App anzeigen. */
    private fun updateIncomingCallBanner(info: de.immokarte.anrufkarte.call.IncomingCallSignal.Info?) {
        if (info == null) {
            binding.incomingCallBanner.visibility = android.view.View.GONE
            return
        }
        binding.tvIncomingCallName.text = info.name
        binding.tvIncomingCallPhone.text = info.phone
        binding.incomingCallBanner.visibility = android.view.View.VISIBLE
        binding.incomingCallBanner.setOnClickListener {
            if (info.isUnknown) {
                editCustomer.launch(
                    Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_PREFILL_PHONE, info.phone)
                )
            }
        }
        binding.btnIncomingCallDismiss.setOnClickListener { binding.incomingCallBanner.visibility = android.view.View.GONE }
    }

    private fun showOverlayDesignPickerDialog() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val options = listOf(
            "classic" to "Klassisch (Icon-Leiste unten)",
            "glass" to "Dark Glass (dunkel, transparent)",
            "gradient" to "Bold Gradient Card (bunt, Verlauf)"
        )
        val current = prefs.getString("overlay_design", "classic")
        val currentIndex = options.indexOfFirst { it.first == current }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Overlay-Design wählen")
            .setSingleChoiceItems(options.map { it.second }.toTypedArray(), currentIndex) { dialog, which ->
                prefs.edit().putString("overlay_design", options[which].first).apply()
                Toast.makeText(this, "Wird beim nächsten Anruf angezeigt.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showThemePickerDialog() {
        val options = de.immokarte.anrufkarte.data.ThemeManager.options
        val current = de.immokarte.anrufkarte.data.ThemeManager.current(this)
        val currentIndex = options.indexOfFirst { it.first == current }
        AlertDialog.Builder(this)
            .setTitle("Design wählen")
            .setSingleChoiceItems(options.map { it.second }.toTypedArray(), currentIndex) { dialog, which ->
                de.immokarte.anrufkarte.data.ThemeManager.setTheme(this, options[which].first)
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showSimPickerDialog() {
        val sims = de.immokarte.anrufkarte.data.MultiSimHelper.listSims(this)
        if (sims.size < 2) {
            AlertDialog.Builder(this)
                .setTitle("Overlay nur für bestimmte SIM")
                .setMessage(
                    "Es wurde nur eine SIM/Rufnummer auf diesem Gerät erkannt — diese Einstellung " +
                        "ist nur bei mehreren SIMs (z. B. privat + dienstlich) relevant.\n\n" +
                        "Falls du zwei SIMs eingelegt hast und trotzdem nur eine siehst: Beide SIMs " +
                        "müssen unter Android-Einstellungen → Verbindungen → SIM-Karten-Manager aktiv sein."
                )
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val currentSubId = prefs.getInt("overlay_sim_subscription_id", -1)
        val labels = listOf("Alle Anrufe zeigen (aus)") + sims.map {
            val nick = prefs.getString("sim_nickname_${it.subscriptionId}", "").orEmpty()
            if (nick.isNotBlank()) "$nick (${it.label})" else it.label
        }
        val currentIndex = sims.indexOfFirst { it.subscriptionId == currentSubId }
        AlertDialog.Builder(this)
            .setTitle("Overlay nur zeigen bei Anruf auf:")
            .setSingleChoiceItems(labels.toTypedArray(), if (currentIndex >= 0) currentIndex + 1 else 0) { dialog, which ->
                if (which == 0) {
                    prefs.edit().putInt("overlay_sim_subscription_id", -1).putInt("overlay_sim_slot_index", -1).apply()
                    stopService(Intent(this, de.immokarte.anrufkarte.call.SimCallStateService::class.java))
                    Toast.makeText(this, "Overlay erscheint wieder bei allen Anrufen.", Toast.LENGTH_SHORT).show()
                } else {
                    val sim = sims[which - 1]
                    prefs.edit()
                        .putInt("overlay_sim_subscription_id", sim.subscriptionId)
                        .putInt("overlay_sim_slot_index", sim.slotIndex)
                        .apply()
                    val serviceIntent = Intent(this, de.immokarte.anrufkarte.call.SimCallStateService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                    dialog.dismiss()
                    promptSimNickname(prefs, sim.subscriptionId, sim.label)
                    return@setSingleChoiceItems
                }
                dialog.dismiss()
            }
            .setNegativeButton("Schließen", null)
            .show()
    }

    /** Fragt optional einen eigenen, klareren Namen für die gewählte SIM ab
     *  (z. B. "Geschäftlich") — praktisch, wenn beide SIMs beim selben
     *  Anbieter sind und deshalb sonst gleich heißen würden. Wird pro
     *  Subscription-ID gespeichert, damit eine Umbenennung nicht versehentlich
     *  auch die andere SIM mit umbenennt. */
    private fun promptSimNickname(prefs: android.content.SharedPreferences, subscriptionId: Int, rawLabel: String) {
        val key = "sim_nickname_$subscriptionId"
        val input = android.widget.EditText(this).apply {
            hint = "z. B. Geschäftlich"
            setText(prefs.getString(key, ""))
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }
        AlertDialog.Builder(this)
            .setTitle("Eigenen Namen für diese SIM vergeben? (optional)")
            .setMessage("Erkannt als: $rawLabel")
            .setView(input)
            .setPositiveButton("Speichern") { _, _ ->
                prefs.edit().putString(key, input.text.toString().trim()).apply()
                Toast.makeText(this, "Overlay erscheint jetzt nur noch bei dieser SIM. Bitte kurz testen, ob es zuverlässig greift.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Ohne eigenen Namen", { _, _ ->
                prefs.edit().putString(key, "").apply()
                Toast.makeText(this, "Overlay erscheint jetzt nur noch bei: $rawLabel. Bitte kurz testen, ob es zuverlässig greift.", Toast.LENGTH_LONG).show()
            })
            .show()
    }

    private fun showSettingsDialog() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val scroll = android.widget.ScrollView(this)
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 10, 40, 10)
        }
        scroll.addView(container)

        fun sectionHeader(text: String) = TextView(this).apply {
            this.text = text; textSize = 11f; setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInkFaint))
            setPadding(0, 24, 0, 8); isAllCaps = true
        }

        // Daten sichern/wiederherstellen
        container.addView(sectionHeader("Daten"))
        val rowBackup = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        val btnBackupNow = android.widget.Button(this).apply {
            text = "Sichern"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
            setOnClickListener { pickBackupLocation.launch("anruf-karte-backup.json") }
        }
        val btnRestoreNow = android.widget.Button(this).apply {
            text = "Wiederherstellen"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { pickBackupToImport.launch(arrayOf("application/json", "text/*")) }
        }
        rowBackup.addView(btnBackupNow); rowBackup.addView(btnRestoreNow)
        container.addView(rowBackup)

        val rowCsv = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
        val btnCsvImport = android.widget.Button(this).apply {
            text = "CSV importieren"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
            setOnClickListener { pickCsv.launch(arrayOf("text/comma-separated-values", "text/csv", "text/*")) }
        }
        val btnCsvExport = android.widget.Button(this).apply {
            text = "CSV exportieren"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { pickCsvExportLocation.launch("anruf-karte-export.csv") }
        }
        rowCsv.addView(btnCsvImport); rowCsv.addView(btnCsvExport)
        container.addView(rowCsv)

        // WhatsApp-Vorlagen-Links
        container.addView(sectionHeader("WhatsApp-Vorlagen"))
        val label1 = TextView(this).apply { text = "Google-Bewertungslink"; textSize = 12f; setPadding(0, 10, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val input1 = android.widget.EditText(this).apply {
            setText(prefs.getString("google_review_link", ""))
            hint = "https://g.page/r/....../review"
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }
        val labelTrustpilot = TextView(this).apply { text = "Trustpilot-Bewertungslink"; textSize = 12f; setPadding(0, 16, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val inputTrustpilot = android.widget.EditText(this).apply {
            setText(prefs.getString("trustpilot_link", ""))
            hint = "https://www.trustpilot.com/evaluate/..."
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }
        val labelReferral = TextView(this).apply { text = "Betterhomes-Tippgeberprogramm-Link"; textSize = 12f; setPadding(0, 16, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val inputReferral = android.widget.EditText(this).apply {
            setText(prefs.getString("referral_link", ""))
            hint = "Link zu deinem Tippgeberprogramm"
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }
        val label2 = TextView(this).apply { text = "Katalog-/Objektübersicht-Link"; textSize = 12f; setPadding(0, 16, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val input2 = android.widget.EditText(this).apply {
            setText(prefs.getString("catalog_link", ""))
            hint = "z. B. dein Betterhomes-Profil"
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }

        // Kalender
        container.addView(sectionHeader("Kalender"))
        val label3 = TextView(this).apply { text = "Kalender für Termine (bei mehreren Konten)"; textSize = 12f; setPadding(0, 10, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val spinnerCalendar = android.widget.Spinner(this)
        val calendars = de.immokarte.anrufkarte.data.CalendarSync.listCalendars(this)
        val calendarLabels = listOf("Automatisch (Standard-Kalender)") + calendars.map { "${it.displayName} (${it.accountName})" }
        spinnerCalendar.adapter = de.immokarte.anrufkarte.data.ThemeManager.themedArrayAdapter(this, calendarLabels)
        val currentCalendarId = prefs.getLong("selected_calendar_id", -1L)
        val preselect = calendars.indexOfFirst { it.id == currentCalendarId }
        spinnerCalendar.setSelection(if (preselect >= 0) preselect + 1 else 0)

        val label4 = TextView(this).apply { text = "Terminfarbe (Hex, leer = Kalender-Standardfarbe)"; textSize = 12f; setPadding(0, 16, 0, 4); setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)) }
        val input4 = android.widget.EditText(this).apply {
            setText(prefs.getString("calendar_event_color", ""))
            hint = "z. B. #A9823D"
            de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@MainActivity, this)
        }

        listOf(label1, input1, labelTrustpilot, inputTrustpilot, labelReferral, inputReferral, label2, input2, label3, spinnerCalendar, label4, input4).forEach { container.addView(it) }

        // Weitere Funktionen
        // Erinnerungen einzeln an-/abschaltbar
        container.addView(sectionHeader("Erinnerungen"))
        de.immokarte.anrufkarte.data.ReminderPrefs.Kind.values().forEach { kind ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 6, 0, 6)
            }
            val switch = android.widget.Switch(this).apply {
                isChecked = de.immokarte.anrufkarte.data.ReminderPrefs.isEnabled(this@MainActivity, kind)
                setOnCheckedChangeListener { _, checked -> de.immokarte.anrufkarte.data.ReminderPrefs.setEnabled(this@MainActivity, kind, checked) }
            }
            val label = TextView(this).apply {
                text = kind.label
                textSize = 12.5f
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk))
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(label)
            row.addView(switch)
            container.addView(row)
        }

        container.addView(sectionHeader("Weiteres"))
        val btnTheme = android.widget.Button(this).apply {
            text = "🎨 Design: ${de.immokarte.anrufkarte.data.ThemeManager.options.first { it.first == de.immokarte.anrufkarte.data.ThemeManager.current(this@MainActivity) }.second}"
            isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
            setOnClickListener { showThemePickerDialog() }
        }
        val btnOverlayDesign = android.widget.Button(this).apply {
            text = "🃏 Overlay-Design (Anrufkarte)"
            isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
            setOnClickListener { showOverlayDesignPickerDialog() }
        }
        val btnSim = android.widget.Button(this).apply {
            text = "📱 Overlay nur für bestimmte SIM"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
            setOnClickListener { showSimPickerDialog() }
        }
        val btnBulk = android.widget.Button(this).apply {
            text = "🎉 Sammelgruß"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
            setOnClickListener { startActivity(Intent(this@MainActivity, BulkGreetingActivity::class.java)) }
        }
        val btnVertretungBtn = android.widget.Button(this).apply {
            text = "🧑‍🤝‍🧑 Vertretung"; isAllCaps = false
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)
            setOnClickListener { showVertretungDialog() }
        }
        listOf(btnTheme, btnOverlayDesign, btnSim, btnBulk, btnVertretungBtn).forEach { container.addView(it) }

        AlertDialog.Builder(this)
            .setTitle("Einstellungen")
            .setView(scroll)
            .setPositiveButton("Speichern") { _, _ ->
                val chosenCalendarId = if (spinnerCalendar.selectedItemPosition == 0) -1L else calendars[spinnerCalendar.selectedItemPosition - 1].id
                val colorText = input4.text.toString().trim()
                val validColor = colorText.isBlank() || runCatching { android.graphics.Color.parseColor(colorText) }.isSuccess
                if (!validColor) {
                    Toast.makeText(this, "Ungültige Farbe — bitte Format #RRGGBB verwenden.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                prefs.edit()
                    .putString("google_review_link", input1.text.toString().trim())
                    .putString("trustpilot_link", inputTrustpilot.text.toString().trim())
                    .putString("referral_link", inputReferral.text.toString().trim())
                    .putString("catalog_link", input2.text.toString().trim())
                    .putLong("selected_calendar_id", chosenCalendarId)
                    .putString("calendar_event_color", colorText)
                    .apply()
                Toast.makeText(this, "Gespeichert.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun toggleImportant(id: Long, important: Boolean) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().setImportant(id, important) }
            loadCustomers()
        }
    }

    private fun showVertretungDialog() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val activeUntil = prefs.getLong("vertretung_until", 0L)
        val importantCount = allCustomers.count { it.customer.important }

        val message = if (activeUntil > System.currentTimeMillis()) {
            "Vertretung ist aktiv bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(activeUntil))}.\n\n" +
                "$importantCount wichtige Kontakte können als Paket geteilt werden."
        } else {
            "Bündelt alle als „wichtig“ markierten Kontakte ($importantCount) in einer Datei und öffnet den Teilen-Dialog — " +
                "ein Kollege mit derselben App kann sie direkt übernehmen. Zusätzlich kannst du ein Enddatum als Erinnerung setzen."
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("🧑‍🤝‍🧑 Vertretung")
            .setMessage(message)
            .setPositiveButton("Paket teilen") { _, _ -> shareImportantContacts() }
            .setNeutralButton("Bis wann?") { _, _ -> pickVertretungDate() }
            .setNegativeButton("Schließen", null)

        if (activeUntil > 0) {
            builder.setNeutralButton("Beenden") { _, _ ->
                prefs.edit().putLong("vertretung_until", 0L).apply()
                updateVertretungBanner()
            }
        }
        builder.show()
    }

    private fun pickVertretungDate() {
        val cal = Calendar.getInstance()
        android.app.DatePickerDialog(this, { _, year, month, day ->
            val picked = Calendar.getInstance().apply { set(year, month, day, 23, 59, 59) }.timeInMillis
            getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).edit().putLong("vertretung_until", picked).apply()
            updateVertretungBanner()
            Toast.makeText(this, "Vertretung bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(picked))} vorgemerkt.", Toast.LENGTH_LONG).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun shareImportantContacts() {
        val important = allCustomers.filter { it.customer.important }
        if (important.isEmpty()) {
            Toast.makeText(this, "Keine als „wichtig“ markierten Kontakte vorhanden.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val file = java.io.File(cacheDir, "vertretung-wichtige-kontakte.json")
            withContext(Dispatchers.IO) { BackupManager.export(this@MainActivity, Uri.fromFile(file), important) }
            val contentUri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Vertretung: ${important.size} wichtige Kontakte")
                putExtra(Intent.EXTRA_TEXT, "Wichtige Kontakte für die Vertretung — mit derselben App über \"Wiederherstellen\" importierbar.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Vertretungs-Paket teilen"))
        }
    }

    private fun updateVertretungBanner() {
        val until = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).getLong("vertretung_until", 0L)
        if (until > System.currentTimeMillis()) {
            binding.tvVertretung.visibility = android.view.View.VISIBLE
            binding.tvVertretung.text = "🧑‍🤝‍🧑 Vertretung aktiv bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(until))} — Kontakte danach wieder selbst übernehmen"
        } else {
            binding.tvVertretung.visibility = android.view.View.GONE
        }
    }

    private fun updateUndoBanner() {
        val desc = de.immokarte.anrufkarte.data.UndoManager.peek()
        if (desc == null) {
            binding.tvUndo.visibility = android.view.View.GONE
            return
        }
        binding.tvUndo.visibility = android.view.View.VISIBLE
        binding.tvUndo.text = "↩️ $desc — antippen zum Rückgängigmachen"
        binding.tvUndo.setOnClickListener {
            lifecycleScope.launch {
                de.immokarte.anrufkarte.data.UndoManager.consume()
                binding.tvUndo.visibility = android.view.View.GONE
                loadCustomers()
            }
        }
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf(android.Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) perms += android.Manifest.permission.READ_CALL_LOG
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms += android.Manifest.permission.POST_NOTIFICATIONS
        perms += android.Manifest.permission.READ_CALENDAR
        perms += android.Manifest.permission.WRITE_CALENDAR
        requestPermissions.launch(perms.toTypedArray())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        // Wichtig auf Geräten mit aggressivem Akku-Management (z. B. Samsung One UI):
        // ohne diese Ausnahme kann das System den Hintergrunddienst zum Erkennen von
        // Anrufen nach einiger Zeit im Standby-Modus einfach beenden.
        requestIgnoreBatteryOptimizations()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            }
        }
    }

    private fun checkPermissionState() {
        val phoneOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val callLogOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.P || ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
        val overlayOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        val calendarOk = de.immokarte.anrufkarte.data.CalendarSync.hasPermission(this)
        val batteryOk = (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)

        // Ist alles eingerichtet, wird der Hinweis komplett ausgeblendet — eine
        // Bestätigung für einen unauffälligen Normalzustand braucht keinen
        // dauerhaften Platz auf der Startseite. Nur bei einem echten
        // Handlungsbedarf (etwas fehlt) erscheint die Karte wieder.
        if (phoneOk && callLogOk && overlayOk && calendarOk && batteryOk) {
            binding.tvPermissionStatus.visibility = View.GONE
        } else {
            binding.tvPermissionStatus.visibility = View.VISIBLE
            binding.tvPermissionStatus.text = when {
                !callLogOk -> "⚠ Anrufliste-Berechtigung fehlt — Rufnummer kann nicht gelesen werden"
                !calendarOk -> "⚠ Kalender-Berechtigung fehlt — Wiedervorlagen werden nicht synchronisiert"
                !batteryOk -> "⚠ Akku-Optimierung aktiv — Erkennung kann im Standby aussetzen (auf „Berechtigungen einrichten“ tippen)"
                else -> "⚠ Berechtigungen fehlen: Telefonstatus & „Über anderen Apps anzeigen“"
            }
        }
    }

    private fun importCsv(uri: Uri) {
        lifecycleScope.launch {
            val rows = withContext(Dispatchers.IO) { CsvImporter.parse(this@MainActivity, uri) }
            if (rows.isEmpty()) {
                Toast.makeText(this@MainActivity, "Keine gültigen Zeilen gefunden.", Toast.LENGTH_LONG).show()
                return@launch
            }
            val dao = AppDatabase.getInstance(applicationContext).customerDao()

            // Dubletten-Check: gleiche Nummer mehrfach in der Datei, oder Nummer existiert
            // schon mit einem anderen Namen.
            val conflicts = mutableListOf<String>()
            val seenInFile = mutableMapOf<String, String>()
            withContext(Dispatchers.IO) {
                rows.forEach { row ->
                    val normalized = PhoneUtils.normalize(row.telefon)
                    seenInFile[normalized]?.let { existingName ->
                        if (existingName != row.name) conflicts += "${row.telefon}: „$existingName“ vs. „${row.name}“ (in der Datei)"
                    }
                    seenInFile[normalized] = row.name
                    val existingId = dao.findIdByPhone(normalized)
                    if (existingId != null) {
                        val existing = dao.getByIdWithProperties(existingId)
                        if (existing != null && existing.customer.name != row.name) {
                            conflicts += "${row.telefon}: bereits gespeichert als „${existing.customer.name}“, neu: „${row.name}“"
                        }
                    }
                }
            }

            if (conflicts.isNotEmpty()) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Mögliche Dubletten gefunden")
                    .setMessage(conflicts.joinToString("\n\n") + "\n\nTrotzdem importieren? Bestehende Namen werden dabei überschrieben.")
                    .setPositiveButton("Trotzdem importieren") { _, _ -> doImportCsv(rows) }
                    .setNegativeButton("Abbrechen", null)
                    .show()
            } else {
                doImportCsv(rows)
            }
        }
    }

    private fun doImportCsv(rows: List<CsvImporter.Row>) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            withContext(Dispatchers.IO) {
                rows.forEach { row ->
                    val normalized = PhoneUtils.normalize(row.telefon)
                    val existingId = dao.findIdByPhone(normalized)
                    // Bei bereits vorhandener Nummer den bestehenden Datensatz per
                    // copy() ergänzen statt komplett zu ersetzen — sonst gingen
                    // Status, Tags, Termine, Notiz-Verlauf usw. unbemerkt verloren.
                    val existing = existingId?.let { dao.getByIdWithProperties(it)?.customer }
                    val entity = existing?.copy(name = row.name, phone = row.telefon, phoneNormalized = normalized, notes = row.notizen)
                        ?: CustomerEntity(name = row.name, phone = row.telefon, phoneNormalized = normalized, notes = row.notizen)
                    val customerId = dao.insertCustomer(entity)
                    dao.deletePropertiesForCustomer(customerId)
                    dao.insertProperties(listOf(PropertyEntity(customerId = customerId, typ = row.typ, adresse = row.adresse, ort = row.ort, preis = row.preis)))
                }
            }
            Toast.makeText(this@MainActivity, "${rows.size} Kontakte importiert.", Toast.LENGTH_LONG).show()
            loadCustomers()
        }
    }

    private fun exportBackup(uri: Uri) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { BackupManager.export(this@MainActivity, uri, allCustomers) }
            getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).edit()
                .putLong("last_backup_at", System.currentTimeMillis()).apply()
            binding.tvBackupReminder.visibility = android.view.View.GONE
            Toast.makeText(this@MainActivity, "Backup gesichert.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportCsv(uri: Uri) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { de.immokarte.anrufkarte.data.CsvExporter.export(this@MainActivity, uri, allCustomers) }
            Toast.makeText(this@MainActivity, "${allCustomers.size} Kontakte als CSV exportiert.", Toast.LENGTH_LONG).show()
        }
    }

    private fun importBackup(uri: Uri) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val count = withContext(Dispatchers.IO) { BackupManager.import(this@MainActivity, uri, dao) }
            Toast.makeText(this@MainActivity, "$count Kontakte wiederhergestellt.", Toast.LENGTH_LONG).show()
            loadCustomers()
        }
    }

    private fun loadCustomers() {
        lifecycleScope.launch {
            allCustomers = withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().getAllWithProperties() }
            updateBanners()
            updateDashboardCards()
            updateSuccessBanner()
            updateUndoBanner()
            updateVertretungBanner()
            FollowUpWidgetProvider.updateAll(applicationContext)
        }
    }

    /** Fällig-heute- und Besichtigung-heute-Banner — unabhängig von der
     *  (jetzt auf der Kontakte-Seite lebenden) Such-/Filterlogik. */
    private fun updateBanners() {
        val endOfToday = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
        val startOfToday = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis

        val due = allCustomers.count { it.customer.followUpAt != null && it.customer.followUpAt!! <= endOfToday }
        if (due > 0) {
            binding.tvDueBanner.visibility = android.view.View.VISIBLE
            binding.tvDueBanner.text = "🔔 $due Wiedervorlage${if (due == 1) "" else "n"} heute fällig"
        } else {
            binding.tvDueBanner.visibility = android.view.View.GONE
        }

        val todaysViewings = allCustomers.filter { it.customer.viewingAt != null && it.customer.viewingAt!! in startOfToday..endOfToday }
            .sortedBy { it.customer.viewingAt }
        if (todaysViewings.isNotEmpty()) {
            val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY)
            val summary = todaysViewings.joinToString(", ") { "${it.customer.name} (${timeFmt.format(java.util.Date(it.customer.viewingAt!!))})" }
            binding.tvViewingBanner.visibility = android.view.View.VISIBLE
            binding.tvViewingBanner.text = "🏠 Heute: $summary"
            binding.tvViewingBanner.setOnClickListener {
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, todaysViewings.first().customer.id))
            }
        } else {
            binding.tvViewingBanner.visibility = android.view.View.GONE
        }

        // Shootings, die MORGEN anstehen — Erinnerung, den Kunden heute
        // schon selbst nochmal zu benachrichtigen (ergänzt die Push-
        // Benachrichtigung von ShootingReminderScheduler).
        val startOfTomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val endOfTomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
        val tomorrowsShootings = allCustomers.filter { it.customer.shootingAt != null && it.customer.shootingAt!! in startOfTomorrow..endOfTomorrow }
            .sortedBy { it.customer.shootingAt }
        if (tomorrowsShootings.isNotEmpty()) {
            val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY)
            val summary = tomorrowsShootings.joinToString(", ") { "${it.customer.name} (${timeFmt.format(java.util.Date(it.customer.shootingAt!!))})" }
            binding.tvShootingReminderBanner.visibility = android.view.View.VISIBLE
            binding.tvShootingReminderBanner.text = "📸 Morgen Termin — heute noch erinnern: $summary"
            binding.tvShootingReminderBanner.setOnClickListener {
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, tomorrowsShootings.first().customer.id))
            }
        } else {
            binding.tvShootingReminderBanner.visibility = android.view.View.GONE
        }

        // Kontakte, die aktiv nach einem Objekt suchen (Suchort hinterlegt),
        // aber schon lange nichts mehr von uns gehört haben — eigene
        // Kategorie, unabhängig vom allgemeinen "lange nicht kontaktiert".
        val staleThreshold = System.currentTimeMillis() - 60L * 24 * 60 * 60 * 1000
        val staleSearchers = allCustomers.filter {
            it.customer.searchOrt.isNotBlank() &&
                it.customer.status !in de.immokarte.anrufkarte.data.StatusInfo.closedStatuses &&
                (it.customer.lastContactAt == null || it.customer.lastContactAt!! < staleThreshold)
        }
        if (staleSearchers.isNotEmpty()) {
            binding.tvStaleSearchBanner.visibility = android.view.View.VISIBLE
            binding.tvStaleSearchBanner.text = "🔍 Lange nichts Neues für: ${staleSearchers.joinToString(", ") { it.customer.name }} (suchen seit über 60 Tagen ohne Update)"
            binding.tvStaleSearchBanner.setOnClickListener {
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, staleSearchers.first().customer.id))
            }
        } else {
            binding.tvStaleSearchBanner.visibility = android.view.View.GONE
        }
    }

    /** Füllt die "Heute"-Kachel, die zwei Kennzahlen-Kacheln und die kurze
     *  "Wichtig & zuletzt bearbeitet"-Liste unten auf dem Dashboard. */
    /** Rein motivierender Hinweis, wenn diese Woche schon etwas abgeschlossen
     *  wurde — kein funktionaler Nutzen, nur ein kleiner Erfolgs-Moment beim Öffnen. */
    private fun updateSuccessBanner() {
        val sevenDaysAgo = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
        val closedThisWeek = allCustomers.count {
            it.customer.status == "abschluss" && it.customer.abschlussAt != null && it.customer.abschlussAt!! >= sevenDaysAgo
        }
        if (closedThisWeek > 0) {
            binding.tvSuccessBanner.visibility = android.view.View.VISIBLE
            binding.tvSuccessBanner.text = "🎉 Diese Woche schon $closedThisWeek Abschluss${if (closedThisWeek == 1) "" else "e"}!"
        } else {
            binding.tvSuccessBanner.visibility = android.view.View.GONE
        }
    }

    private fun updateDashboardCards() {
        val endOfToday = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
        val startOfToday = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        fun today(millis: Long?) = millis != null && millis in startOfToday..endOfToday

        val followUpsToday = allCustomers.count { it.customer.followUpAt != null && it.customer.followUpAt!! <= endOfToday }
        val shootingsToday = allCustomers.count { today(it.customer.shootingAt) }
        val viewingsToday = allCustomers.count { today(it.customer.viewingAt) }
        val contractsToday = allCustomers.count { today(it.customer.contractDateAt) }
        val anniversariesToday = allCustomers.count { today(it.customer.anniversaryAt) }
        val totalToday = followUpsToday + shootingsToday + viewingsToday + contractsToday + anniversariesToday

        binding.tvTodayCount.text = "$totalToday"
        val parts = mutableListOf<String>()
        if (followUpsToday > 0) parts += "$followUpsToday Wiedervorlage${if (followUpsToday == 1) "" else "n"}"
        if (shootingsToday > 0) parts += "$shootingsToday Termin${if (shootingsToday == 1) "" else "e"}"
        if (viewingsToday > 0) parts += "$viewingsToday Besichtigung${if (viewingsToday == 1) "" else "en"}"
        if (contractsToday > 0) parts += "$contractsToday Notar-/Mietvertragstermin${if (contractsToday == 1) "" else "e"}"
        if (anniversariesToday > 0) parts += "$anniversariesToday Jahrestag${if (anniversariesToday == 1) "" else "e"}"
        binding.tvTodaySummary.text = if (parts.isEmpty()) "Nichts anstehend — guter Tag!" else parts.joinToString(" · ")
        binding.cardToday.setOnClickListener { startActivity(Intent(this, WeekPlanActivity::class.java)) }

        binding.tvStatTotal.text = "${allCustomers.size}"
        val monthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val closedThisMonth = allCustomers.count { it.customer.status == "abschluss" && it.customer.abschlussAt != null && it.customer.abschlussAt!! >= monthStart }
        binding.tvStatClosed.text = "$closedThisMonth"

        // Bis zu 5 Kontakte: erst wichtig markierte, dann zuletzt kontaktierte —
        // ersetzt die volle Liste, die jetzt auf der Kontakte-Seite lebt.
        // Höchstens 3 wichtige, damit bei vielen "wichtig" markierten Kontakten
        // (nach Monaten realistisch) immer noch Platz für zuletzt Bearbeitete bleibt.
        val importantPart = allCustomers.filter { it.customer.important }.take(3)
        val recentPart = allCustomers.sortedByDescending { it.customer.lastContactAt ?: 0L }
        val shortlist = (importantPart + recentPart)
            .distinctBy { it.customer.id }
            .take(5)

        binding.dashboardListContainer.removeAllViews()
        if (shortlist.isEmpty()) {
            binding.dashboardListContainer.addView(TextView(this).apply {
                text = "Noch keine Kontakte — leg unten den ersten an."
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInkFaint))
                textSize = 12.5f
            })
        }
        shortlist.forEach { cwp ->
            val c = cwp.customer
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundResource(R.drawable.bg_card)
                val params = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = 8
                layoutParams = params
                setOnClickListener {
                    editCustomer.launch(Intent(this@MainActivity, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, c.id))
                }
            }
            val star = TextView(this).apply {
                text = if (c.important) "★" else "☆"
                textSize = 15f
                setTextColor(0xFFA9823D.toInt())
                setPadding(0, 0, 12, 0)
                setOnClickListener { toggleImportant(c.id, !c.important) }
            }
            val textCol = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(this).apply { text = c.name; textSize = 13.5f; setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInk)); setTypeface(typeface, android.graphics.Typeface.BOLD) })
            textCol.addView(TextView(this).apply {
                val dotColor = de.immokarte.anrufkarte.data.StatusInfo.color(c.status)
                val full = "●  ${de.immokarte.anrufkarte.data.StatusInfo.label(c.status)}"
                val spannable = android.text.SpannableString(full)
                spannable.setSpan(android.text.style.ForegroundColorSpan(dotColor), 0, 1, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                text = spannable
                textSize = 11f
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@MainActivity, R.attr.colorInkFaint))
            })
            row.addView(star)
            row.addView(textCol)
            binding.dashboardListContainer.addView(row)
        }
    }
}
