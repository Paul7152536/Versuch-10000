package de.immokarte.anrufkarte.data

data class NoteEntry(val timestamp: Long, val text: String)

/** Der Notiz-Verlauf wird bewusst ohne eigene Tabelle als einfacher Text
 *  im Feld `noteLog` gespeichert: eine Zeile pro Eintrag im Format
 *  "epochMillis::Text" (Zeilenumbrüche im Text werden escaped). */
object NoteLogUtils {
    private const val DELIM = "::"

    fun parse(raw: String): List<NoteEntry> =
        raw.split("\n").mapNotNull { line ->
            if (line.isBlank()) return@mapNotNull null
            val idx = line.indexOf(DELIM)
            if (idx < 0) return@mapNotNull null
            val ts = line.substring(0, idx).toLongOrNull() ?: return@mapNotNull null
            val text = line.substring(idx + DELIM.length).replace("\\n", "\n")
            NoteEntry(ts, text)
        }.sortedBy { it.timestamp }

    fun append(raw: String, entry: NoteEntry): String {
        val safeText = entry.text.replace("\n", "\\n")
        val line = "${entry.timestamp}$DELIM$safeText"
        return if (raw.isBlank()) line else "$raw\n$line"
    }
}
