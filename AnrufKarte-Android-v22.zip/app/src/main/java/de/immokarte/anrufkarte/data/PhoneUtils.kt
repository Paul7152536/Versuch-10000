package de.immokarte.anrufkarte.data

import android.app.AlertDialog
import android.content.Context

object PhoneUtils {
    /** Reduziert eine Telefonnummer auf Ziffern (+ führendes '+'), damit
     *  unterschiedliche Schreibweisen ("0151 234", "+49151234") zusammenfinden. */
    fun normalize(raw: String): String =
        raw.filter { it.isDigit() || it == '+' }

    /** Führt eine Aktion (Anrufen, WhatsApp, …) mit der Telefonnummer eines
     *  Kontakts aus. Gibt es eine zweite Nummer, fragt zuerst per Dialog nach,
     *  welche verwendet werden soll — sonst wird direkt die einzige Nummer genommen. */
    fun withChosenNumber(context: Context, primary: String, secondary: String, onChosen: (String) -> Unit) {
        if (secondary.isBlank()) {
            onChosen(primary)
            return
        }
        AlertDialog.Builder(context)
            .setTitle("Welche Nummer?")
            .setItems(arrayOf("📞 $primary", "📞 $secondary")) { _, which ->
                onChosen(if (which == 0) primary else secondary)
            }
            .show()
    }
}
