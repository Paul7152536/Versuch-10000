package de.immokarte.anrufkarte.data

/**
 * Einfaches, prozessweites Rückgängig für die zuletzt ausgeführte, potenziell
 * versehentliche Aktion (z. B. Kontakt gelöscht, verpasste Anrufe zurückgesetzt,
 * Wiedervorlage verschoben). Kein Verlauf über mehrere Schritte — nur die
 * jeweils letzte Aktion, überschreibt sich bei der nächsten. Nicht persistent
 * (geht beim App-Neustart verloren), das ist für den Zweck ausreichend.
 */
object UndoManager {

    private var description: String? = null
    private var action: (suspend () -> Unit)? = null

    fun set(description: String, action: suspend () -> Unit) {
        this.description = description
        this.action = action
    }

    fun peek(): String? = description

    suspend fun consume() {
        action?.invoke()
        clear()
    }

    fun clear() {
        description = null
        action = null
    }
}
