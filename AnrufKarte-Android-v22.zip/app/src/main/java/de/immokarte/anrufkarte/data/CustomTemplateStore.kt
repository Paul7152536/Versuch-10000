package de.immokarte.anrufkarte.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Eigene, speicherbare Text-Vorlagen unter einem selbst gewählten Namen —
 *  für WhatsApp-Nachrichten, nutzbar sowohl beim Sammelgruß als auch beim
 *  allgemeinen "Nachricht schreiben"-Fenster (z. B. Besichtigungs-
 *  Bestätigungen). Gespeichert als kleines JSON-Array in den
 *  SharedPreferences — kein Datenbank-Feld nötig. */
object CustomTemplateStore {

    data class Template(val name: String, val text: String)

    private const val PREFS = "anruf_karte_prefs"
    private const val KEY = "custom_message_templates"

    fun getAll(context: Context): List<Template> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Template(o.optString("name"), o.optString("text"))
        }
    }

    /** Legt eine neue Vorlage an oder überschreibt eine bestehende mit
     *  demselben Namen (so lässt sich eine Vorlage einfach aktualisieren). */
    fun save(context: Context, name: String, text: String) {
        val existing = getAll(context).filter { it.name != name }
        val updated = existing + Template(name, text)
        persist(context, updated)
    }

    fun delete(context: Context, name: String) {
        persist(context, getAll(context).filter { it.name != name })
    }

    private fun persist(context: Context, templates: List<Template>) {
        val arr = JSONArray()
        templates.forEach { t ->
            val o = JSONObject()
            o.put("name", t.name); o.put("text", t.text)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
