package de.immokarte.anrufkarte.data

import android.content.Context

/** Zentrale Ein/Aus-Schalter je Erinnerungsart — alle standardmäßig an.
 *  Einstellbar unter ⚙️ Einstellungen → "Erinnerungen". */
object ReminderPrefs {
    private const val PREFS = "anruf_karte_prefs"

    enum class Kind(val key: String, val label: String) {
        VIEWING("reminder_viewing_enabled", "Besichtigungs-Erinnerung (45 Min. vorher)"),
        SHOOTING("reminder_shooting_enabled", "Termin-Erinnerung (1 Tag vorher)"),
        CONTRACT("reminder_contract_enabled", "Notar/Mietvertrag-Erinnerung (1 Tag vorher)"),
        HOLIDAY("reminder_holiday_enabled", "Feiertags-/Sonntags-Warnung"),
        CONFLICT("reminder_conflict_enabled", "Terminkonflikt-Warnung"),
    }

    fun isEnabled(context: Context, kind: Kind): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(kind.key, true)

    fun setEnabled(context: Context, kind: Kind, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(kind.key, enabled).apply()
    }
}
