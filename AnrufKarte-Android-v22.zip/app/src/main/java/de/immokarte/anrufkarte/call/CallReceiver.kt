package de.immokarte.anrufkarte.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/**
 * Lauscht auf Änderungen des Telefonstatus. Bei "RINGING" wird die
 * eingehende Nummer gelesen und der OverlayService gestartet — außer eine
 * "Geschäfts-SIM" ist in den Einstellungen ausgewählt UND die Herkunfts-SIM
 * des Anrufs lässt sich zuverlässig bestimmen UND sie stimmt nicht überein.
 * Bei "IDLE" (Anruf beendet) wird die Karte wieder geschlossen — anhand von
 * "wurde OFFHOOK erreicht?" wird entschieden, ob es ein verpasster/
 * abgelehnter Anruf war, und bei einem angenommenen Anruf wird die
 * ungefähre Gesprächsdauer mitgegeben.
 *
 * Hinweis zur SIM-Erkennung: Android dokumentiert öffentlich keinen
 * einheitlichen Weg, um bei einem eingehenden Anruf zu bestimmen, welche
 * der eigenen SIM-Karten angerufen wurde (anders als "wer ruft an" — das
 * ist zuverlässig). Es wird versucht, mehrere bekannte, in der Praxis von
 * Android/Herstellern verwendete Zusatzfelder auszulesen. Lässt sich keines
 * davon auslesen, wird das Overlay sicherheitshalber trotzdem angezeigt
 * (lieber einmal zu viel als ein wichtiger Anruf verpasst).
 *
 * Hinweis: Ab Android 9 (API 28) benötigt EXTRA_INCOMING_NUMBER
 * zusätzlich die Berechtigung READ_CALL_LOG (neben READ_PHONE_STATE).
 */
class CallReceiver : BroadcastReceiver() {

    companion object {
        private var ringingNumber: String? = null
        private var wasAnswered: Boolean = false
        private var offHookAt: Long = 0L
        private const val PREFS = "anruf_karte_prefs"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                ringingNumber = number
                wasAnswered = false
                if (matchesConfiguredSim(context, intent)) {
                    val serviceIntent = Intent(context, OverlayService::class.java).apply {
                        action = OverlayService.ACTION_SHOW
                        putExtra(OverlayService.EXTRA_PHONE, number ?: "")
                        putExtra(OverlayService.EXTRA_ON_BUSINESS_SIM, isConfirmedBusinessSim(context, intent))
                    }
                    context.startForegroundService(serviceIntent)
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (!wasAnswered) offHookAt = System.currentTimeMillis()
                wasAnswered = true
                // Sobald der Anruf angenommen wurde, verschwindet die Karte sofort —
                // vorher blieb sie fälschlich über die gesamte Gesprächsdauer (auch
                // in anderen Apps) sichtbar, bis der Anruf komplett beendet war.
                val dismissIntent = Intent(context, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_DISMISS
                }
                context.startService(dismissIntent)
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val durationSec = if (wasAnswered && offHookAt > 0) ((System.currentTimeMillis() - offHookAt) / 1000).toInt() else 0
                val serviceIntent = Intent(context, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_HIDE
                    putExtra(OverlayService.EXTRA_PHONE, ringingNumber ?: "")
                    putExtra(OverlayService.EXTRA_ANSWERED, wasAnswered)
                    putExtra(OverlayService.EXTRA_DURATION_SEC, durationSec)
                }
                context.startService(serviceIntent)
                ringingNumber = null
                offHookAt = 0L
            }
        }
    }

    /** Primäre Quelle: der zuverlässige, pro-SIM lauschende SimCallStateService
     *  (siehe dort). Zusatzfelder aus dem Broadcast werden nur noch als
     *  Ergänzung mitgeprüft, falls sie auf manchen Geräten doch funktionieren. */
    private fun simCandidates(intent: Intent): List<Int> {
        val fromService = SimCallStateService.currentRingingSubId()
        val fromExtras = listOf(
            intent.getIntExtra("subscription", -1),
            intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1),
            intent.getIntExtra("slot", -1),
            intent.getIntExtra("simSlot", -1),
            intent.getIntExtra("slotId", -1),
            intent.getIntExtra("phone", -1),
        )
        return (listOf(fromService) + fromExtras).filter { it >= 0 }
    }

    /** Steuert, ob das Overlay überhaupt erscheint. Fail-open: Lässt sich die
     *  SIM nicht bestimmen, wird lieber trotzdem gezeigt. */
    private fun matchesConfiguredSim(context: Context, intent: Intent): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val chosenSubId = prefs.getInt("overlay_sim_subscription_id", -1)
        if (chosenSubId < 0) return true // Funktion nicht aktiviert -> wie bisher bei jedem Anruf zeigen
        val chosenSlot = prefs.getInt("overlay_sim_slot_index", -1)
        val candidates = simCandidates(intent)
        if (candidates.isEmpty()) return true // Keine Erkennung möglich -> sicherheitshalber zeigen
        return candidates.any { it == chosenSubId || it == chosenSlot }
    }

    /** Steuert, ob der "+ Kontakt anlegen"-Button bei unbekannten Anrufern
     *  angeboten wird. Fail-closed (Gegenteil von oben): Ist keine
     *  Geschäfts-SIM eingerichtet oder lässt sie sich nicht sicher bestimmen,
     *  wird der Button NICHT angeboten — sonst könnten aus Versehen private
     *  Anrufer ins Geschäfts-CRM eingeladen werden. */
    private fun isConfirmedBusinessSim(context: Context, intent: Intent): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val chosenSubId = prefs.getInt("overlay_sim_subscription_id", -1)
        if (chosenSubId < 0) return false
        val chosenSlot = prefs.getInt("overlay_sim_slot_index", -1)
        val candidates = simCandidates(intent)
        if (candidates.isEmpty()) return false
        return candidates.any { it == chosenSubId || it == chosenSlot }
    }
}
