package de.immokarte.anrufkarte.data

import androidx.room.Embedded
import androidx.room.Relation

data class CustomerWithProperties(
    @Embedded val customer: CustomerEntity,
    @Relation(parentColumn = "id", entityColumn = "customerId")
    val properties: List<PropertyEntity>
)

data class CustomerNameOnly(val id: Long, val name: String)
