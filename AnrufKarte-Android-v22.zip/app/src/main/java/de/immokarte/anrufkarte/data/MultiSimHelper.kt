package de.immokarte.anrufkarte.data

import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat

data class SimChoice(val subscriptionId: Int, val label: String, val slotIndex: Int)

/** Liest die auf dem Gerät aktiven SIM-Karten/eSIMs aus, damit der Nutzer bei
 *  Mehr-SIM-Geräten (z. B. privat + dienstlich) eine davon als "die, bei der
 *  das Overlay erscheinen soll" auswählen kann. */
object MultiSimHelper {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED

    fun listSims(context: Context): List<SimChoice> {
        if (!hasPermission(context)) return emptyList()
        return runCatching {
            val sm = context.getSystemService(SubscriptionManager::class.java) ?: return@runCatching emptyList()
            val list = sm.activeSubscriptionInfoList ?: return@runCatching emptyList()
            list.map { info ->
                val baseName = info.displayName?.toString()?.takeIf { it.isNotBlank() }
                    ?: info.carrierName?.toString()?.takeIf { it.isNotBlank() }
                    ?: "SIM"
                // Steckplatz immer mit anzeigen — bei gleichem Anbieter (z. B. zwei
                // Telekom-SIMs) wären sie sonst nicht auseinanderzuhalten.
                val label = "$baseName — Steckplatz ${info.simSlotIndex + 1}"
                SimChoice(subscriptionId = info.subscriptionId, label = label, slotIndex = info.simSlotIndex)
            }
        }.getOrDefault(emptyList())
    }
}
