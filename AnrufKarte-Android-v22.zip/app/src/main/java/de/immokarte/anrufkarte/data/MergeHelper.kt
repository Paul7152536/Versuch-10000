package de.immokarte.anrufkarte.data

/** Führt zwei Kunden-Einträge zusammen, die eigentlich dieselbe Person sind
 *  (z. B. einmal per CSV importiert, einmal manuell angelegt). "target"
 *  bleibt bestehen und wird um die Daten von "other" ergänzt; "other" wird
 *  danach gelöscht. Termine/Kalender-Einträge von "other" müssen VORHER
 *  vom Aufrufer bereinigt werden (braucht einen Context, siehe
 *  CustomerEditActivity). */
object MergeHelper {

    suspend fun merge(dao: CustomerDao, target: CustomerEntity, other: CustomerEntity): CustomerEntity {
        val mergedNoteLog = listOf(target.noteLog, other.noteLog).filter { it.isNotBlank() }.joinToString("\n")
        val mergedNotes = listOf(target.notes, other.notes).filter { it.isNotBlank() }.distinct().joinToString("\n---\n")
        val mergedTags = (target.tags.split(",") + other.tags.split(","))
            .map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString(", ")

        // Zweite Telefonnummer übernehmen, falls beim Ziel noch keine hinterlegt ist
        var phone2 = target.phone2
        var phone2Normalized = target.phone2Normalized
        if (phone2.isBlank() && other.phone.isNotBlank() && other.phone != target.phone) {
            phone2 = other.phone
            phone2Normalized = other.phoneNormalized
        } else if (phone2.isBlank() && other.phone2.isNotBlank()) {
            phone2 = other.phone2
            phone2Normalized = other.phone2Normalized
        }

        val merged = target.copy(
            noteLog = mergedNoteLog,
            notes = mergedNotes,
            tags = mergedTags,
            important = target.important || other.important,
            phone2 = phone2,
            phone2Normalized = phone2Normalized,
        )
        dao.insertCustomer(merged)
        dao.reassignProperties(other.id, target.id)
        dao.deleteCustomerById(other.id)
        return merged
    }
}
