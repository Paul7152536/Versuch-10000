package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import java.io.OutputStreamWriter

/** Schreibt eine CSV im selben Format, das CsvImporter einliest
 *  (Name,Telefon,Typ,Adresse,Ort,Preis,Notizen) — für Auswertungen
 *  außerhalb der App (Excel, Google Sheets) oder zum Weitergeben.
 *  Bei mehreren Objekten pro Kunde wird nur das erste exportiert
 *  (identisch zur Grenze, die auch der Import hat: eine Zeile = ein Objekt). */
object CsvExporter {

    fun export(context: Context, uri: Uri, customers: List<CustomerWithProperties>) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            val writer = OutputStreamWriter(out, Charsets.UTF_8)
            writer.write("Name,Telefon,Typ,Adresse,Ort,Preis,Notizen\n")
            customers.forEach { cwp ->
                val prop = cwp.properties.firstOrNull()
                val cells = listOf(
                    cwp.customer.name,
                    cwp.customer.phone,
                    prop?.typ.orEmpty(),
                    prop?.adresse.orEmpty(),
                    prop?.ort.orEmpty(),
                    prop?.preis.orEmpty(),
                    cwp.customer.notes
                )
                writer.write(cells.joinToString(",") { escape(it) })
                writer.write("\n")
            }
            writer.flush()
        }
    }

    /** Setzt Anführungszeichen um Felder mit Komma/Anführungszeichen/Zeilenumbruch,
     *  wie im CSV-Standard üblich. */
    private fun escape(value: String): String =
        if (value.contains(',') || value.contains('"') || value.contains('\n')) {
            "\"${value.replace("\"", "\"\"")}\""
        } else value
}
