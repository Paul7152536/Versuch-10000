package de.immokarte.anrufkarte.call

/**
 * Leichtgewichtiger In-Prozess-Signalweg, damit die gerade sichtbare
 * Activity (z. B. MainActivity) direkt informiert werden kann, wenn ein
 * Anruf klingelt oder endet — als Reserveweg zum System-Overlay.
 *
 * Hintergrund: Ist die Anruf-Karte-App selbst gerade offen, kann Samsungs
 * eigene (kompakte) Anruf-Oberfläche das System-Overlay-Fenster komplett
 * verdecken — das ist eine harte, nicht umgehbare Systembeschränkung.
 * Die passende Lösung dafür ist kein Overlay-Fenster, sondern eine Anzeige
 * INNERHALB der eigenen, ohnehin schon sichtbaren App.
 */
object IncomingCallSignal {
    data class Info(val name: String, val phone: String, val isUnknown: Boolean)

    private var listener: ((Info?) -> Unit)? = null

    fun setListener(l: ((Info?) -> Unit)?) {
        listener = l
    }

    fun notifyRinging(name: String, phone: String, isUnknown: Boolean) {
        listener?.invoke(Info(name, phone, isUnknown))
    }

    fun notifyEnded() {
        listener?.invoke(null)
    }
}
