package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

/** Feuert 1 Stunde nach einem verschobenen Rückruf und erinnert erneut. */
class CallbackReminderReceiver : BroadcastReceiver() {

    companion object { private const val CHANNEL_ID = "missed_call" }

    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra(SnoozeReceiver.EXTRA_NAME) ?: return
        val phone = intent.getStringExtra(SnoozeReceiver.EXTRA_PHONE) ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Verpasste Anrufe", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val callIntent = PendingIntent.getActivity(
            context, phone.hashCode(), Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("Rückruf fällig: $name")
            .setContentText(phone)
            .setSmallIcon(android.R.drawable.sym_call_missed)
            .setContentIntent(callIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.sym_action_call, "Anrufen", callIntent)
            .build()

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(phone.hashCode(), notification)
    }
}
