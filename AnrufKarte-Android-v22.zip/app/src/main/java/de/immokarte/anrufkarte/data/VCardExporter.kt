package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import java.io.OutputStreamWriter

/** Schreibt einen Kontakt im Standard-vCard-3.0-Format — öffnet sich mit
 *  jeder Kontakte-App (nicht nur unserer), lässt sich per WhatsApp/E-Mail/
 *  Bluetooth teilen wie ein normaler Handy-Kontakt. */
object VCardExporter {

    fun export(context: Context, uri: Uri, customer: CustomerEntity) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            val writer = OutputStreamWriter(out, Charsets.UTF_8)
            writer.write("BEGIN:VCARD\r\n")
            writer.write("VERSION:3.0\r\n")
            writer.write("FN:${escape(customer.name)}\r\n")
            if (customer.phone.isNotBlank()) writer.write("TEL;TYPE=CELL:${escape(customer.phone)}\r\n")
            if (customer.phone2.isNotBlank()) writer.write("TEL;TYPE=WORK:${escape(customer.phone2)}\r\n")
            if (customer.email.isNotBlank()) writer.write("EMAIL:${escape(customer.email)}\r\n")
            if (customer.notes.isNotBlank()) writer.write("NOTE:${escape(customer.notes)}\r\n")
            writer.write("END:VCARD\r\n")
            writer.flush()
        }
    }

    /** vCard-Sonderzeichen maskieren (Komma, Semikolon, Backslash, Zeilenumbrüche). */
    private fun escape(value: String): String =
        value.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")
}
