package de.immokarte.anrufkarte.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Plant/entfernt die Erinnerung "1 Tag vorher an Unterlagen für den
 *  Notar-/Mietvertragstermin denken" — analog zur Shooting-Erinnerung,
 *  feuert um 09:00 Uhr am Vortag. */
object ContractReminderScheduler {

    fun schedule(context: Context, customerId: Long, name: String, phone: String, contractDateAt: Long?) {
        cancel(context, customerId)
        if (contractDateAt == null) return
        if (!de.immokarte.anrufkarte.data.ReminderPrefs.isEnabled(context, de.immokarte.anrufkarte.data.ReminderPrefs.Kind.CONTRACT)) return

        val fireAt = Calendar.getInstance().apply {
            timeInMillis = contractDateAt
            add(Calendar.DAY_OF_YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        if (fireAt <= System.currentTimeMillis()) return

        val dateLabel = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date(contractDateAt))
        val timeLabel = SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(contractDateAt))
        val intent = Intent(context, ContractReminderReceiver::class.java).apply {
            putExtra(ContractReminderReceiver.EXTRA_CUSTOMER_ID, customerId)
            putExtra(ContractReminderReceiver.EXTRA_NAME, name)
            putExtra(ContractReminderReceiver.EXTRA_PHONE, phone)
            putExtra(ContractReminderReceiver.EXTRA_DATE_LABEL, dateLabel)
            putExtra(ContractReminderReceiver.EXTRA_TIME_LABEL, timeLabel)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching { alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pendingIntent) }
    }

    fun cancel(context: Context, customerId: Long) {
        val intent = Intent(context, ContractReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }

    private fun requestCode(customerId: Long): Int = (7_000_000 + customerId).toInt()
}
