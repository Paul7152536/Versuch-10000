package de.immokarte.anrufkarte.data

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Fasst mehrere Wiedervorlagen am selben Tag zu EINEM Kalender-Termin
 * zusammen ("🔔 Anrufliste 12.08.2026" mit allen Namen in der Beschreibung),
 * statt für jeden Kontakt einen eigenen Termin anzulegen — verhindert, dass
 * der Kalender bei mehreren Wiedervorlagen am gleichen Tag zumüllt.
 *
 * Die Zuordnung "Tag → Kalender-Termin-ID" wird in den SharedPreferences als
 * kleines JSON-Objekt gespeichert (kein Datenbank-Feld nötig/kein Reset).
 * resyncDay() wird nach jeder Änderung an einer Wiedervorlage aufgerufen und
 * baut die Terminbeschreibung für den betroffenen Tag komplett neu auf.
 */
object FollowUpDayCalendarSync {

    private const val PREFS = "anruf_karte_prefs"
    private const val KEY = "followup_day_events"

    private fun loadMap(context: Context): MutableMap<Long, Long> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}"
        val json = runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
        val map = mutableMapOf<Long, Long>()
        json.keys().forEach { k -> map[k.toLong()] = json.getLong(k) }
        return map
    }

    private fun saveMap(context: Context, map: Map<Long, Long>) {
        val json = JSONObject()
        map.forEach { (k, v) -> json.put(k.toString(), v) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json.toString()).apply()
    }

    private fun startOfDay(millis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = millis
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Baut den gemeinsamen Termin für den Tag, zu dem "anyTimeOnThatDay"
     *  gehört, komplett neu auf — abhängig davon, wer aktuell an diesem Tag
     *  eine Wiedervorlage hat. Bei niemandem mehr wird der Termin gelöscht. */
    suspend fun resyncDay(context: Context, dao: CustomerDao, anyTimeOnThatDay: Long) {
        val dayStart = startOfDay(anyTimeOnThatDay)
        val dayEnd = dayStart + 24 * 60 * 60 * 1000L - 1
        val customers = dao.getFollowUpsOnDay(dayStart, dayEnd)

        val map = loadMap(context)
        val existingEventId = map[dayStart]

        if (customers.isEmpty()) {
            existingEventId?.let { CalendarSync.deleteEvent(context, it) }
            if (existingEventId != null) {
                map.remove(dayStart)
                saveMap(context, map)
            }
            return
        }

        val dateLabel = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date(dayStart))
        val title = "🔔 Anrufliste $dateLabel"
        val timeFmt = SimpleDateFormat("HH:mm", Locale.GERMANY)
        val sorted = customers.sortedBy { it.followUpAt }
        val description = "Wiedervorlagen heute:\n" + sorted.joinToString("\n\n") { c ->
            val time = c.followUpAt?.let { timeFmt.format(Date(it)) } ?: "?"
            val reason = c.followUpReason.takeIf { it.isNotBlank() }?.let { "\n  Grund: $it" } ?: ""
            "• $time — ${c.name} (${c.phone})$reason"
        }
        // Termin-Startzeit: früheste Wiedervorlage des Tages (statt fest 9 Uhr,
        // jetzt wo jede Wiedervorlage eine eigene Uhrzeit hat).
        val start = sorted.firstOrNull()?.followUpAt ?: (dayStart + 9 * 60 * 60 * 1000L)

        val newEventId = CalendarSync.syncEvent(context, existingEventId, title, description, start, start + 30 * 60 * 1000L)
        if (newEventId != null && newEventId != existingEventId) {
            map[dayStart] = newEventId
            saveMap(context, map)
        }
    }
}
