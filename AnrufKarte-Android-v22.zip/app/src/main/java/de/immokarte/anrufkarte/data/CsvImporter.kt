package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Erwartet eine CSV mit Kopfzeile (Reihenfolge egal, Groß-/Kleinschreibung egal):
 * Name,Telefon,Typ,Adresse,Ort,Preis,Notizen
 * — identisch zum Format des Web-Prototyps.
 *
 * Erkennt automatisch, ob die Datei mit Komma oder Semikolon getrennt ist
 * (deutsches Excel speichert CSVs standardmäßig mit Semikolon).
 */
object CsvImporter {

    data class Row(
        val name: String,
        val telefon: String,
        val typ: String,
        val adresse: String,
        val ort: String,
        val preis: String,
        val notizen: String
    )

    fun parse(context: Context, uri: Uri): List<Row> {
        val rows = mutableListOf<Row>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            // BOM entfernen, falls vorhanden (Excel schreibt oft ein UTF-8-BOM)
            val reader = BufferedReader(InputStreamReader(input, Charsets.UTF_8))
            var header = reader.readLine() ?: return@use
            if (header.isNotEmpty() && header[0] == '\uFEFF') header = header.substring(1)

            val delimiter = detectDelimiter(header)
            val cols = splitCsvLine(header, delimiter).map { it.trim().trim('"').lowercase() }

            fun idx(vararg keys: String) = keys.firstNotNullOfOrNull { k ->
                val i = cols.indexOf(k)
                if (i >= 0) i else null
            } ?: -1

            val iName = idx("name")
            val iPhone = idx("telefon", "phone", "rufnummer", "handynummer")
            val iTyp = idx("typ", "type")
            val iAdresse = idx("adresse", "address", "straße", "strasse")
            val iOrt = idx("ort", "city", "stadt")
            val iPreis = idx("preis", "price")
            val iNotizen = idx("notizen", "notes", "notiz")

            if (iName < 0 || iPhone < 0) return@use

            var line = reader.readLine()
            while (line != null) {
                if (line.isNotBlank()) {
                    val cells = splitCsvLine(line, delimiter)
                    fun cell(i: Int) = if (i in cells.indices) cells[i].trim().trim('"') else ""
                    val name = cell(iName)
                    val telefon = cell(iPhone)
                    if (name.isNotBlank() && telefon.isNotBlank()) {
                        rows += Row(
                            name = name,
                            telefon = telefon,
                            typ = cell(iTyp).ifBlank { "Wohnung" },
                            adresse = cell(iAdresse),
                            ort = cell(iOrt),
                            preis = cell(iPreis).filter { it.isDigit() },
                            notizen = cell(iNotizen)
                        )
                    }
                }
                line = reader.readLine()
            }
        }
        return rows
    }

    /** Zählt Kommas vs. Semikolons in der Kopfzeile (außerhalb von Anführungszeichen)
     *  und nimmt das häufigere Zeichen als Trennzeichen. */
    private fun detectDelimiter(header: String): Char {
        var commas = 0
        var semicolons = 0
        var inQuotes = false
        for (c in header) {
            when {
                c == '"' -> inQuotes = !inQuotes
                c == ',' && !inQuotes -> commas++
                c == ';' && !inQuotes -> semicolons++
            }
        }
        return if (semicolons > commas) ';' else ','
    }

    /** Einfacher CSV-Parser, der Trennzeichen innerhalb von Anführungszeichen respektiert. */
    private fun splitCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        for (c in line) {
            when {
                c == '"' -> inQuotes = !inQuotes
                c == delimiter && !inQuotes -> { result += sb.toString(); sb.clear() }
                else -> sb.append(c)
            }
        }
        result += sb.toString()
        return result
    }
}
