package de.immokarte.anrufkarte.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "properties",
    foreignKeys = [ForeignKey(
        entity = CustomerEntity::class,
        parentColumns = ["id"],
        childColumns = ["customerId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("customerId")]
)
data class PropertyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val typ: String,       // "Haus" | "Wohnung" | "Sonstiges"
    val adresse: String = "",
    val ort: String = "",
    val preis: String = "", // Angebotspreis, in vollen Euro, nur Ziffern
    val status: String = "interessiert", // interessiert | reserviert | verkauft_vermietet
    val verkaufspreis: String = "", // tatsächlicher Verkaufs-/Abschlusspreis, nur Ziffern
    val exposeUri: String = "" // gespeicherte Datei-URI eines angehängten Exposés (PDF)
)
