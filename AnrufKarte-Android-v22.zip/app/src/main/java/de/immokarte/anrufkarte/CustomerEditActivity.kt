package de.immokarte.anrufkarte

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import androidx.core.content.FileProvider
import java.io.File
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.BackupManager
import de.immokarte.anrufkarte.data.CustomerEntity
import de.immokarte.anrufkarte.data.NoteEntry
import de.immokarte.anrufkarte.data.NoteLogUtils
import de.immokarte.anrufkarte.data.PdfExporter
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.PropertyEntity
import de.immokarte.anrufkarte.databinding.ActivityCustomerEditBinding
import de.immokarte.anrufkarte.databinding.ItemPropertyEditBinding
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class PropertyDraft(val typ: String, val adresse: String, val ort: String, val preis: String, val status: String, val verkaufspreis: String, val exposeUri: String)

private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)

class CustomerEditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CUSTOMER_ID = "extra_customer_id"
        const val EXTRA_PREFILL_NAME = "extra_prefill_name"
        const val EXTRA_PREFILL_PHONE = "extra_prefill_phone"
        const val EXTRA_PREFILL_EMAIL = "extra_prefill_email"
        const val EXTRA_PREFILL_NOTES = "extra_prefill_notes"
        const val EXTRA_PREFILL_STATUS = "extra_prefill_status"
        const val EXTRA_PREFILL_TAGS = "extra_prefill_tags"
        const val EXTRA_PREFILL_OBJEKT = "extra_prefill_objekt"
        const val EXTRA_PREFILL_PROGRESS = "extra_prefill_progress"
    }

    private lateinit var binding: ActivityCustomerEditBinding
    private var customerId: Long = -1L
    private val propertyRows = mutableListOf<ItemPropertyEditBinding>()
    private val propertyTypes = arrayOf("Haus", "Wohnung", "Sonstiges")
    private val propertyStatuses = arrayOf("interessiert", "reserviert", "verkauft_vermietet")
    private val propertyStatusLabels = arrayOf("Interessiert", "Reserviert", "Verkauft/Vermietet")
    private var followUpAt: Long? = null
    private var originalFollowUpAt: Long? = null
    private var anniversaryAt: Long? = null
    private var abschlussAt: Long? = null
    private var calendarEventId: Long? = null
    private var contractDateAt: Long? = null
    private var contractEventId: Long? = null
    private var viewingAt: Long? = null
    private var viewingEventId: Long? = null
    private var shootingAt: Long? = null
    private var shootingEventId: Long? = null
    // Werden im Formular nirgends angezeigt/bearbeitet, müssen aber beim
    // Speichern (REPLACE-Insert) unverändert mitgegeben werden — sonst
    // gehen sie bei jedem Speichern verloren.
    private var missedCalls: Int = 0
    private var lastContactAt: Long? = null
    // Diese Felder haben im Formular kein eigenes Eingabe-Element mehr
    // (auf Wunsch reduziert auf Email/Sprache/Status), bleiben aber beim
    // Laden/Speichern unverändert erhalten statt verloren zu gehen.
    private var tags: String = ""
    private var provision: String = ""
    private var reachability: String = ""
    private var searchOrt: String = ""
    private var budgetMax: String = ""
    private var important: Boolean = false
    private var storedReferredById: Long? = null
    private var noteLog: String = ""
    private var statusListenerActive = false
    private val propertyExposeUris = mutableMapOf<ItemPropertyEditBinding, String>()
    private var pendingExposeTarget: ItemPropertyEditBinding? = null

    private val pickExposeFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { docUri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(docUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                pendingExposeTarget?.let { propertyExposeUris[it] = docUri.toString() }
                Toast.makeText(this, "Exposé angehängt.", Toast.LENGTH_SHORT).show()
            }
        }

    private val pickPdfLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
            uri?.let { exportPdf(it) }
        }

    private val pickVCardLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri: Uri? ->
            uri?.let { exportVCard(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        binding = ActivityCustomerEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Aufklappbare Bereiche: Kontaktdaten + Termine starten offen (am
        // häufigsten gebraucht), der Rest eingeklappt (klappt sich unten
        // automatisch auf, falls beim Laden Inhalt vorhanden ist).
        setupCollapsible(binding.sectionKontaktHead, binding.sectionKontaktBody, binding.chevronKontakt, initiallyOpen = true)
        setupCollapsible(binding.sectionTermineHead, binding.sectionTermineBody, binding.chevronTermine, initiallyOpen = true)
        setupCollapsible(binding.sectionNotizenHead, binding.sectionNotizenBody, binding.chevronNotizen, initiallyOpen = false)
        setupCollapsible(binding.sectionObjekteHead, binding.sectionObjekteBody, binding.chevronObjekte, initiallyOpen = false)
        setupCollapsible(binding.sectionAktionenHead, binding.sectionAktionenBody, binding.chevronAktionen, initiallyOpen = false)

        customerId = intent.getLongExtra(EXTRA_CUSTOMER_ID, -1L)

        binding.spinnerStatus.adapter = de.immokarte.anrufkarte.data.ThemeManager.themedArrayAdapter(this, de.immokarte.anrufkarte.data.StatusInfo.labels)
        binding.spinnerLanguage.adapter = de.immokarte.anrufkarte.data.ThemeManager.themedArrayAdapter(this, listOf("Deutsch", "Englisch"))
        binding.spinnerStatus.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!statusListenerActive) return
                val newStatus = de.immokarte.anrufkarte.data.StatusInfo.keys[position]
                if (customerId >= 0) updateStatusBadge(newStatus)
                if (newStatus == "abschluss") {
                    var changed = false
                    if (abschlussAt == null) {
                        abschlussAt = System.currentTimeMillis()
                        changed = true
                    }
                    if (followUpAt == null) {
                        followUpAt = Calendar.getInstance().apply { add(Calendar.MONTH, 1) }.timeInMillis
                        changed = true
                    }
                    if (anniversaryAt == null) {
                        anniversaryAt = Calendar.getInstance().apply { add(Calendar.MONTH, 12) }.timeInMillis
                        changed = true
                    }
                    if (changed) {
                        updateFollowUpLabel()
                        updateAnniversaryLabel()
                        Toast.makeText(
                            this@CustomerEditActivity,
                            "Erinnerungen gesetzt: in 1 Monat nachfragen, in 1 Jahr Jahrestag-Gespräch",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    promptReviewRequest()
                } else if (abschlussAt != null) {
                    // Status wurde von "Kauf abgeschlossen" weg geändert (Deal ist doch
                    // geplatzt) — altes Abschlussdatum verwerfen. Sonst würde ein
                    // späterer, erneuter Abschluss fälschlich nicht als neuer
                    // Zeitpunkt erfasst (Statistik würde das alte Datum zeigen).
                    abschlussAt = null
                    Toast.makeText(this@CustomerEditActivity, "Abschlussdatum zurückgesetzt.", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        binding.btnAddProperty.setOnClickListener { addPropertyRow() }
        binding.btnSave.setOnClickListener { save() }
        binding.btnDelete.setOnClickListener { confirmDelete() }
        binding.btnPickDate.setOnClickListener { pickDate() }
        binding.btnComposeMessage.setOnClickListener { showComposeMessageDialog() }
        binding.btnMergeCustomer.setOnClickListener { showMergePickerDialog() }
        binding.btnDuplicateCustomer.setOnClickListener { confirmDuplicate() }
        binding.btnClearDate.setOnClickListener { followUpAt = null; updateFollowUpLabel() }
        binding.btnPickContractDate.setOnClickListener { pickContractDate() }
        binding.btnClearContractDate.setOnClickListener { contractDateAt = null; updateContractDateLabel() }
        binding.btnPickViewing.setOnClickListener { pickViewingDateTime() }
        binding.btnClearViewing.setOnClickListener { viewingAt = null; updateViewingLabel() }
        binding.btnViewingConfirmMessage.setOnClickListener { showViewingConfirmDraft() }
        binding.btnShootingConfirmMessage.setOnClickListener { showShootingConfirmChannelPicker() }
        binding.btnPickShooting.setOnClickListener { pickShootingDateTime() }
        binding.btnClearShooting.setOnClickListener { shootingAt = null; updateShootingLabel() }
        binding.btnAddNote.setOnClickListener { addNoteFromInput() }
        setupNoteTemplateChips()
        binding.btnExportPdf.setOnClickListener {
            val safeName = binding.etName.text.toString().trim().ifBlank { "kontakt" }.replace(Regex("[^A-Za-z0-9-]+"), "_")
            pickPdfLocation.launch("$safeName-steckbrief.pdf")
        }
        binding.btnExportVCard.setOnClickListener {
            val safeName = binding.etName.text.toString().trim().ifBlank { "kontakt" }.replace(Regex("[^A-Za-z0-9-]+"), "_")
            pickVCardLocation.launch("$safeName.vcf")
        }
        binding.btnAddContact.setOnClickListener { addToPhoneContacts() }
        binding.btnShareCustomer.setOnClickListener { shareCustomer() }

        if (customerId >= 0) {
            binding.tvTitle.text = getString(R.string.edit_title_edit)
            binding.btnDelete.visibility = View.VISIBLE
            binding.noteLogSection.visibility = View.VISIBLE
            binding.btnMergeCustomer.visibility = View.VISIBLE
            binding.btnDuplicateCustomer.visibility = View.VISIBLE
            loadCustomer()
        } else {
            binding.tvTitle.text = getString(R.string.edit_title_new)
            binding.noteLogSection.visibility = View.GONE // Notizen erst möglich, sobald der Kontakt gespeichert ist
            addPropertyRow()
            expandSection(binding.sectionObjekteBody, binding.chevronObjekte)
            updateFollowUpLabel()

            val prefillName = intent.getStringExtra(EXTRA_PREFILL_NAME).orEmpty()
            val prefillPhone = intent.getStringExtra(EXTRA_PREFILL_PHONE).orEmpty()
            val prefillEmail = intent.getStringExtra(EXTRA_PREFILL_EMAIL).orEmpty()
            val prefillNotes = intent.getStringExtra(EXTRA_PREFILL_NOTES).orEmpty()
            val prefillStatus = intent.getStringExtra(EXTRA_PREFILL_STATUS).orEmpty()
            val prefillTags = intent.getStringExtra(EXTRA_PREFILL_TAGS).orEmpty()
            val prefillObjekt = intent.getStringExtra(EXTRA_PREFILL_OBJEKT).orEmpty()
            val prefillProgress = intent.getStringExtra(EXTRA_PREFILL_PROGRESS).orEmpty()
            if (prefillName.isNotBlank() || prefillPhone.isNotBlank()) {
                binding.etName.setText(prefillName)
                binding.etPhone.setText(prefillPhone)
                binding.etEmail.setText(prefillEmail)
                if (prefillNotes.isNotBlank()) {
                    binding.etNotes.setText("Aus Foto erkannt:\n$prefillNotes")
                }
                if (prefillStatus.isNotBlank()) {
                    val idx = de.immokarte.anrufkarte.data.StatusInfo.keys.indexOf(prefillStatus)
                    if (idx >= 0) binding.spinnerStatus.setSelection(idx)
                }
                if (prefillTags.isNotBlank()) tags = prefillTags
                if (prefillObjekt.isNotBlank()) propertyRows.firstOrNull()?.etAdresse?.setText(prefillObjekt)
                if (prefillProgress.isNotBlank()) {
                    binding.tvTitle.text = "${getString(R.string.edit_title_new)} ($prefillProgress)"
                }
                Toast.makeText(this, "Bitte erkannte Daten kurz prüfen und ggf. korrigieren.", Toast.LENGTH_LONG).show()
            }
        }
        binding.spinnerStatus.post { statusListenerActive = true }
    }

    /** Status-Badge neben dem Titel — wie in der HTML-Detailansicht (Name + Badge in einer Zeile). */
    private fun updateStatusBadge(status: String) {
        binding.tvStatusBadge.text = de.immokarte.anrufkarte.data.StatusInfo.label(status)
        binding.tvStatusBadge.backgroundTintList =
            android.content.res.ColorStateList.valueOf(de.immokarte.anrufkarte.data.StatusInfo.color(status))
        binding.tvStatusBadge.visibility = View.VISIBLE
    }

    private fun loadCustomer() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val match = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) }
            if (match == null) { finish(); return@launch }

            binding.etName.setText(match.customer.name)
            binding.etPhone.setText(match.customer.phone)
            binding.etPhone2.setText(match.customer.phone2)
            binding.etEmail.setText(match.customer.email)
            binding.spinnerLanguage.setSelection(if (match.customer.preferredLanguage == "en") 1 else 0)
            binding.etNotes.setText(match.customer.notes)
            tags = match.customer.tags
            provision = match.customer.provision
            reachability = match.customer.reachability
            searchOrt = match.customer.searchOrt
            budgetMax = match.customer.budgetMax
            storedReferredById = match.customer.referredById
            contractDateAt = match.customer.contractDateAt
            contractEventId = match.customer.contractEventId
            updateContractDateLabel()
            viewingAt = match.customer.viewingAt
            viewingEventId = match.customer.viewingEventId
            updateViewingLabel()
            shootingAt = match.customer.shootingAt
            shootingEventId = match.customer.shootingEventId
            missedCalls = match.customer.missedCalls
            lastContactAt = match.customer.lastContactAt
            updateShootingLabel()
            important = match.customer.important
            binding.spinnerStatus.setSelection(de.immokarte.anrufkarte.data.StatusInfo.keys.indexOf(match.customer.status).coerceAtLeast(0))
            updateStatusBadge(match.customer.status)
            followUpAt = match.customer.followUpAt
            binding.etFollowUpReason.setText(match.customer.followUpReason)
            originalFollowUpAt = match.customer.followUpAt
            anniversaryAt = match.customer.anniversaryAt
            abschlussAt = match.customer.abschlussAt
            calendarEventId = match.customer.calendarEventId
            updateCalendarSyncLabel()
            noteLog = match.customer.noteLog
            updateFollowUpLabel()
            updateAnniversaryLabel()
            renderNoteLog()
            renderCallHistory()

            if (match.properties.isEmpty()) addPropertyRow()
            else match.properties.forEach { p -> addPropertyRow(p.typ, p.adresse, p.ort, p.preis, p.status, p.verkaufspreis, p.exposeUri) }

            // Bereiche mit bereits vorhandenem Inhalt automatisch aufklappen,
            // statt sie hinter einem Tap zu verstecken.
            if (match.customer.notes.isNotBlank() || match.customer.noteLog.isNotBlank()) {
                expandSection(binding.sectionNotizenBody, binding.chevronNotizen)
            }
            if (match.properties.any { it.adresse.isNotBlank() || it.ort.isNotBlank() || it.preis.isNotBlank() }) {
                expandSection(binding.sectionObjekteBody, binding.chevronObjekte)
            }
        }
    }

    /** Macht einen Bereich per Antippen der Kopfzeile auf-/zuklappbar. */
    private fun setupCollapsible(header: View, body: View, chevron: TextView, initiallyOpen: Boolean) {
        body.visibility = if (initiallyOpen) View.VISIBLE else View.GONE
        chevron.text = if (initiallyOpen) "▾" else "▸"
        header.setOnClickListener {
            val open = body.visibility != View.VISIBLE
            body.visibility = if (open) View.VISIBLE else View.GONE
            chevron.text = if (open) "▾" else "▸"
        }
    }

    private fun expandSection(body: View, chevron: TextView) {
        body.visibility = View.VISIBLE
        chevron.text = "▾"
    }

    private fun pickDate() {
        val cal = Calendar.getInstance()
        followUpAt?.let { cal.timeInMillis = it } ?: cal.set(Calendar.HOUR_OF_DAY, 9).also { cal.set(Calendar.MINUTE, 0) }
        DatePickerDialog(this, { _, year, month, day ->
            android.app.TimePickerDialog(this, { _, hour, minute ->
                val picked = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0)
                }
                followUpAt = picked.timeInMillis
                updateFollowUpLabel()
                checkHoliday(picked.timeInMillis, "Die Wiedervorlage")
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun pickContractDate() {
        val cal = Calendar.getInstance()
        contractDateAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            val picked = Calendar.getInstance().apply {
                set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            contractDateAt = picked.timeInMillis
            updateContractDateLabel()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateContractDateLabel() {
        binding.tvContractDateValue.text = contractDateAt?.let { dateFmt.format(Date(it)) } ?: "—"
    }

    /** Besichtigungen brauchen anders als Wiedervorlage/Vertragstermin eine
     *  konkrete Uhrzeit — deshalb Datum- und Uhrzeit-Dialog nacheinander. */
    private fun pickShootingDateTime() {
        val cal = Calendar.getInstance()
        shootingAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            android.app.TimePickerDialog(this, { _, hour, minute ->
                val picked = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0)
                }
                shootingAt = picked.timeInMillis
                updateShootingLabel()
                checkHoliday(picked.timeInMillis, "Der Termin")
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateShootingLabel() {
        binding.tvShootingValue.text = shootingAt?.let {
            SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(it))
        } ?: "—"
        binding.btnShootingConfirmMessage.visibility = if (shootingAt != null) View.VISIBLE else View.GONE
    }

    private fun pickViewingDateTime() {
        val cal = Calendar.getInstance()
        viewingAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            android.app.TimePickerDialog(this, { _, hour, minute ->
                val picked = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0)
                }
                viewingAt = picked.timeInMillis
                updateViewingLabel()
                checkViewingConflict(picked.timeInMillis)
                checkHoliday(picked.timeInMillis, "Die Besichtigung")

                // Ohne Adresse im (ggf. eingeklappten) Objekte-Bereich landet im
                // Kalender-Termin keine Adresse — Bereich aufklappen und hinweisen,
                // statt dass es beim Speichern stillschweigend leer bleibt.
                val hasAddress = propertyRows.any { it.etAdresse.text.toString().isNotBlank() }
                if (!hasAddress) {
                    expandSection(binding.sectionObjekteBody, binding.chevronObjekte)
                    Toast.makeText(this, "Tipp: Adresse unten bei „Objekte“ eintragen, damit sie im Kalender-Termin erscheint.", Toast.LENGTH_LONG).show()
                }
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    /** Warnt, falls sich die neue Besichtigung mit einer anderen überschneidet
     *  (beide standardmäßig 45 Minuten lang, siehe Kalender-Sync). */
    private fun checkViewingConflict(newStart: Long) {
        if (!de.immokarte.anrufkarte.data.ReminderPrefs.isEnabled(this, de.immokarte.anrufkarte.data.ReminderPrefs.Kind.CONFLICT)) return
        val newEnd = newStart + 45 * 60 * 1000L
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val windowStart = newStart - 60 * 60 * 1000L
            val windowEnd = newStart + 60 * 60 * 1000L
            val candidates = withContext(Dispatchers.IO) { dao.getViewingsInWindow(windowStart, windowEnd, customerId) }
            val conflict = candidates.firstOrNull { other ->
                val otherStart = other.viewingAt!!
                val otherEnd = otherStart + 45 * 60 * 1000L
                otherStart < newEnd && otherEnd > newStart
            }
            if (conflict != null) {
                val timeFmt = SimpleDateFormat("HH:mm", Locale.GERMANY)
                Toast.makeText(
                    this@CustomerEditActivity,
                    "⚠ Terminkonflikt: überschneidet sich mit ${conflict.name} um ${timeFmt.format(Date(conflict.viewingAt!!))}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** Warnt, falls ein Termin auf einen Sonntag oder bundesweiten Feiertag fällt. */
    private fun checkHoliday(millis: Long, subject: String) {
        if (!de.immokarte.anrufkarte.data.ReminderPrefs.isEnabled(this, de.immokarte.anrufkarte.data.ReminderPrefs.Kind.HOLIDAY)) return
        val reason = de.immokarte.anrufkarte.data.HolidayHelper.checkDate(millis) ?: return
        Toast.makeText(this, "⚠ $subject fällt auf: $reason", Toast.LENGTH_LONG).show()
    }

    private fun updateViewingLabel() {
        binding.tvViewingValue.text = viewingAt?.let {
            SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(it))
        } ?: "—"
        binding.btnViewingConfirmMessage.visibility = if (viewingAt != null) View.VISIBLE else View.GONE
    }

    private fun updateFollowUpLabel() {
        binding.tvFollowUpValue.text = followUpAt?.let { SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(it)) } ?: "—"
        updateCalendarSyncLabel()
    }

    /** Öffnet ein Bearbeiten-Fenster für eine WhatsApp-Nachricht — du kannst
     *  den Text frei schreiben/anpassen, bevor irgendwas verschickt wird.
     *  Der "✨ Mit KI personalisieren"-Knopf erstellt (nur wenn ein eigener
     *  API-Schlüssel hinterlegt ist) einen Entwurf, der konkrete Details aus
     *  den Notizen zum Kontakt aufgreift. */
    /** Baut aus dem eingetragenen Besichtigungstermin + der ersten Objekt-
     *  Adresse einen Bestätigungs-Textentwurf und öffnet ihn im
     *  Bearbeiten-Fenster — du prüfst/passt an, bevor irgendwas verschickt wird. */
    /** Fragt, ob die Shooting-Bestätigung per WhatsApp oder E-Mail raus soll,
     *  und öffnet den jeweils passenden vorausgefüllten Entwurf. */
    private fun showShootingConfirmChannelPicker() {
        val phone = binding.etPhone.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val options = mutableListOf<String>()
        if (phone.isNotBlank()) options += "💬 WhatsApp"
        if (email.isNotBlank()) options += "✉️ E-Mail"
        if (options.isEmpty()) {
            Toast.makeText(this, "Bitte zuerst Telefonnummer oder E-Mail eintragen.", Toast.LENGTH_SHORT).show()
            return
        }
        if (options.size == 1) {
            if (options[0].contains("WhatsApp")) showShootingConfirmDraft() else sendShootingConfirmEmail()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Bestätigung senden über…")
            .setItems(options.toTypedArray()) { _, which ->
                if (options[which].contains("WhatsApp")) showShootingConfirmDraft() else sendShootingConfirmEmail()
            }
            .show()
    }

    /** Sprache, wie im Spinner aktuell ausgewählt — steuert, in welcher
     *  Sprache generierte Kunden-Nachrichten (Bestätigungen etc.) verfasst werden. */
    private fun currentLanguage(): String = if (binding.spinnerLanguage.selectedItemPosition == 1) "en" else "de"

    private fun buildShootingConfirmText(): String {
        val at = shootingAt ?: return ""
        val lang = currentLanguage()
        val dateLabel = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date(at))
        val timeLabel = SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(at))
        val firstRow = propertyRows.firstOrNull()
        val adresse = firstRow?.etAdresse?.text?.toString()?.trim().orEmpty()
        val ort = firstRow?.etOrt?.text?.toString()?.trim().orEmpty()
        val ortsangabe = listOf(adresse, ort).filter { it.isNotBlank() }.joinToString(", ")
        val greeting = de.immokarte.anrufkarte.data.HolidayHelper.greetingFor(lang)
        return if (lang == "en") {
            buildString {
                append("Thank you for the call! See you on $dateLabel")
                if (ortsangabe.isNotBlank()) append(" at $ortsangabe")
                append(" at $timeLabel for our appointment.")
                if (greeting != null) append("\n\n$greeting")
                append("\n\nBest regards\nPaul Görner")
            }
        } else {
            buildString {
                append("Vielen Dank für das Telefonat! Bis zum $dateLabel")
                if (ortsangabe.isNotBlank()) append(" in der $ortsangabe")
                append(" um $timeLabel Uhr zu unserem Termin.")
                if (greeting != null) append("\n\n$greeting")
                append("\n\nMit freundlichen Grüßen\nPaul Görner")
            }
        }
    }

    private fun showShootingConfirmDraft() {
        showComposeMessageDialog(buildShootingConfirmText())
    }

    private fun sendShootingConfirmEmail() {
        val email = binding.etEmail.text.toString().trim()
        if (email.isBlank()) return
        val subject = if (currentLanguage() == "en") "Appointment — Confirmation" else "Termin — Bestätigung"
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, buildShootingConfirmText())
        }
        runCatching { startActivity(intent) }
    }

    private fun showViewingConfirmDraft() {
        val at = viewingAt ?: return
        val lang = currentLanguage()
        val dateLabel = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date(at))
        val timeLabel = SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(at))
        val firstRow = propertyRows.firstOrNull()
        val adresse = firstRow?.etAdresse?.text?.toString()?.trim().orEmpty()
        val ort = firstRow?.etOrt?.text?.toString()?.trim().orEmpty()
        val ortsangabe = listOf(adresse, ort).filter { it.isNotBlank() }.joinToString(", ")
        val greeting = de.immokarte.anrufkarte.data.HolidayHelper.greetingFor(lang)

        val text = if (lang == "en") {
            buildString {
                append("Thank you for the call! See you on $dateLabel")
                if (ortsangabe.isNotBlank()) append(" at $ortsangabe")
                append(" at $timeLabel.")
                if (greeting != null) append("\n\n$greeting")
                append("\n\nBest regards\nPaul Görner")
            }
        } else {
            buildString {
                append("Vielen Dank für das Telefonat! Bis zum $dateLabel")
                if (ortsangabe.isNotBlank()) append(" in der $ortsangabe")
                append(" um $timeLabel Uhr.")
                if (greeting != null) append("\n\n$greeting")
                append("\n\nMit freundlichen Grüßen\nPaul Görner")
            }
        }
        showComposeMessageDialog(text)
    }

    private fun showComposeMessageDialog(initialText: String = "") {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (phone.isBlank()) {
            Toast.makeText(this, "Bitte zuerst eine Telefonnummer eintragen.", Toast.LENGTH_SHORT).show()
            return
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }
        val input = android.widget.EditText(this).apply {
            setText(initialText)
            minLines = 5
            gravity = android.view.Gravity.TOP
            hint = "Deine Nachricht…"
        }
        val templateRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 }
        }
        val btnLoadTemplate = android.widget.Button(this).apply {
            text = "📋 Vorlage"
            isAllCaps = false
            textSize = 12f
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { showTemplatePicker(input) }
        }
        val btnSaveTemplate = android.widget.Button(this).apply {
            text = "💾 Als Vorlage speichern"
            isAllCaps = false
            textSize = 12f
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { promptSaveTemplate(input.text.toString()) }
        }
        templateRow.addView(btnLoadTemplate)
        templateRow.addView(btnSaveTemplate)
        container.addView(input)
        container.addView(templateRow)

        AlertDialog.Builder(this)
            .setTitle("Nachricht schreiben")
            .setView(container)
            .setPositiveButton("WhatsApp öffnen") { _, _ ->
                val digits = phone.filter { it.isDigit() || it == '+' }.removePrefix("+")
                val link = de.immokarte.anrufkarte.data.WhatsAppTemplates.buildLinkFromText(digits, input.text.toString())
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showTemplatePicker(input: android.widget.EditText) {
        val templates = de.immokarte.anrufkarte.data.CustomTemplateStore.getAll(this)
        if (templates.isEmpty()) {
            Toast.makeText(this, "Noch keine eigenen Vorlagen gespeichert.", Toast.LENGTH_SHORT).show()
            return
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        val etSearch = android.widget.EditText(this).apply {
            hint = "Suchen…"
            setSingleLine(true)
        }
        val listContainer = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        container.addView(etSearch)
        container.addView(listContainer)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Vorlage wählen")
            .setView(container)
            .setNeutralButton("Verwalten…") { _, _ -> showTemplateManageDialog() }
            .setNegativeButton("Abbrechen", null)
            .create()

        fun renderList(query: String) {
            listContainer.removeAllViews()
            val filtered = templates.filter { it.name.contains(query, ignoreCase = true) || it.text.contains(query, ignoreCase = true) }
            if (filtered.isEmpty()) {
                listContainer.addView(TextView(this).apply { text = "Keine Treffer."; setTextColor(0xFF8B93A0.toInt()); setPadding(0, 20, 0, 20) })
            }
            filtered.forEach { t ->
                listContainer.addView(TextView(this).apply {
                    text = t.name
                    textSize = 14f
                    setPadding(0, 24, 0, 24)
                    setOnClickListener { input.setText(t.text); dialog.dismiss() }
                })
            }
        }
        renderList("")
        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { renderList(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        dialog.show()
    }

    private fun promptSaveTemplate(currentText: String) {
        if (currentText.isBlank()) {
            Toast.makeText(this, "Erst einen Text schreiben, dann speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        val nameInput = android.widget.EditText(this).apply { hint = "z. B. Erinnerung Unterlagen" }
        AlertDialog.Builder(this)
            .setTitle("Als Vorlage speichern")
            .setMessage("Unter welchem Namen soll diese Nachricht wiederfindbar sein?")
            .setView(nameInput)
            .setPositiveButton("Speichern") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isNotBlank()) {
                    de.immokarte.anrufkarte.data.CustomTemplateStore.save(this, name, currentText)
                    Toast.makeText(this, "Vorlage „$name“ gespeichert.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showTemplateManageDialog() {
        val templates = de.immokarte.anrufkarte.data.CustomTemplateStore.getAll(this)
        if (templates.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Vorlage löschen")
            .setItems(templates.map { it.name }.toTypedArray()) { _, which ->
                de.immokarte.anrufkarte.data.CustomTemplateStore.delete(this, templates[which].name)
                Toast.makeText(this, "Gelöscht.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Fertig", null)
            .show()
    }

    /** Fragt beim Setzen auf "Kauf abgeschlossen" direkt nach, ob die
     *  Abschluss-Nachricht (Bewertungs-/Tippgeber-Links) per WhatsApp
     *  vorbereitet werden soll — spart das manuelle Dran-Denken zum
     *  passenden Zeitpunkt. Die drei Links lassen sich unter ⚙️ Einstellungen
     *  jederzeit ändern, falls sie sich mal ändern sollten. */
    private fun promptReviewRequest() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val googleLink = prefs.getString("google_review_link", "").orEmpty()
            .ifBlank { "https://maps.app.goo.gl/Kt8qygixF1S9Hs8u9?g_st=ac" }
        val trustpilotLink = prefs.getString("trustpilot_link", "").orEmpty()
            .ifBlank { "https://de.trustpilot.com/review/betterhomes.de" }
        val referralLink = prefs.getString("referral_link", "").orEmpty()
            .ifBlank { "https://www.betterhomes.de/de/immobilie-verkaufen-oder-vermieten/tippgeber-programm" }
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()

        if (phone.isBlank()) return

        AlertDialog.Builder(this)
            .setTitle("🎉 Glückwunsch zum Abschluss!")
            .setMessage("Jetzt eine Nachricht mit Bewertungs-/Tippgeber-Links vorbereiten?")
            .setPositiveButton("Ja, Nachricht vorbereiten") { _, _ ->
                val text = """
                    Hallo $name,

                    es hat mich sehr gefreut, Sie auf dem Weg in Ihr neues Zuhause begleiten zu dürfen! 😊

                    Wenn Sie mit meiner Betreuung zufrieden waren, würde ich mich sehr über eine kurze Bewertung freuen:

                    ⭐ Google: $googleLink
                    ⭐ Trustpilot: $trustpilotLink

                    🎁 Jemanden im Umfeld, der eine Immobilie sucht oder verkaufen möchte?
                    Mehr Infos zu unserem Tippgeberprogramm: $referralLink

                    Vielen Dank für Ihre Unterstützung! 🙏
                """.trimIndent()
                showComposeMessageDialog(text)
            }
            .setNegativeButton("Später", null)
            .show()
    }

    private fun updateCalendarSyncLabel() {
        binding.tvCalendarSync.text = when {
            followUpAt == null -> ""
            !de.immokarte.anrufkarte.data.CalendarSync.hasPermission(this) -> "⚠ Kalender-Berechtigung fehlt — Termin wird nicht synchronisiert (in den App-Berechtigungen erlauben)"
            !de.immokarte.anrufkarte.data.CalendarSync.hasAnyCalendar(this) -> "⚠ Kein Kalender-Konto auf dem Gerät gefunden — Termin kann nicht synchronisiert werden"
            else -> "📅 Wird automatisch im Kalender synchronisiert"
        }
    }

    private fun updateAnniversaryLabel() {
        if (anniversaryAt != null) {
            binding.tvAnniversary.visibility = View.VISIBLE
            binding.tvAnniversary.text = "🎉 Jahrestag-Erinnerung: ${dateFmt.format(Date(anniversaryAt!!))}  (zum Entfernen tippen)"
            binding.tvAnniversary.setOnClickListener { anniversaryAt = null; updateAnniversaryLabel() }
        } else {
            binding.tvAnniversary.visibility = View.GONE
        }
    }

    /** Filtert die automatisch protokollierten Anruf-Ereignisse (📞/📵) aus
     *  dem Notiz-Verlauf heraus und zeigt sie kompakt als eigene Übersicht —
     *  schneller Überblick "wann hab ich mit der Person telefoniert",
     *  ohne durch alle Notizen scrollen zu müssen. */
    private fun renderCallHistory() {
        val callEntries = NoteLogUtils.parse(noteLog)
            .filter { it.text.startsWith("📞") || it.text.startsWith("📵") }
            .sortedByDescending { it.timestamp }
        binding.callHistorySection.visibility = if (callEntries.isEmpty()) View.GONE else View.VISIBLE
        binding.callHistoryContainer.removeAllViews()
        callEntries.take(10).forEach { entry ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(14, 10, 14, 10)
            }
            row.addView(TextView(this).apply {
                text = SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(entry.timestamp))
                textSize = 11f
                setTextColor(0xFF8B93A0.toInt())
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this).apply {
                text = entry.text.removePrefix("📞").removePrefix("📵").trim()
                textSize = 11.5f
                setTextColor(if (entry.text.startsWith("📵")) 0xFF8C3B2B.toInt() else 0xFF3E6B4F.toInt())
            })
            binding.callHistoryContainer.addView(row)
            binding.callHistoryContainer.addView(View(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(0x14000000)
            })
        }
    }

    private fun renderNoteLog() {
        binding.noteLogContainer.removeAllViews()
        val entries = NoteLogUtils.parse(noteLog).sortedByDescending { it.timestamp }
        if (entries.isEmpty()) {
            val tv = TextView(this).apply {
                text = "Noch keine Notizen."
                textSize = 12f
                setTextColor(0xFF8B93A0.toInt())
            }
            binding.noteLogContainer.addView(tv)
            return
        }
        entries.forEach { entry ->
            val row = LayoutInflater.from(this).let { _ ->
                android.widget.LinearLayout(this).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    setPadding(20, 14, 20, 14)
                    setBackgroundResource(R.drawable.bg_paper_pill)
                    val params = android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.bottomMargin = 8
                    layoutParams = params
                }
            }
            val tvDate = TextView(this).apply {
                text = SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(entry.timestamp))
                textSize = 10.5f
                setTextColor(0xFF8B93A0.toInt())
            }
            val tvText = TextView(this).apply {
                text = entry.text
                textSize = 13f
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@CustomerEditActivity, R.attr.colorInk))
            }
            row.addView(tvDate)
            row.addView(tvText)
            binding.noteLogContainer.addView(row)
        }
    }

    /** Standard-Notiz-Textbausteine für schnelles Antippen — füllt nur das
     *  Eingabefeld, du kannst noch was ergänzen, bevor du auf "+" tippst
     *  (nichts wird beim Antippen selbst schon gespeichert). */
    private fun setupNoteTemplateChips() {
        val templates = listOf("Nicht erreicht", "Rückruf gewünscht", "Anrufbeantworter", "Kein Interesse mehr", "Termin vereinbart", "Unterlagen zugesendet")
        val container = binding.noteTemplateContainer
        container.removeAllViews()
        templates.forEach { label ->
            val chip = TextView(this).apply {
                text = label
                textSize = 11.5f
                setPadding(22, 12, 22, 12)
                setTextColor(0xFF5C6470.toInt())
                setBackgroundResource(R.drawable.bg_card)
                setOnClickListener { binding.etNewNote.setText(label) }
            }
            val params = android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)
            params.marginEnd = 6
            container.addView(chip, params)
        }
    }

    private fun addNoteFromInput() {
        val text = binding.etNewNote.text.toString().trim()
        if (text.isEmpty() || customerId < 0) return
        noteLog = NoteLogUtils.append(noteLog, NoteEntry(System.currentTimeMillis(), text))
        binding.etNewNote.text.clear()
        renderNoteLog()
        renderCallHistory()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().updateNoteLog(customerId, noteLog) }
        }
    }

    private fun addPropertyRow(
        typ: String = "Wohnung", adresse: String = "", ort: String = "", preis: String = "",
        status: String = "interessiert", verkaufspreis: String = "", exposeUri: String = ""
    ) {
        val rowBinding = ItemPropertyEditBinding.inflate(LayoutInflater.from(this), binding.propertiesContainer, false)
        rowBinding.spinnerTyp.adapter = de.immokarte.anrufkarte.data.ThemeManager.themedArrayAdapter(this, propertyTypes.toList())
        rowBinding.spinnerTyp.setSelection(propertyTypes.indexOf(typ).let { if (it >= 0) it else 1 })
        rowBinding.etAdresse.setText(adresse)
        rowBinding.etOrt.setText(ort)
        rowBinding.etPreis.setText(preis)
        rowBinding.etVerkaufspreis.setText(verkaufspreis)
        // Status (immer "interessiert") und Exposé-URI bleiben in der Datenbank
        // erhalten (kein Datenverlust), sind im Formular aber bewusst nicht mehr
        // editierbar — Objekte gehören ohnehin fest zum jeweiligen Kontakt.
        if (exposeUri.isNotBlank()) propertyExposeUris[rowBinding] = exposeUri

        rowBinding.btnRemoveProperty.setOnClickListener {
            binding.propertiesContainer.removeView(rowBinding.root)
            propertyRows.remove(rowBinding)
            propertyExposeUris.remove(rowBinding)
        }
        propertyRows += rowBinding
        binding.propertiesContainer.addView(rowBinding.root)
    }

    private fun save() {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_name_phone_required), Toast.LENGTH_SHORT).show()
            return
        }
        val phone2 = binding.etPhone2.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val preferredLanguage = if (binding.spinnerLanguage.selectedItemPosition == 1) "en" else "de"
        val notes = binding.etNotes.text.toString().trim()
        // tags/provision/reachability/searchOrt/budgetMax/important/storedReferredById
        // sind Klassenvariablen (siehe Feld-Deklarationen oben) — kein eigenes
        // Formularfeld mehr, bleiben beim Speichern unverändert erhalten.
        val referredById = storedReferredById
        val status = de.immokarte.anrufkarte.data.StatusInfo.keys[binding.spinnerStatus.selectedItemPosition]
        val normalized = PhoneUtils.normalize(phone)
        val normalized2 = if (phone2.isNotBlank()) PhoneUtils.normalize(phone2) else ""

        val properties = propertyRows.mapNotNull { row ->
            val adresse = row.etAdresse.text.toString().trim()
            val ort = row.etOrt.text.toString().trim()
            val preis = row.etPreis.text.toString().trim().filter { it.isDigit() }
            val verkaufspreis = row.etVerkaufspreis.text.toString().trim().filter { it.isDigit() }
            val typ = propertyTypes[row.spinnerTyp.selectedItemPosition]
            val exposeUri = propertyExposeUris[row] ?: ""
            if (adresse.isBlank() && ort.isBlank() && preis.isBlank()) null
            else PropertyDraft(typ, adresse, ort, preis, "interessiert", verkaufspreis, exposeUri)
        }

        if (customerId < 0) {
            // Neuer Kontakt: prüfen, ob die Nummer schon existiert, bevor gespeichert wird
            // (deckt auch den Foto-Import ab, der über denselben Weg läuft).
            lifecycleScope.launch {
                val dao = AppDatabase.getInstance(applicationContext).customerDao()
                val existingId = withContext(Dispatchers.IO) { dao.findIdByPhone(normalized) }
                if (existingId != null) {
                    val existing = withContext(Dispatchers.IO) { dao.getByIdWithProperties(existingId) }
                    AlertDialog.Builder(this@CustomerEditActivity)
                        .setTitle("Nummer bereits vorhanden")
                        .setMessage("Diese Telefonnummer gehört bereits zu „${existing?.customer?.name}“. Wie möchtest du fortfahren?")
                        .setPositiveButton("Bestehenden bearbeiten") { _, _ ->
                            startActivity(Intent(this@CustomerEditActivity, CustomerEditActivity::class.java).putExtra(EXTRA_CUSTOMER_ID, existingId))
                            setResult(RESULT_OK)
                            finish()
                        }
                        .setNeutralButton("Trotzdem neu anlegen") { _, _ -> performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties) }
                        .setNegativeButton("Abbrechen", null)
                        .show()
                } else {
                    performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties)
                }
            }
        } else {
            performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties)
        }
    }

    private fun performSave(
        name: String, phone: String, normalized: String, phone2: String, normalized2: String, email: String, preferredLanguage: String, notes: String, tags: String,
        provision: String, reachability: String, searchOrt: String, budgetMax: String, referredById: Long?,
        status: String, important: Boolean, properties: List<PropertyDraft>
    ) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()

            // Adresse aus dem (ersten) verknüpften Objekt — für ALLE drei
            // objektbezogenen Termine einheitlich: direkt im TITEL (immer
            // sichtbar, egal welche Kalender-Ansicht/Vorschau/Benachrichtigung),
            // zusätzlich als Ort-Feld (Navigation) und vorne in der Beschreibung.
            val primaryProperty = properties.firstOrNull()
            val propertyAddress = primaryProperty?.let { listOf(it.adresse, it.ort).filter { part -> part.isNotBlank() }.joinToString(", ") }?.takeIf { it.isNotBlank() }
            fun titleWithAddress(base: String) = base + (propertyAddress?.let { " — $it" } ?: "")
            fun descriptionWithAddress() = (propertyAddress?.let { "📍 $it\n\n" } ?: "") + "Anruf-Karte — $phone"

            // Für den Shooting-Termin zusätzlich kurz Objekt-Typ (WHG/Haus) +
            // Preis ergänzen, falls ein Objekt hinterlegt ist.
            val propertyTypeShort = primaryProperty?.typ?.let {
                when {
                    it.contains("Wohnung", ignoreCase = true) -> "WHG"
                    it.contains("Haus", ignoreCase = true) -> "Haus"
                    else -> it
                }
            }
            val propertyPriceInfo = listOfNotNull(propertyTypeShort, primaryProperty?.preis?.takeIf { it.isNotBlank() })
                .joinToString(" ").takeIf { it.isNotBlank() }
            val shootingTitle = titleWithAddress("Termin: $name") + (propertyPriceInfo?.let { " ($it)" } ?: "")

            val syncedContractEventId = withContext(Dispatchers.IO) {
                val start = contractDateAt?.plus(9 * 60 * 60 * 1000L)
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, contractEventId, titleWithAddress("Notar/Mietvertrag: $name"), descriptionWithAddress(), start, start?.plus(60 * 60 * 1000L),
                    location = propertyAddress
                )
            }
            val syncedShootingEventId = withContext(Dispatchers.IO) {
                val start = shootingAt
                // Bestehenden Termin bewusst löschen + neu anlegen statt zu
                // aktualisieren: Manche Kalender-Apps übernehmen eine
                // Farb-Änderung bei einem UPDATE nicht zuverlässig, bei einem
                // frischen INSERT aber schon.
                shootingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, null, shootingTitle, descriptionWithAddress(), start, start?.plus(60 * 60 * 1000L),
                    location = propertyAddress, colorOverride = de.immokarte.anrufkarte.data.CalendarSync.COLOR_SHOOTING_RED
                )
            }
            val syncedViewingEventId = withContext(Dispatchers.IO) {
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, viewingEventId, titleWithAddress("Besichtigung: $name"), descriptionWithAddress(), viewingAt, viewingAt?.plus(45 * 60 * 1000L),
                    location = propertyAddress, colorOverride = de.immokarte.anrufkarte.data.CalendarSync.COLOR_VIEWING_GRAY
                )
            }
            withContext(Dispatchers.IO) {
                val id = dao.insertCustomer(
                    CustomerEntity(
                        id = if (customerId >= 0) customerId else 0,
                        name = name, phone = phone, phoneNormalized = normalized, phone2 = phone2, phone2Normalized = normalized2,
                        email = email, notes = notes,
                        noteLog = noteLog, status = status, followUpAt = followUpAt,
                        followUpReason = binding.etFollowUpReason.text.toString().trim(),
                        important = important, tags = tags,
                        anniversaryAt = anniversaryAt, provision = provision, referredById = referredById,
                        reachability = reachability, abschlussAt = abschlussAt, calendarEventId = null,
                        searchOrt = searchOrt, budgetMax = budgetMax, contractDateAt = contractDateAt,
                        contractEventId = syncedContractEventId, preferredLanguage = preferredLanguage,
                        viewingAt = viewingAt, viewingEventId = syncedViewingEventId,
                        shootingAt = shootingAt, shootingEventId = syncedShootingEventId,
                        missedCalls = missedCalls, lastContactAt = lastContactAt
                    )
                )
                dao.deletePropertiesForCustomer(id)
                if (properties.isNotEmpty()) {
                    dao.insertProperties(properties.map {
                        PropertyEntity(
                            customerId = id, typ = it.typ, adresse = it.adresse, ort = it.ort, preis = it.preis,
                            status = it.status, verkaufspreis = it.verkaufspreis, exposeUri = it.exposeUri
                        )
                    })
                }
                val viewingAddress = properties.firstOrNull()
                    ?.let { listOf(it.adresse, it.ort).filter { part -> part.isNotBlank() }.joinToString(", ") }
                    ?.takeIf { it.isNotBlank() }
                de.immokarte.anrufkarte.reminder.ViewingReminderScheduler.schedule(applicationContext, id, name, phone, viewingAt, viewingAddress)
                de.immokarte.anrufkarte.reminder.ShootingReminderScheduler.schedule(applicationContext, id, name, phone, shootingAt, preferredLanguage)
                de.immokarte.anrufkarte.reminder.ContractReminderScheduler.schedule(applicationContext, id, name, phone, contractDateAt)

                // Betroffene Tage neu abgleichen: den alten (falls sich das Datum
                // geändert hat oder entfernt wurde) und den neuen — baut den
                // gemeinsamen Kalender-Termin für jeden Tag komplett neu auf.
                if (originalFollowUpAt != null && originalFollowUpAt != followUpAt) {
                    de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, originalFollowUpAt!!)
                }
                followUpAt?.let { de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
                originalFollowUpAt = followUpAt
            }
            FollowUpWidgetProvider.updateAll(applicationContext)
            setResult(RESULT_OK)
            finish()
        }
    }



    /** Öffnet den Telefon-Kontakte-Dialog vorausgefüllt — Nutzer speichert selbst,
     *  kein WRITE_CONTACTS-Recht nötig. */
    private fun addToPhoneContacts() {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_name_phone_required), Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, name)
            putExtra(ContactsContract.Intents.Insert.PHONE, phone)
        }
        runCatching { startActivity(intent) }
            .onFailure { Toast.makeText(this, "Kontakte-App konnte nicht geöffnet werden.", Toast.LENGTH_SHORT).show() }
    }

    /** Exportiert genau diesen Kontakt als JSON-Datei und öffnet den System-Teilen-Dialog.
     *  Ein Kollege mit derselben App kann die Datei direkt über "Wiederherstellen"
     *  importieren — die Daten (inkl. Objekte, Notizen) werden dann automatisch übernommen. */
    private fun shareCustomer() {
        if (customerId < 0) {
            Toast.makeText(this, "Bitte den Kontakt zuerst speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val data = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch

            val safeName = data.customer.name.ifBlank { "kontakt" }.replace(Regex("[^A-Za-z0-9-]+"), "_")
            val file = File(cacheDir, "$safeName-anrufkarte.json")
            withContext(Dispatchers.IO) {
                val uri = Uri.fromFile(file)
                BackupManager.export(this@CustomerEditActivity, uri, listOf(data))
            }

            val contentUri = FileProvider.getUriForFile(this@CustomerEditActivity, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Kontakt: ${data.customer.name}")
                putExtra(Intent.EXTRA_TEXT, "Kontakt „${data.customer.name}“ aus der Anruf-Karte — mit derselben App über \"Wiederherstellen\" importierbar.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Kontakt teilen"))
        }
    }

    private fun exportPdf(uri: Uri) {
        if (customerId < 0) {
            Toast.makeText(this, "Bitte den Kontakt zuerst speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val data = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch
            withContext(Dispatchers.IO) { PdfExporter.export(this@CustomerEditActivity, uri, data) }
            Toast.makeText(this@CustomerEditActivity, "PDF-Steckbrief gespeichert.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportVCard(uri: Uri) {
        if (customerId < 0) {
            Toast.makeText(this, "Bitte den Kontakt zuerst speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val data = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch
            withContext(Dispatchers.IO) { de.immokarte.anrufkarte.data.VCardExporter.export(this@CustomerEditActivity, uri, data.customer) }
            Toast.makeText(this@CustomerEditActivity, "vCard gespeichert — öffnet sich mit jeder Kontakte-App.", Toast.LENGTH_LONG).show()
        }
    }

    /** Zeigt eine durchsuchbare Liste aller anderen Kontakte, um einen
     *  Duplikat-Eintrag in den aktuell geöffneten zu übernehmen. */
    /** Legt eine Kopie dieses Kontakts an — für Partner/WG, wo Status,
     *  Objekte, Tags, Budget usw. meist identisch sind und nur Name/Telefon
     *  unterschiedlich. Termine, Notizen und der Verlauf werden bewusst
     *  NICHT übernommen (die sind pro Person eigen). Öffnet direkt den
     *  neuen (leeren) Kontakt zum Ausfüllen von Name/Telefon. */
    private fun confirmDuplicate() {
        AlertDialog.Builder(this)
            .setTitle("Kontakt duplizieren?")
            .setMessage("Legt eine Kopie mit Status, Tags, Objekten, Budget und Suchort an — Name, Telefon, Notizen und Termine bleiben leer, da die meist pro Person unterschiedlich sind.")
            .setPositiveButton("Duplizieren") { _, _ -> performDuplicate() }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun performDuplicate() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val source = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch
            val newId = withContext(Dispatchers.IO) {
                val id = dao.insertCustomer(
                    CustomerEntity(
                        name = "", phone = "", phoneNormalized = "",
                        status = source.customer.status, tags = source.customer.tags,
                        searchOrt = source.customer.searchOrt, budgetMax = source.customer.budgetMax,
                        reachability = source.customer.reachability, preferredLanguage = source.customer.preferredLanguage,
                        referredById = source.customer.referredById
                    )
                )
                if (source.properties.isNotEmpty()) {
                    dao.insertProperties(source.properties.map {
                        PropertyEntity(customerId = id, typ = it.typ, adresse = it.adresse, ort = it.ort, preis = it.preis, status = it.status, verkaufspreis = it.verkaufspreis)
                    })
                }
                id
            }
            Toast.makeText(this@CustomerEditActivity, "Dupliziert — bitte Name und Telefonnummer eintragen.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this@CustomerEditActivity, CustomerEditActivity::class.java).putExtra(EXTRA_CUSTOMER_ID, newId))
        }
    }

    private fun showMergePickerDialog() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val others = withContext(Dispatchers.IO) { dao.getNamesForPicker(customerId) }
            if (others.isEmpty()) {
                Toast.makeText(this@CustomerEditActivity, "Keine anderen Kontakte vorhanden.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            AlertDialog.Builder(this@CustomerEditActivity)
                .setTitle("Welchen Kontakt hier zusammenführen?")
                .setItems(others.map { it.name }.toTypedArray()) { _, which ->
                    confirmMerge(others[which])
                }
                .setNegativeButton("Abbrechen", null)
                .show()
        }
    }

    private fun confirmMerge(other: de.immokarte.anrufkarte.data.CustomerNameOnly) {
        AlertDialog.Builder(this)
            .setTitle("Wirklich zusammenführen?")
            .setMessage(
                "\"${other.name}\" wird in diesen Kontakt übernommen (Notizen, Tags, Objekte, ggf. zweite " +
                    "Telefonnummer) und danach gelöscht. Das lässt sich nicht rückgängig machen."
            )
            .setPositiveButton("Zusammenführen") { _, _ -> performMerge(other.id) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun performMerge(otherId: Long) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val otherFull = withContext(Dispatchers.IO) { dao.getByIdWithProperties(otherId) }
            if (otherFull == null) {
                Toast.makeText(this@CustomerEditActivity, "Kontakt nicht gefunden.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            withContext(Dispatchers.IO) {
                // Vertragstermin/Besichtigung des Duplikats sind wirklich nur
                // seine eigenen — die dürfen direkt gelöscht werden.
                otherFull.customer.contractEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                otherFull.customer.viewingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                otherFull.customer.shootingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                de.immokarte.anrufkarte.reminder.ViewingReminderScheduler.cancel(applicationContext, otherFull.customer.id)
                de.immokarte.anrufkarte.reminder.ShootingReminderScheduler.cancel(applicationContext, otherFull.customer.id)
                de.immokarte.anrufkarte.reminder.ContractReminderScheduler.cancel(applicationContext, otherFull.customer.id)

                val currentTarget = dao.getByIdWithProperties(customerId)?.customer
                    ?: CustomerEntity(id = customerId, name = binding.etName.text.toString().trim(), phone = binding.etPhone.text.toString().trim(), phoneNormalized = PhoneUtils.normalize(binding.etPhone.text.toString().trim()))
                de.immokarte.anrufkarte.data.MergeHelper.merge(dao, currentTarget, otherFull.customer)

                // Wiedervorlage: NICHT den (möglicherweise mit anderen Kontakten
                // geteilten) Tages-Termin direkt löschen — stattdessen den Tag
                // neu abgleichen, nachdem das Duplikat weg ist. So bleiben
                // andere Kontakte am selben Tag im gemeinsamen Termin erhalten.
                otherFull.customer.followUpAt?.let { de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
            }
            Toast.makeText(this@CustomerEditActivity, "Zusammengeführt.", Toast.LENGTH_LONG).show()
            loadCustomer()
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_message))
            .setPositiveButton(getString(R.string.btn_delete)) { _, _ -> deleteCustomer() }
            .setNegativeButton(getString(R.string.btn_cancel), null)
            .show()
    }

    private fun deleteCustomer() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val fullData = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) }
            withContext(Dispatchers.IO) {
                contractEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                viewingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                shootingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                de.immokarte.anrufkarte.reminder.ViewingReminderScheduler.cancel(applicationContext, customerId)
                de.immokarte.anrufkarte.reminder.ShootingReminderScheduler.cancel(applicationContext, customerId)
                de.immokarte.anrufkarte.reminder.ContractReminderScheduler.cancel(applicationContext, customerId)
                dao.deleteCustomerById(customerId)
                // Statt den (jetzt evtl. geteilten) Wiedervorlage-Termin zu löschen,
                // den betroffenen Tag neu abgleichen — andere Kontakte am selben
                // Tag bleiben im gemeinsamen Termin erhalten.
                followUpAt?.let { de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
            }
            if (fullData != null) {
                de.immokarte.anrufkarte.data.UndoManager.set("Kontakt gelöscht: ${fullData.customer.name}") {
                    withContext(Dispatchers.IO) {
                        dao.insertCustomer(fullData.customer)
                        if (fullData.properties.isNotEmpty()) dao.insertProperties(fullData.properties)
                        val restoredAddress = fullData.properties.firstOrNull()
                            ?.let { listOf(it.adresse, it.ort).filter { part -> part.isNotBlank() }.joinToString(", ") }
                            ?.takeIf { it.isNotBlank() }
                        de.immokarte.anrufkarte.reminder.ViewingReminderScheduler.schedule(
                            applicationContext, fullData.customer.id, fullData.customer.name, fullData.customer.phone, fullData.customer.viewingAt, restoredAddress
                        )
                        fullData.customer.followUpAt?.let { de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
                    }
                }
            }
            FollowUpWidgetProvider.updateAll(applicationContext)
            setResult(RESULT_OK)
            finish()
        }
    }
}
