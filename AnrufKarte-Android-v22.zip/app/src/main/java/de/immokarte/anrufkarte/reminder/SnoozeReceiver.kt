package de.immokarte.anrufkarte.reminder

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Reagiert auf "In 1 Stunde erinnern" in der Verpasster-Anruf-Benachrichtigung:
 *  schließt die aktuelle Benachrichtigung und plant eine neue in 1 Stunde. */
class SnoozeReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_NOTIF_ID = "extra_notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra(EXTRA_NAME) ?: return
        val phone = intent.getStringExtra(EXTRA_PHONE) ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, phone.hashCode())

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId)

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val callbackIntent = Intent(context, CallbackReminderReceiver::class.java).apply {
            putExtra(EXTRA_NAME, name)
            putExtra(EXTRA_PHONE, phone)
        }
        val pending = PendingIntent.getBroadcast(
            context, notifId, callbackIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60 * 60 * 1000, pending)

        Toast.makeText(context, "Erinnerung in 1 Stunde für $name", Toast.LENGTH_SHORT).show()
    }
}
