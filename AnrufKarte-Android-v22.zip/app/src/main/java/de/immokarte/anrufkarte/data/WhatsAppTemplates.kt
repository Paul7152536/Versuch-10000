package de.immokarte.anrufkarte.data

import java.net.URLEncoder

data class WaTemplate(val label: String, val text: String, val lang: String)

/** Vorformulierte WhatsApp-Nachrichten. {name} wird durch den Kundennamen ersetzt,
 *  {link} durch den Google-Bewertungslink, {catalog} durch den Katalog-Link. */
object WhatsAppTemplates {

    val templates = listOf(
        WaTemplate("Terminbestätigung", "Hallo {name}, hiermit bestätige ich gerne unseren Besichtigungstermin. Bis bald!", "de"),
        WaTemplate("Kurze Rückfrage", "Hallo {name}, ich wollte kurz nachfragen, ob noch Fragen offen sind?", "de"),
        WaTemplate("Rückruf erbeten", "Hallo {name}, ich habe versucht Sie zu erreichen. Könnten Sie mich zurückrufen, wenn es passt?", "de"),
        WaTemplate("Glückwunsch zum Kauf", "Hallo {name}, herzlichen Glückwunsch nochmal zu Ihrem neuen Zuhause! Melden Sie sich gerne, falls ich noch etwas für Sie tun kann.", "de"),
        WaTemplate("⭐ Bewertung erbitten", "Hallo {name}, es hat mich sehr gefreut, Sie auf dem Weg zu Ihrem neuen Zuhause zu begleiten! Falls Sie kurz Zeit haben, würde ich mich riesig über eine kurze Google-Bewertung freuen: {link}", "de"),
        WaTemplate("📋 Objektübersicht", "Hallo {name}, hier finden Sie eine Übersicht meiner aktuellen Objekte: {catalog}", "de"),
        WaTemplate("🎄 Weihnachtsgruß", "Hallo {name}, ich wünsche Ihnen und Ihren Liebsten ein frohes Weihnachtsfest und einen guten Rutsch ins neue Jahr!", "de"),
        WaTemplate("🎆 Neujahrsgruß", "Hallo {name}, alles Gute für das neue Jahr! Falls sich bei Ihnen etwas in Sachen Immobilien tut, bin ich gerne für Sie da.", "de"),
        WaTemplate("🇬🇧 Appointment confirmation", "Hi {name}, this is to confirm our viewing appointment. See you soon!", "en"),
        WaTemplate("🇬🇧 Quick follow-up", "Hi {name}, just checking in to see if you have any open questions?", "en"),
        WaTemplate("🇬🇧 Please call back", "Hi {name}, I tried to reach you. Could you please call me back when convenient?", "en"),
        WaTemplate("🇬🇧 Congratulations", "Hi {name}, congratulations again on your new home! Feel free to reach out if I can help with anything.", "en"),
    )

    /** Sortiert die bevorzugte Sprache des Kontakts nach vorne, ohne die
     *  jeweils interne Reihenfolge innerhalb einer Sprache zu verändern. */
    fun templatesFor(preferredLanguage: String): List<WaTemplate> =
        templates.sortedBy { if (it.lang == preferredLanguage) 0 else 1 }

    fun buildLink(phoneDigits: String, name: String, template: String, reviewLink: String = "", catalogLink: String = ""): String {
        val text = template.replace("{name}", name.ifBlank { "" })
            .replace("{link}", reviewLink)
            .replace("{catalog}", catalogLink)
            .trim()
        val encoded = URLEncoder.encode(text, "UTF-8")
        return "https://wa.me/$phoneDigits?text=$encoded"
    }

    fun buildLinkPlain(phoneDigits: String): String = "https://wa.me/$phoneDigits"

    /** Für frei zusammengestellte Nachrichten (z. B. die kombinierte
     *  Bewertungs-/Tippgeber-Nachricht beim Abschluss) — kein {platzhalter}-
     *  Ersetzen, nur URL-Kodierung des fertigen Texts. */
    fun buildLinkFromText(phoneDigits: String, text: String): String {
        val encoded = URLEncoder.encode(text.trim(), "UTF-8")
        return "https://wa.me/$phoneDigits?text=$encoded"
    }
}
