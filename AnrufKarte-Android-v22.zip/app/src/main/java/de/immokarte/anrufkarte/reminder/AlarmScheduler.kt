package de.immokarte.anrufkarte.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {

    /** Plant eine tägliche Prüfung um 8:00 Uhr, ob Wiedervorlagen fällig sind. */
    fun scheduleDaily(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, FollowUpReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

        // Inexakter, wiederholender Alarm — kein SCHEDULE_EXACT_ALARM-Recht nötig,
        // Abweichung von ein paar Minuten ist für eine Tageserinnerung unkritisch.
        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP, triggerAt, AlarmManager.INTERVAL_DAY, pending
        )
    }
}
