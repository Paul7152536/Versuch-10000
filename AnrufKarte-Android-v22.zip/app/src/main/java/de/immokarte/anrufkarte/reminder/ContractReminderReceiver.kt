package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.CustomerEditActivity

/** Feuert 1 Tag vor einem Notar-/Mietvertragstermin — Erinnerung, an
 *  benötigte Unterlagen zu denken (Ausweis, Vollmacht, Grundbuchauszug etc.,
 *  je nach Termin). */
class ContractReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_CUSTOMER_ID = "extra_customer_id"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_DATE_LABEL = "extra_date_label"
        const val EXTRA_TIME_LABEL = "extra_time_label"
        private const val CHANNEL_ID = "contract_reminder"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val customerId = intent.getLongExtra(EXTRA_CUSTOMER_ID, -1L)
        val name = intent.getStringExtra(EXTRA_NAME) ?: return
        val timeLabel = intent.getStringExtra(EXTRA_TIME_LABEL).orEmpty()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Notar-/Mietvertrag-Erinnerung", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            context, customerId.toInt(),
            Intent(context, CustomerEditActivity::class.java).apply {
                putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, customerId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("📝 Notar/Mietvertrag morgen: $name")
            .setContentText("Termin um $timeLabel Uhr — an Unterlagen denken")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(4006 + customerId.toInt(), builder.build())
    }
}
