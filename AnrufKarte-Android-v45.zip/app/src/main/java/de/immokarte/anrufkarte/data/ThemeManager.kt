package de.immokarte.anrufkarte.data

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import de.immokarte.anrufkarte.R

/** Verwaltet die drei wählbaren App-Designs (Modern Minimal / Dark
 *  Professional / Warm & Freundlich). Jede Activity ruft applyTheme() vor
 *  setContentView() auf; der OverlayService (kein Activity-Kontext) nutzt
 *  themedContext(), um sein Layout im passenden Design einzufärben. */
object ThemeManager {
    private const val PREFS = "anruf_karte_prefs"
    private const val KEY = "app_theme"

    const val MINIMAL = "minimal"
    const val DARK = "dark"
    const val WARM = "warm"
    const val ANTHRACITE = "anthracite"
    const val BETTERHOMES = "betterhomes"

    val options = listOf(
        ANTHRACITE to "Anruf-Karte (Standard)",
        MINIMAL to "Modern Minimal",
        DARK to "Dark Professional",
        WARM to "Warm & Freundlich",
        BETTERHOMES to "Betterhomes-Stil",
    )

    fun current(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY, ANTHRACITE) ?: ANTHRACITE
    }

    fun setTheme(context: Context, theme: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, theme).apply()
    }

    private fun styleResFor(theme: String): Int = when (theme) {
        DARK -> R.style.Theme_AnrufKarte_Dark
        WARM -> R.style.Theme_AnrufKarte_Warm
        MINIMAL -> R.style.Theme_AnrufKarte_Minimal
        BETTERHOMES -> R.style.Theme_AnrufKarte_Betterhomes
        else -> R.style.Theme_AnrufKarte_Anthracite
    }

    /** In jeder Activity direkt nach super.onCreate() und vor setContentView() aufrufen. */
    fun applyTheme(activity: Activity) {
        activity.setTheme(styleResFor(current(activity)))
    }

    /** Für Kontexte ohne eigenes Activity-Theme (z. B. den OverlayService). */
    fun themedContext(context: Context): Context =
        ContextThemeWrapper(context, styleResFor(current(context)))

    /** Löst eine Theme-Farbe zur Laufzeit auf — für die wenigen Stellen, an
     *  denen Farben direkt im Kotlin-Code gesetzt werden (nicht per XML). */
    fun resolveColor(context: Context, attrResId: Int): Int {
        val themed = themedContext(context)
        val typedValue = TypedValue()
        themed.theme.resolveAttribute(attrResId, typedValue, true)
        return typedValue.data
    }

    /** ArrayAdapter für Spinner, dessen Text explizit in der Theme-Textfarbe
     *  (colorInk) eingefärbt wird. Der Standard-Android-Zeilenlayout
     *  (simple_spinner_item/_dropdown_item) nutzt sonst systemeigene, feste
     *  Textfarben (meist schwarz) — auf den dunklen Feld-Hintergründen der
     *  Dark-/Anthracite-/... Designs war der ausgewählte Wert dadurch kaum
     *  oder gar nicht lesbar. */
    /** Färbt ein programmatisch erzeugtes EditText (z. B. in einem
     *  AlertDialog) im aktuellen Design ein — Hintergrund, Textfarbe und
     *  Hinweistextfarbe. Ohne das nutzt so ein Feld die Standard-Dialog-
     *  Optik des Systems, die je nach Design (v. a. Betterhomes) zu kaum
     *  lesbarem dunklem Text auf dunklem Grund führen kann. */
    fun styleDialogField(context: Context, editText: android.widget.EditText) {
        // Hintergrund UND Textfarbe bewusst aus derselben, frisch aus den
        // SharedPreferences gelesenen Theme-Quelle (themedContext) holen —
        // beide über getriggte activity.setTheme()-Werte laufen zu lassen
        // konnte nach einem Design-Wechsel kurzzeitig auseinanderlaufen
        // (z. B. noch dunkles Feld + schon dunkler Text vom neuen, hellen
        // Design), was zu kaum lesbarem dunklem Text auf dunklem Grund führte.
        val themed = themedContext(context)
        editText.background = themed.getDrawable(R.drawable.bg_field)
        editText.setPadding(20, 16, 20, 16)
        editText.setTextColor(resolveColor(context, R.attr.colorInk))
        editText.setHintTextColor(resolveColor(context, R.attr.colorInkFaint))
    }

    fun themedArrayAdapter(activity: Activity, items: List<String>): ArrayAdapter<String> {
        val inkColor = resolveColor(activity, R.attr.colorInk)
        val adapter = object : ArrayAdapter<String>(activity, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: ViewGroup): android.view.View {
                val view = super.getView(position, convertView, parent)
                (view as? TextView)?.setTextColor(inkColor)
                return view
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: ViewGroup): android.view.View {
                val view = super.getDropDownView(position, convertView, parent)
                (view as? TextView)?.setTextColor(inkColor)
                return view
            }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }
}
