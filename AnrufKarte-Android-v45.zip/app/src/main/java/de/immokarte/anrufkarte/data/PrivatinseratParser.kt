package de.immokarte.anrufkarte.data

import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Zerlegt einen eingefügten Zeitungsinserat-Text nach dem Schema
 *   Name (des Anbieters): …
 *   Objekt: …
 *   Lage: …
 *   Preis: …
 *   Telefon: …
 *   E-Mail: …
 *   Eingestellt am: 29.08.2026
 *   Privat eindeutig: 🟢 / unklar: 🟡
 * in die einzelnen Felder — Zeilen können in beliebiger Reihenfolge stehen,
 * Groß-/Kleinschreibung der Label ist egal. Nicht erkannte Zeilen werden
 * ignoriert, fehlende Felder bleiben leer.
 */
object PrivatinseratParser {

    private val labelMap = mapOf(
        "name" to "name", "name des anbieters" to "name", "anbieter" to "name",
        "objekt" to "objekt", "lage" to "lage", "preis" to "preis",
        "telefon" to "telefon", "tel" to "telefon",
        "email" to "email", "e-mail" to "email",
        "eingestellt am" to "eingestellt", "eingestellt" to "eingestellt", "reingestellt" to "eingestellt",
        "privat eindeutig" to "privat", "privat" to "privat"
    )

    data class Parsed(
        val name: String = "", val objekt: String = "", val lage: String = "", val preis: String = "",
        val telefon: String = "", val email: String = "", val eingestelltAt: Long? = null, val privatStatus: String = ""
    ) {
        fun isEmpty() = objekt.isBlank() && lage.isBlank() && preis.isBlank() && name.isBlank()
    }

    /** Ein einzelner Block (Rückwärtskompatibilität — nutzt intern parseMultiple). */
    fun parse(raw: String): Parsed = parseMultiple(raw).firstOrNull() ?: Parsed()

    /** Mehrere hintereinander eingefügte Inserate auf einmal — Blöcke werden
     *  an Leerzeilen ODER an einer erneut auftauchenden "Objekt:"-Zeile
     *  getrennt (falls ohne Leerzeile zwischen zwei Anzeigen reinkopiert
     *  wurde). Leere/nicht erkannte Blöcke werden ausgelassen. */
    fun parseMultiple(raw: String): List<Parsed> {
        val blocks = mutableListOf<MutableList<String>>()
        var current = mutableListOf<String>()
        raw.lines().forEach { rawLine ->
            val line = rawLine.trim()
            val startsNewObjekt = line.lowercase().startsWith("objekt:") && current.any { it.lowercase().startsWith("objekt:") }
            if (line.isBlank() || startsNewObjekt) {
                if (current.isNotEmpty()) { blocks += current; current = mutableListOf() }
                if (startsNewObjekt) current.add(rawLine)
            } else {
                current.add(rawLine)
            }
        }
        if (current.isNotEmpty()) blocks += current

        return blocks.map { parseSingleBlock(it.joinToString("\n")) }.filter { !it.isEmpty() }
    }

    private fun parseSingleBlock(raw: String): Parsed {
        val values = mutableMapOf<String, String>()
        raw.lines().forEach { line ->
            val idx = line.indexOf(':')
            if (idx <= 0) return@forEach
            val label = line.substring(0, idx).trim().lowercase()
            val value = line.substring(idx + 1).trim()
            val key = labelMap[label] ?: return@forEach
            if (value.isNotBlank()) values[key] = value
        }
        val datumText = values["eingestellt"]
        val datum = datumText?.let {
            listOf("d.M.yyyy", "dd.MM.yyyy").firstNotNullOfOrNull { pattern ->
                runCatching { SimpleDateFormat(pattern, Locale.GERMANY).parse(it)?.time }.getOrNull()
            }
        }
        val privatRoh = values["privat"].orEmpty().lowercase()
        val privatStatus = when {
            privatRoh.contains("🟢") || privatRoh.contains("eindeutig") -> "eindeutig"
            privatRoh.contains("🟡") || privatRoh.contains("unklar") -> "unklar"
            else -> ""
        }
        return Parsed(
            name = values["name"].orEmpty(),
            objekt = values["objekt"].orEmpty(),
            lage = values["lage"].orEmpty(),
            preis = values["preis"].orEmpty(),
            telefon = values["telefon"].orEmpty(),
            email = values["email"].orEmpty(),
            eingestelltAt = datum,
            privatStatus = privatStatus
        )
    }
}
