package de.immokarte.anrufkarte.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PrivatinseratDao {
    @Query("SELECT * FROM privatinserate ORDER BY kontaktiert ASC, erfasstAt DESC")
    suspend fun getAll(): List<PrivatinseratEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: PrivatinseratEntity): Long

    @Query("UPDATE privatinserate SET kontaktiert = :value WHERE id = :id")
    suspend fun setKontaktiert(id: Long, value: Boolean)

    @Query("UPDATE privatinserate SET notiz = :notiz WHERE id = :id")
    suspend fun setNotiz(id: Long, notiz: String)

    @Query("UPDATE privatinserate SET erinnerungAt = :at, erinnerungEventId = :eventId WHERE id = :id")
    suspend fun setErinnerung(id: Long, at: Long?, eventId: Long?)

    @Query("DELETE FROM privatinserate WHERE id = :id")
    suspend fun delete(id: Long)
}
