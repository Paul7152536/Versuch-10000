package de.immokarte.anrufkarte.data

data class StatusOption(val key: String, val label: String)

/** Zentrale, einzige Quelle für die Status-Liste — wird von der Kundenliste,
 *  dem Bearbeiten-Bildschirm, der Anruf-Karte und der Statistik-Seite
 *  gemeinsam genutzt, damit sie garantiert nie auseinanderlaufen. */
object StatusInfo {
    // Logische Reihenfolge entlang des Verkaufsverlaufs — von "erster
    // Kontakt" bis "Kunde", Abgelehnt bewusst ganz am Ende (siehe unten).
    val options = listOf(
        StatusOption("potenziell", "Potenzieller Kunde"),
        StatusOption("interessent", "Interessent"),
        StatusOption("besichtigung", "Besichtigung vereinbart"),
        StatusOption("angebot", "Angebot abgegeben"),
        StatusOption("pendent", "Pendent (Entscheidung offen)"),
        StatusOption("abschluss", "Kauf abgeschlossen"),
        StatusOption("kunde", "Kunde"),
        // Ganz am Ende: für die Sortierung/Filter-Reihenfolge bewusst als am
        // wenigsten wichtig eingestuft.
        StatusOption("abgelehnt", "Abgelehnt"),
    )

    val keys: List<String> = options.map { it.key }
    val labels: List<String> = options.map { it.label }
    private val labelByKey: Map<String, String> = options.associate { it.key to it.label }

    /** Sortier-Rang je Status: Kunde zuerst, dann Interessent, dann der Rest
     *  in der obigen Reihenfolge, Abgelehnt ganz zuletzt. Wird für die
     *  Sortierung der Kontaktliste ("Alle") genutzt. */
    private val sortRank: Map<String, Int> = options.withIndex().associate { (i, o) -> o.key to i }
    fun sortIndex(key: String): Int = sortRank[key] ?: options.size

    /** Status, bei denen der Kontakt nicht mehr aktiv "in Bearbeitung" ist —
     *  wird für Filter/Vorschläge genutzt, die nur offene Fälle zeigen sollen. */
    val closedStatuses = setOf("kunde", "abgelehnt", "abschluss")

    fun label(key: String): String = labelByKey[key] ?: key

    /** Eine Farbe je Status — für die kleinen Farbpunkte in der Kontaktliste,
     *  auf einen Blick erfassbar statt den Text lesen zu müssen. */
    fun color(key: String): Int = when (key) {
        "potenziell" -> 0xFF5DCAA5.toInt()   // Türkis — noch ganz am Anfang
        "kunde" -> 0xFF97C459.toInt()        // Grün — schon Kunde
        "interessent" -> 0xFFEF9F27.toInt()  // Orange
        "besichtigung" -> 0xFFA9823D.toInt() // Messing
        "angebot" -> 0xFFEF9F27.toInt()      // Orange
        "pendent" -> 0xFFEAB308.toInt()      // Gelb — Entscheidung offen
        "abgelehnt" -> 0xFF8C3B2B.toInt()    // Rotbraun
        "abschluss" -> 0xFFAFA9EC.toInt()    // Violett — abgeschlossen
        else -> 0xFF8A8A8A.toInt()
    }
}
