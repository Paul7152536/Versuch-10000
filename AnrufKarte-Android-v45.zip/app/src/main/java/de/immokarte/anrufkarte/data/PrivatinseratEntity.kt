package de.immokarte.anrufkarte.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Ein aus einer Zeitungs-/Kleinanzeige erfasstes privates Inserat — zum
 * Nachverfolgen und ggf. Kontaktieren des Anbieters. Felder entsprechen dem
 * Schema Name/Objekt/Lage/Preis/Telefon/E-Mail/Eingestellt am/Privat
 * eindeutig(🟢)-oder-unklar(🟡).
 */
@Entity(tableName = "privatinserate")
data class PrivatinseratEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",         // Name des Anbieters (Eigentümer/potenzieller Kunde)
    val objekt: String = "",       // z. B. "118 m², 5 Zimmer, Bj. 2005, Doppelgarage, Garten"
    val lage: String = "",         // z. B. "Bayern / bei Passau"
    val preis: String = "",        // frei, z. B. "525.000 €"
    val telefon: String = "",
    val email: String = "",
    val eingestelltAt: Long? = null, // Datum aus der Anzeige ("Eingestellt am")
    val privatStatus: String = "", // "" (noch nicht eingeschätzt) | "eindeutig" (🟢) | "unklar" (🟡)
    val erfasstAt: Long = System.currentTimeMillis(), // wann DU es eingetragen hast
    val notiz: String = "",        // eigene Notiz/Verlauf zum Kontaktversuch
    val kontaktiert: Boolean = false,
    val erinnerungAt: Long? = null,       // optionaler Kalender-Termin "kontaktieren am..."
    val erinnerungEventId: Long? = null
)
