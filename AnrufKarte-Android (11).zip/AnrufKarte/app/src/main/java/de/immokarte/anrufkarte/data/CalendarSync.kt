package de.immokarte.anrufkarte.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.TimeZone

data class CalendarChoice(val id: Long, val displayName: String, val accountName: String)

/**
 * Legt für Wiedervorlagen, Vertragstermine und Besichtigungen automatisch
 * einen Kalender-Termin an, aktualisiert ihn bei Änderungen oder löscht ihn,
 * wenn das Datum entfernt wird. Nutzt bei mehreren Konten/Kalendern auf dem
 * Gerät bevorzugt den in den Einstellungen gewählten Kalender — sonst den
 * ersten beschreibbaren (bevorzugt "primär" markierten).
 */
object CalendarSync {

    private const val PREFS = "anruf_karte_prefs"
    private const val KEY_CALENDAR_ID = "selected_calendar_id"
    private const val KEY_EVENT_COLOR = "calendar_event_color"

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    /** Listet alle beschreibbaren Kalender des Geräts (über alle Konten hinweg)
     *  für die Auswahl in den Einstellungen. */
    fun listCalendars(context: Context): List<CalendarChoice> {
        if (!hasPermission(context)) return emptyList()
        val result = mutableListOf<CalendarChoice>()
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
        )
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val level = cursor.getInt(3)
                if (level >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                    result += CalendarChoice(
                        id = cursor.getLong(0),
                        displayName = cursor.getString(1) ?: "Kalender",
                        accountName = cursor.getString(2) ?: ""
                    )
                }
            }
        }
        return result
    }

    private fun findDefaultCalendarId(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.IS_PRIMARY
        )
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            var fallback: Long? = null
            while (cursor.moveToNext()) {
                val level = cursor.getInt(1)
                if (level >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                    val id = cursor.getLong(0)
                    val isPrimary = runCatching { cursor.getInt(2) == 1 }.getOrDefault(false)
                    if (isPrimary) return id
                    if (fallback == null) fallback = id
                }
            }
            return fallback
        }
        return null
    }

    /** Bevorzugt den in den Einstellungen ausgewählten Kalender, sonst automatische Erkennung. */
    private fun resolveCalendarId(context: Context): Long? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val selected = prefs.getLong(KEY_CALENDAR_ID, -1L)
        if (selected > 0) {
            // Prüfen, ob der gewählte Kalender noch existiert (Konto könnte entfernt worden sein)
            val stillExists = listCalendars(context).any { it.id == selected }
            if (stillExists) return selected
        }
        return findDefaultCalendarId(context)
    }

    private fun preferredEventColor(context: Context): Int? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val hex = prefs.getString(KEY_EVENT_COLOR, "") ?: ""
        if (hex.isBlank()) return null
        return runCatching { Color.parseColor(hex) }.getOrNull()
    }

    private fun eventExists(context: Context, eventId: Long): Boolean {
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        return context.contentResolver.query(uri, arrayOf(CalendarContract.Events._ID), null, null, null)
            ?.use { it.moveToFirst() } ?: false
    }

    /** Erstellt/aktualisiert/löscht einen Termin. startAt/endAt in Millisekunden;
     *  wenn startAt null ist, wird ein vorhandener Termin gelöscht. */
    fun syncEvent(context: Context, existingEventId: Long?, title: String, description: String, startAt: Long?, endAt: Long?): Long? {
        if (!hasPermission(context)) return existingEventId

        if (startAt == null) {
            existingEventId?.let { deleteEvent(context, it) }
            return null
        }

        val calendarId = resolveCalendarId(context) ?: return existingEventId
        val end = endAt ?: (startAt + 30 * 60 * 1000L)

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startAt)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            preferredEventColor(context)?.let { put(CalendarContract.Events.EVENT_COLOR, it) }
        }

        return if (existingEventId != null && eventExists(context, existingEventId)) {
            runCatching {
                context.contentResolver.update(
                    ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingEventId), values, null, null
                )
            }
            existingEventId
        } else {
            runCatching {
                context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)?.lastPathSegment?.toLongOrNull()
            }.getOrNull()
        }
    }

    /** Praktischer Alias für ganztägige/9-Uhr-Termine (Wiedervorlage, Vertragstermin). */
    fun syncFollowUp(context: Context, existingEventId: Long?, name: String, phone: String, dateAt: Long?): Long? {
        val start = dateAt?.plus(9 * 60 * 60 * 1000L)
        return syncEvent(context, existingEventId, "Wiedervorlage: $name", "Anruf-Karte — $phone", start, start?.plus(30 * 60 * 1000L))
    }

    fun deleteEvent(context: Context, eventId: Long) {
        if (!hasPermission(context)) return
        runCatching {
            context.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null)
        }
    }
}
