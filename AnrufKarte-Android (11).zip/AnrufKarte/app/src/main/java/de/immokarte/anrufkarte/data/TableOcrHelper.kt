package de.immokarte.anrufkarte.data

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class TableRow(
    val statusRaw: String,
    val name: String,
    val phone: String,
    val objekt: String
)

/**
 * Erkennt tabellarische Kontaktlisten (Status | Name | Telefon | Objekt),
 * wie sie z. B. aus dem Betterhomes-CRM abfotografiert werden. Nutzt die
 * Telefonnummer als verlässlichen Zeilen-Anker — jede Zeile hat garantiert
 * genau eine Nummer, unabhängig davon, wie viele Zeilen Name/Objekt durch
 * Zeilenumbruch belegen — und ordnet die übrigen erkannten Textzeilen
 * anhand ihrer horizontalen Position den Spalten Status/Name/Objekt zu.
 *
 * Diese Zuordnung ist eine Heuristik auf Basis der Textposition im Bild —
 * bei unüblichen Layouts oder schrägen Fotos kann sie danebenliegen, daher
 * zeigt die App die erkannten Zeilen immer erst zur Prüfung an, bevor
 * etwas gespeichert wird.
 */
object TableOcrHelper {

    private val phoneRegex = Regex("""(\+?\d[\d\s\-/()]{7,}\d)""")

    private val statusSynonyms = mapOf(
        "pendent" to "pendent",
        "interessent" to "interessent",
        "besichtigung" to "besichtigung",
        "besichtigung vereinbart" to "besichtigung",
        "kunde" to "kunde",
        "abgelehnt" to "abgelehnt",
        "abschluss" to "abschluss",
        "kauf abgeschlossen" to "abschluss",
        "angebot" to "angebot",
        "angebot abgegeben" to "angebot",
    )

    /** Ordnet den erkannten Status-Text einem App-Status zu, falls möglich.
     *  Sonst bleibt der Status auf "Interessent" und der Originaltext wird
     *  als Tag zurückgegeben (z. B. "Wiedervorlage"), damit nichts verloren geht. */
    fun resolveStatus(raw: String): Pair<String, String?> {
        val key = raw.trim().lowercase()
        val matched = statusSynonyms[key]
        return if (matched != null) matched to null else "interessent" to raw.trim().ifBlank { null }
    }

    /** Liefert eine leere Liste, wenn keine Tabelle mit Name- und
     *  Telefon-Kopfzeile erkannt wurde (dann sollte der Aufrufer auf die
     *  Einzelkontakt-Erkennung zurückfallen). */
    suspend fun parseTable(bitmap: Bitmap): List<TableRow> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val result = recognizer.process(image).await()

        val lines = result.textBlocks.flatMap { it.lines }
            .mapNotNull { line -> line.boundingBox?.let { box -> Pair(line.text.trim(), box) } }
            .filter { it.first.isNotBlank() }
        if (lines.isEmpty()) return emptyList()

        var statusX: Int? = null
        var nameX: Int? = null
        var telefonX: Int? = null
        var objektX: Int? = null
        var headerBottom = 0

        lines.forEach { (text, box) ->
            val t = text.lowercase()
            when {
                t.contains("status") && statusX == null -> { statusX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("name") && nameX == null -> { nameX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("telefon") && telefonX == null -> { telefonX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("objekt") && objektX == null -> { objektX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
            }
        }

        // Ohne erkennbare Name- und Telefon-Spalte lohnt sich der Tabellenmodus nicht.
        val nX = nameX ?: return emptyList()
        val tX = telefonX ?: return emptyList()
        val sX = statusX ?: 0
        val oX = objektX ?: (tX + 300)

        val dataLines = lines.filter { it.second.top > headerBottom }
        val heights = dataLines.map { it.second.height() }.sorted()
        val lineHeight = if (heights.isNotEmpty()) heights[heights.size / 2] else 40

        val phoneLines = dataLines
            .filter { phoneRegex.containsMatchIn(it.first) && it.second.left >= tX - lineHeight }
            .sortedBy { it.second.top }

        val rows = mutableListOf<TableRow>()
        phoneLines.forEach { (phoneText, phoneBox) ->
            val bandTop = phoneBox.top - (lineHeight * 1.3).toInt()
            val bandBottom = phoneBox.bottom + (lineHeight * 1.3).toInt()

            fun cellText(colStart: Int, colEnd: Int?): String =
                dataLines.filter {
                    it.second.top in bandTop..bandBottom &&
                        it.second.left >= colStart &&
                        (colEnd == null || it.second.left < colEnd) &&
                        !phoneRegex.containsMatchIn(it.first)
                }.sortedBy { it.second.top }.joinToString(" ") { it.first }.trim()

            val statusText = cellText(sX, nX)
            val nameText = cellText(nX, tX)
            val objektText = cellText(oX, null)
            val phoneMatch = phoneRegex.find(phoneText)?.value?.trim() ?: phoneText

            if (nameText.isNotBlank() && phoneMatch.isNotBlank()) {
                rows += TableRow(statusRaw = statusText, name = nameText, phone = phoneMatch, objekt = objektText)
            }
        }

        return rows
    }
}
