package de.immokarte.anrufkarte.data

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import android.view.ContextThemeWrapper
import de.immokarte.anrufkarte.R

/** Verwaltet die drei wählbaren App-Designs (Modern Minimal / Dark
 *  Professional / Warm & Freundlich). Jede Activity ruft applyTheme() vor
 *  setContentView() auf; der OverlayService (kein Activity-Kontext) nutzt
 *  themedContext(), um sein Layout im passenden Design einzufärben. */
object ThemeManager {
    private const val PREFS = "anruf_karte_prefs"
    private const val KEY = "app_theme"

    const val MINIMAL = "minimal"
    const val DARK = "dark"
    const val WARM = "warm"
    const val ANTHRACITE = "anthracite"

    val options = listOf(
        ANTHRACITE to "Anruf-Karte (Standard)",
        MINIMAL to "Modern Minimal",
        DARK to "Dark Professional",
        WARM to "Warm & Freundlich",
    )

    fun current(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY, ANTHRACITE) ?: ANTHRACITE
    }

    fun setTheme(context: Context, theme: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, theme).apply()
    }

    private fun styleResFor(theme: String): Int = when (theme) {
        DARK -> R.style.Theme_AnrufKarte_Dark
        WARM -> R.style.Theme_AnrufKarte_Warm
        MINIMAL -> R.style.Theme_AnrufKarte_Minimal
        else -> R.style.Theme_AnrufKarte_Anthracite
    }

    /** In jeder Activity direkt nach super.onCreate() und vor setContentView() aufrufen. */
    fun applyTheme(activity: Activity) {
        activity.setTheme(styleResFor(current(activity)))
    }

    /** Für Kontexte ohne eigenes Activity-Theme (z. B. den OverlayService). */
    fun themedContext(context: Context): Context =
        ContextThemeWrapper(context, styleResFor(current(context)))

    /** Löst eine Theme-Farbe zur Laufzeit auf — für die wenigen Stellen, an
     *  denen Farben direkt im Kotlin-Code gesetzt werden (nicht per XML). */
    fun resolveColor(context: Context, attrResId: Int): Int {
        val themed = themedContext(context)
        val typedValue = TypedValue()
        themed.theme.resolveAttribute(attrResId, typedValue, true)
        return typedValue.data
    }
}
