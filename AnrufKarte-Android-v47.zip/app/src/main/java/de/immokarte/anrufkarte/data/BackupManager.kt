package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Sichert/liest alle Kontakte inkl. Objekte UND die "portablen"
 *  Einstellungen (Links, Design, eigene Vorlagen, Erinnerungs-Schalter) als
 *  lesbare JSON-Datei — dient als lokales Backup (kein Cloud-Abgleich).
 *
 *  WICHTIG: Jedes neue Feld auf CustomerEntity/PropertyEntity muss hier in
 *  BEIDEN Richtungen (export UND import) ergänzt werden — sonst geht es
 *  bei einem Sichern/Wiederherstellen-Zyklus unbemerkt verloren. Gleiches
 *  gilt für neue "portable" Einstellungen — bei SETTINGS_KEYS ergänzen.
 *
 *  Bewusst NICHT gesichert: Kalender-ID, SIM-Zuordnung, der Kalender-
 *  Termin-ID-Zwischenspeicher — die sind geräte-/SIM-spezifisch und würden
 *  auf einem anderen Gerät oder nach einem SIM-Wechsel ins Leere zeigen. */
object BackupManager {

    /** Einstellungen, die auf jedem Gerät sinnvoll sind (im Gegensatz zu
     *  Kalender-ID/SIM-Zuordnung, die geräte-spezifisch bleiben). */
    private val SETTINGS_STRING_KEYS = listOf(
        "google_review_link", "trustpilot_link", "referral_link", "catalog_link",
        "calendar_event_color", "app_theme", "overlay_design", "custom_message_templates"
    )
    private val SETTINGS_BOOL_KEYS = listOf(
        "reminder_viewing_enabled", "reminder_shooting_enabled", "reminder_contract_enabled",
        "reminder_holiday_enabled", "reminder_conflict_enabled"
    )
    private val SETTINGS_LONG_KEYS = listOf("vertretung_until")

    private fun optLongOrNull(o: JSONObject, key: String): Long? =
        if (o.isNull(key) || !o.has(key)) null else o.optLong(key)

    fun export(context: Context, uri: Uri, customers: List<CustomerWithProperties>, privatinserate: List<PrivatinseratEntity> = emptyList()) {
        val arr = JSONArray()
        customers.forEach { cwp ->
            val c = cwp.customer
            val o = JSONObject()
            o.put("name", c.name)
            o.put("anrede", c.anrede)
            o.put("phone", c.phone)
            o.put("phone2", c.phone2)
            o.put("email", c.email)
            o.put("notes", c.notes)
            o.put("noteLog", c.noteLog)
            o.put("status", c.status)
            o.put("followUpAt", c.followUpAt ?: JSONObject.NULL)
            o.put("followUpReason", c.followUpReason)
            o.put("followUpConfirmed", c.followUpConfirmed)
            o.put("important", c.important)
            o.put("missedCalls", c.missedCalls)
            o.put("lastContactAt", c.lastContactAt ?: JSONObject.NULL)
            o.put("tags", c.tags)
            o.put("anniversaryAt", c.anniversaryAt ?: JSONObject.NULL)
            o.put("anniversaryConfirmed", c.anniversaryConfirmed)
            o.put("provision", c.provision)
            o.put("referredByName", customers.firstOrNull { it.customer.id == c.referredById }?.customer?.name ?: JSONObject.NULL)
            o.put("reachability", c.reachability)
            o.put("abschlussAt", c.abschlussAt ?: JSONObject.NULL)
            o.put("searchOrt", c.searchOrt)
            o.put("budgetMax", c.budgetMax)
            o.put("contractDateAt", c.contractDateAt ?: JSONObject.NULL)
            o.put("contractConfirmed", c.contractConfirmed)
            o.put("preferredLanguage", c.preferredLanguage)
            o.put("viewingAt", c.viewingAt ?: JSONObject.NULL)
            o.put("viewingConfirmed", c.viewingConfirmed)
            o.put("viewingCalNote", c.viewingCalNote)
            o.put("viewingInteressenten", c.viewingInteressenten)
            o.put("shootingAt", c.shootingAt ?: JSONObject.NULL)
            o.put("shootingConfirmed", c.shootingConfirmed)
            o.put("shootingCalNote", c.shootingCalNote)
            val props = JSONArray()
            cwp.properties.forEach { p ->
                val po = JSONObject()
                po.put("typ", p.typ); po.put("adresse", p.adresse); po.put("ort", p.ort); po.put("plz", p.plz); po.put("preis", p.preis)
                po.put("status", p.status); po.put("verkaufspreis", p.verkaufspreis); po.put("exposeUri", p.exposeUri)
                props.put(po)
            }
            o.put("properties", props)
            arr.put(o)
        }

        val privArr = JSONArray()
        privatinserate.forEach { p ->
            val po = JSONObject()
            po.put("name", p.name); po.put("objekt", p.objekt); po.put("lage", p.lage); po.put("preis", p.preis)
            po.put("telefon", p.telefon); po.put("email", p.email)
            po.put("eingestelltAt", p.eingestelltAt ?: JSONObject.NULL)
            po.put("privatStatus", p.privatStatus)
            po.put("erfasstAt", p.erfasstAt)
            po.put("notiz", p.notiz)
            po.put("kontaktiert", p.kontaktiert)
            po.put("erinnerungAt", p.erinnerungAt ?: JSONObject.NULL)
            privArr.put(po)
        }

        val settings = JSONObject()
        val prefs = context.getSharedPreferences("anruf_karte_prefs", Context.MODE_PRIVATE)
        SETTINGS_STRING_KEYS.forEach { key -> prefs.getString(key, null)?.let { settings.put(key, it) } }
        SETTINGS_BOOL_KEYS.forEach { key -> settings.put(key, prefs.getBoolean(key, true)) }
        SETTINGS_LONG_KEYS.forEach { key -> if (prefs.contains(key)) settings.put(key, prefs.getLong(key, 0)) }

        val root = JSONObject()
        root.put("customers", arr)
        root.put("privatinserate", privArr)
        root.put("settings", settings)
        context.contentResolver.openOutputStream(uri)?.use { it.write(root.toString(2).toByteArray()) }
    }

    suspend fun import(context: Context, uri: Uri, dao: CustomerDao, privatinseratDao: PrivatinseratDao? = null): Int {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return 0
        // Ältere Backups (vor dieser Version) sind ein reines Array ohne
        // Einstellungen — weiterhin lesbar, nur ohne Einstellungs-Wiederherstellung.
        val trimmed = text.trim()
        val root = if (trimmed.startsWith("[")) JSONObject().put("customers", JSONArray(trimmed)) else JSONObject(trimmed)
        val arr = root.getJSONArray("customers")

        if (root.has("settings")) {
            val settings = root.getJSONObject("settings")
            val prefs = context.getSharedPreferences("anruf_karte_prefs", Context.MODE_PRIVATE)
            val editor = prefs.edit()
            SETTINGS_STRING_KEYS.forEach { key -> if (settings.has(key)) editor.putString(key, settings.optString(key)) }
            SETTINGS_BOOL_KEYS.forEach { key -> if (settings.has(key)) editor.putBoolean(key, settings.optBoolean(key, true)) }
            SETTINGS_LONG_KEYS.forEach { key -> if (settings.has(key)) editor.putLong(key, settings.optLong(key)) }
            editor.apply()
        }

        // Empfehler werden über den Namen aufgelöst (IDs können sich zwischen
        // Installationen unterscheiden) — deshalb zuerst alle Kontakte anlegen,
        // dann in einem zweiten Durchlauf die Empfehler-Verknüpfung setzen.
        val referrerNameByNewId = mutableMapOf<Long, String>()

        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val normalized = PhoneUtils.normalize(o.optString("phone"))
            val phone2 = o.optString("phone2", "")
            val normalized2 = if (phone2.isNotBlank()) PhoneUtils.normalize(phone2) else ""
            val existingId = dao.findIdByPhone(normalized)
            val id = dao.insertCustomer(
                CustomerEntity(
                    id = existingId ?: 0,
                    name = o.optString("name"),
                    anrede = o.optString("anrede", ""),
                    phone = o.optString("phone"),
                    phoneNormalized = normalized,
                    phone2 = phone2,
                    phone2Normalized = normalized2,
                    email = o.optString("email", ""),
                    notes = o.optString("notes", ""),
                    noteLog = o.optString("noteLog", ""),
                    status = o.optString("status", "interessent"),
                    followUpAt = optLongOrNull(o, "followUpAt"),
                    followUpReason = o.optString("followUpReason", ""),
                    followUpConfirmed = o.optBoolean("followUpConfirmed", false),
                    important = o.optBoolean("important", false),
                    missedCalls = o.optInt("missedCalls", 0),
                    lastContactAt = optLongOrNull(o, "lastContactAt"),
                    tags = o.optString("tags", ""),
                    anniversaryAt = optLongOrNull(o, "anniversaryAt"),
                    anniversaryConfirmed = o.optBoolean("anniversaryConfirmed", false),
                    provision = o.optString("provision", ""),
                    reachability = o.optString("reachability", ""),
                    abschlussAt = optLongOrNull(o, "abschlussAt"),
                    searchOrt = o.optString("searchOrt", ""),
                    budgetMax = o.optString("budgetMax", ""),
                    contractDateAt = optLongOrNull(o, "contractDateAt"),
                    contractConfirmed = o.optBoolean("contractConfirmed", false),
                    preferredLanguage = o.optString("preferredLanguage", "de"),
                    viewingAt = optLongOrNull(o, "viewingAt"),
                    viewingConfirmed = o.optBoolean("viewingConfirmed", false),
                    viewingCalNote = o.optString("viewingCalNote", ""),
                    viewingInteressenten = o.optString("viewingInteressenten", ""),
                    shootingAt = optLongOrNull(o, "shootingAt"),
                    shootingConfirmed = o.optBoolean("shootingConfirmed", false),
                    shootingCalNote = o.optString("shootingCalNote", "")
                )
            )
            if (!o.isNull("referredByName") && o.has("referredByName")) {
                referrerNameByNewId[id] = o.optString("referredByName")
            }

            dao.deletePropertiesForCustomer(id)
            val props = o.optJSONArray("properties") ?: JSONArray()
            val propertyList = mutableListOf<PropertyEntity>()
            for (j in 0 until props.length()) {
                val po = props.getJSONObject(j)
                propertyList += PropertyEntity(
                    customerId = id, typ = po.optString("typ", "Wohnung"),
                    adresse = po.optString("adresse", ""), ort = po.optString("ort", ""), plz = po.optString("plz", ""),
                    preis = po.optString("preis", ""),
                    status = po.optString("status", "interessiert"),
                    verkaufspreis = po.optString("verkaufspreis", ""),
                    exposeUri = po.optString("exposeUri", "")
                )
            }
            if (propertyList.isNotEmpty()) dao.insertProperties(propertyList)
        }

        // Zweiter Durchlauf: Empfehler-Namen zu den (jetzt bekannten) IDs auflösen.
        if (referrerNameByNewId.isNotEmpty()) {
            val allByName = dao.getAllWithProperties().associateBy { it.customer.name }
            referrerNameByNewId.forEach { (customerId, referrerName) ->
                val referrer = allByName[referrerName]
                if (referrer != null) dao.setReferredBy(customerId, referrer.customer.id)
            }
        }

        // Privatinserate — eigener Bereich, unabhängig von den Kontakten.
        if (privatinseratDao != null && root.has("privatinserate")) {
            val privArr = root.getJSONArray("privatinserate")
            for (i in 0 until privArr.length()) {
                val po = privArr.getJSONObject(i)
                privatinseratDao.upsert(
                    PrivatinseratEntity(
                        name = po.optString("name", ""),
                        objekt = po.optString("objekt", ""),
                        lage = po.optString("lage", ""),
                        preis = po.optString("preis", ""),
                        telefon = po.optString("telefon", ""),
                        email = po.optString("email", ""),
                        eingestelltAt = optLongOrNull(po, "eingestelltAt"),
                        privatStatus = po.optString("privatStatus", ""),
                        erfasstAt = po.optLong("erfasstAt", System.currentTimeMillis()),
                        notiz = po.optString("notiz", ""),
                        kontaktiert = po.optBoolean("kontaktiert", false),
                        erinnerungAt = optLongOrNull(po, "erinnerungAt")
                    )
                )
            }
        }

        return arr.length()
    }
}
