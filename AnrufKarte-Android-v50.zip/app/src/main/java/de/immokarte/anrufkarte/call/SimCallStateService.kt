package de.immokarte.anrufkarte.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.data.MultiSimHelper

/**
 * Hört durchgehend auf den Anruf-Status JEDER aktiven SIM EINZELN (statt nur
 * auf das allgemeine "es klingelt"-Signal), um zuverlässig zu bestimmen,
 * welche SIM angerufen wurde. Die einfache Methode über Zusatzfelder im
 * "es klingelt"-Signal ist auf modernen Android-Geräten (bestätigt getestet
 * auf einem Samsung S23 Ultra) nicht zuverlässig verfügbar — das hier ist
 * der offiziell vorgesehene, robuste Weg dafür.
 *
 * Läuft nur, solange unter "Overlay nur für bestimmte SIM" eine Geschäfts-SIM
 * eingerichtet ist (siehe MainActivity.showSimPickerDialog) — dafür verlangt
 * Android ein dauerhaftes, aber möglichst unaufdringliches Benachrichtigungssymbol.
 */
class SimCallStateService : Service() {

    companion object {
        @Volatile private var lastRingingSubId: Int = -1
        @Volatile private var lastRingingAt: Long = 0L

        private const val CHANNEL_ID = "sim_watcher"
        private const val NOTIF_ID = 3001

        private fun recordRinging(subId: Int) {
            lastRingingSubId = subId
            lastRingingAt = System.currentTimeMillis()
        }

        /** Liefert die Subscription-ID der zuletzt geklingelten SIM — nur,
         *  wenn das innerhalb der letzten Sekunden geschah (verhindert, dass
         *  ein veralteter Wert für einen neuen Anruf verwendet wird). Etwas
         *  großzügiger als früher (8 statt 4 Sekunden), da knappe Fenster in
         *  der Praxis öfter mal knapp verpasst wurden, wenn die Zustellung
         *  des Broadcasts durch Android etwas verzögert war.  */
        fun currentRingingSubId(): Int =
            if (System.currentTimeMillis() - lastRingingAt < 8000) lastRingingSubId else -1
    }

    private val listeners = mutableListOf<Pair<TelephonyManager, PhoneStateListener>>()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        registerListeners()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (listeners.isEmpty()) registerListeners()
        return START_STICKY
    }

    private fun registerListeners() {
        unregisterListeners()
        val sims = MultiSimHelper.listSims(this)
        val baseTm = getSystemService(TELEPHONY_SERVICE) as? TelephonyManager ?: return
        sims.forEach { sim ->
            runCatching {
                val tmForSub = baseTm.createForSubscriptionId(sim.subscriptionId)
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        if (state == TelephonyManager.CALL_STATE_RINGING) {
                            recordRinging(sim.subscriptionId)
                        }
                    }
                }
                @Suppress("DEPRECATION")
                tmForSub.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
                listeners += tmForSub to listener
            }
        }
    }

    private fun unregisterListeners() {
        listeners.forEach { (tm, listener) ->
            @Suppress("DEPRECATION")
            runCatching { tm.listen(listener, PhoneStateListener.LISTEN_NONE) }
        }
        listeners.clear()
    }

    override fun onDestroy() {
        unregisterListeners()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val subId = prefs.getInt("overlay_sim_subscription_id", -1)
        val nickname = if (subId >= 0) prefs.getString("sim_nickname_$subId", "").orEmpty() else ""
        val text = if (nickname.isNotBlank()) "Aktiv für: $nickname" else "Nötig, damit die Karte nur bei der Geschäfts-SIM erscheint"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Anruf-Karte: SIM-Erkennung aktiv")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "SIM-Erkennung (dauerhaft)", NotificationManager.IMPORTANCE_MIN)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
