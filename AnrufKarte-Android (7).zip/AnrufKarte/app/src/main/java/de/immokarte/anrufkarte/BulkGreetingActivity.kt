package de.immokarte.anrufkarte

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.WhatsAppTemplates
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Liste aller offenen Kontakte (nicht "Kauf abgeschlossen") mit gewählter
 * Vorlage. WhatsApp erlaubt keinen echten Massenversand per App — daher wird
 * hier Kontakt für Kontakt einzeln der vorausgefüllte Chat geöffnet, du
 * bestätigst den Versand jeweils selbst. Bereits geöffnete Kontakte werden
 * mit einem Häkchen markiert, damit du den Überblick behältst.
 */
class BulkGreetingActivity : AppCompatActivity() {

    private val greetingTemplates = listOf(
        "🎄 Weihnachtsgruß" to "Hallo {name}, ich wünsche Ihnen und Ihren Liebsten ein frohes Weihnachtsfest und einen guten Rutsch ins neue Jahr!",
        "🎆 Neujahrsgruß" to "Hallo {name}, alles Gute für das neue Jahr! Falls sich bei Ihnen etwas in Sachen Immobilien tut, bin ich gerne für Sie da.",
        "☀️ Sommergruß" to "Hallo {name}, ich wünsche Ihnen einen schönen Sommer! Melden Sie sich gerne, falls es Neuigkeiten bei Ihnen gibt.",
    )
    private val sentIds = mutableSetOf<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bulk_greeting)

        val spinner = findViewById<android.widget.Spinner>(R.id.spinnerGreetingTemplate)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, greetingTemplates.map { it.first })

        val container = findViewById<LinearLayout>(R.id.greetingContainer)

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val customers = withContext(Dispatchers.IO) { dao.getAllWithProperties() }
                .filter { it.customer.status != "abschluss" }

            if (customers.isEmpty()) {
                container.addView(TextView(this@BulkGreetingActivity).apply {
                    text = "Keine offenen Kontakte gefunden."
                    setTextColor(0xFF8B93A0.toInt())
                })
                return@launch
            }

            customers.forEach { c ->
                val row = LinearLayout(this@BulkGreetingActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(24, 24, 24, 24)
                    setBackgroundResource(R.drawable.bg_card)
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    params.bottomMargin = 8
                    layoutParams = params
                }
                val tvName = TextView(this@BulkGreetingActivity).apply {
                    text = c.customer.name
                    textSize = 14f
                    setTextColor(0xFF20242B.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvStatus = TextView(this@BulkGreetingActivity).apply {
                    text = if (sentIds.contains(c.customer.id)) "✓ Geöffnet" else "WhatsApp öffnen"
                    textSize = 12f
                    setTextColor(if (sentIds.contains(c.customer.id)) 0xFF3E6B4F.toInt() else 0xFF1E2C3B.toInt())
                }
                row.addView(tvName)
                row.addView(tvStatus)
                row.setOnClickListener {
                    val (_, template) = greetingTemplates[spinner.selectedItemPosition]
                    val digits = c.customer.phone.filter { it.isDigit() }
                    val link = WhatsAppTemplates.buildLink(digits, c.customer.name, template)
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    }
                    sentIds += c.customer.id
                    tvStatus.text = "✓ Geöffnet"
                    tvStatus.setTextColor(0xFF3E6B4F.toInt())
                }
                container.addView(row)
            }
        }
    }
}
