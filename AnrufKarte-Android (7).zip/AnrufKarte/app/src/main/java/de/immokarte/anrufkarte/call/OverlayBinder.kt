package de.immokarte.anrufkarte.call

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import de.immokarte.anrufkarte.R
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.NoteEntry
import de.immokarte.anrufkarte.data.NoteLogUtils
import de.immokarte.anrufkarte.data.WhatsAppTemplates
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

private val STATUS_LABELS = mapOf(
    "interessent" to "Interessent",
    "besichtigung" to "Besichtigung vereinbart",
    "abschluss" to "Kauf abgeschlossen",
)

/** Befüllt das Overlay-Layout (overlay_card.xml) mit den Daten des Treffers
 *  und verdrahtet Schnellaktionen (WhatsApp/E-Mail) sowie das Notizfeld. */
object OverlayBinder {

    fun bind(view: View, rawPhone: String, match: CustomerWithProperties?, scope: CoroutineScope) {
        val tvName = view.findViewById<TextView>(R.id.tvName)
        val tvPhone = view.findViewById<TextView>(R.id.tvPhone)
        val tvReachability = view.findViewById<TextView>(R.id.tvReachability)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvNote = view.findViewById<TextView>(R.id.tvNote)
        val tvMissedCalls = view.findViewById<TextView>(R.id.tvMissedCalls)
        val propsContainer = view.findViewById<LinearLayout>(R.id.propsContainer)
        val btnWhatsApp = view.findViewById<TextView>(R.id.btnWhatsApp)
        val btnEmail = view.findViewById<TextView>(R.id.btnEmail)
        val etQuickNote = view.findViewById<EditText>(R.id.etQuickNote)
        val btnSaveNote = view.findViewById<TextView>(R.id.btnSaveNote)
        val btnQuickNote1 = view.findViewById<TextView>(R.id.btnQuickNote1)
        val btnQuickNote2 = view.findViewById<TextView>(R.id.btnQuickNote2)

        tvPhone.text = rawPhone.ifBlank { "Unbekannte Nummer" }

        if (match == null) {
            tvName.text = "Unbekannter Anrufer"
            tvReachability.visibility = View.GONE
            tvStatus.visibility = View.GONE
            tvNote.visibility = View.GONE
            tvMissedCalls.visibility = View.GONE
            propsContainer.visibility = View.GONE
            btnWhatsApp.visibility = View.GONE
            btnEmail.visibility = View.GONE
            etQuickNote.visibility = View.GONE
            btnSaveNote.visibility = View.GONE
            btnQuickNote1.visibility = View.GONE
            btnQuickNote2.visibility = View.GONE
            return
        }

        val customer = match.customer
        tvName.text = customer.name

        if (customer.reachability.isNotBlank()) {
            tvReachability.text = "📞 ${customer.reachability}"
            tvReachability.visibility = View.VISIBLE
        } else {
            tvReachability.visibility = View.GONE
        }

        tvStatus.text = STATUS_LABELS[customer.status] ?: customer.status
        tvStatus.visibility = View.VISIBLE

        fun saveQuickNote(text: String) {
            scope.launch {
                withContext(Dispatchers.IO) {
                    val dao = AppDatabase.getInstance(view.context.applicationContext).customerDao()
                    val current = dao.getByIdWithProperties(customer.id)?.customer?.noteLog ?: customer.noteLog
                    val updated = NoteLogUtils.append(current, NoteEntry(System.currentTimeMillis(), text))
                    dao.updateNoteLog(customer.id, updated)
                }
            }
            tvNote.text = "Letzte Notiz: $text"
            tvNote.visibility = View.VISIBLE
        }
        btnQuickNote1.setOnClickListener { saveQuickNote("Kein Interesse mehr") }
        btnQuickNote2.setOnClickListener { saveQuickNote("Rückruf gewünscht") }

        if (customer.missedCalls > 0) {
            tvMissedCalls.text = "${customer.missedCalls} verpasst"
            tvMissedCalls.visibility = View.VISIBLE
        } else {
            tvMissedCalls.visibility = View.GONE
        }

        val lastNote = NoteLogUtils.parse(customer.noteLog).lastOrNull()
        if (lastNote != null) {
            tvNote.text = "Letzte Notiz: ${lastNote.text}"
            tvNote.visibility = View.VISIBLE
        } else if (customer.notes.isNotBlank()) {
            tvNote.text = customer.notes
            tvNote.visibility = View.VISIBLE
        } else {
            tvNote.visibility = View.GONE
        }

        // Schnellaktionen
        val digits = rawPhone.filter { it.isDigit() }
        btnWhatsApp.visibility = View.VISIBLE
        btnWhatsApp.setOnClickListener {
            val prefs = view.context.getSharedPreferences("anruf_karte_prefs", android.content.Context.MODE_PRIVATE)
            val reviewLink = prefs.getString("google_review_link", "").orEmpty()
            val catalogLink = prefs.getString("catalog_link", "").orEmpty()
            val orderedTemplates = WhatsAppTemplates.templatesFor(customer.preferredLanguage)
            val popup = PopupMenu(view.context, btnWhatsApp)
            orderedTemplates.forEachIndexed { i, t -> popup.menu.add(0, i, i, t.label) }
            popup.menu.add(0, -1, orderedTemplates.size, "Ohne Vorlage öffnen")
            popup.setOnMenuItemClickListener { item ->
                val link = if (item.itemId == -1) {
                    WhatsAppTemplates.buildLinkPlain(digits)
                } else {
                    val t = orderedTemplates[item.itemId]
                    WhatsAppTemplates.buildLink(digits, customer.name, t.text, reviewLink, catalogLink)
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { view.context.startActivity(intent) }
                true
            }
            popup.show()
        }
        if (customer.email.isNotBlank()) {
            btnEmail.visibility = View.VISIBLE
            btnEmail.setOnClickListener {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${customer.email}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { view.context.startActivity(intent) }
            }
        } else {
            btnEmail.visibility = View.GONE
        }

        // Notiz während des Anrufs
        etQuickNote.visibility = View.VISIBLE
        btnSaveNote.visibility = View.VISIBLE
        btnSaveNote.setOnClickListener {
            val text = etQuickNote.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            saveQuickNote(text)
            etQuickNote.text.clear()
        }

        propsContainer.removeAllViews()
        if (match.properties.isEmpty()) {
            propsContainer.visibility = View.GONE
            return
        }
        propsContainer.visibility = View.VISIBLE

        val inflater = LayoutInflater.from(view.context)
        val fmt = NumberFormat.getCurrencyInstance(Locale.GERMANY).apply { maximumFractionDigits = 0 }

        val propStatusMarks = mapOf("reserviert" to " · reserviert", "verkauft_vermietet" to " · vergeben")
        match.properties.forEach { p ->
            val row = inflater.inflate(R.layout.overlay_property_row, propsContainer, false)
            row.findViewById<TextView>(R.id.tvPropTitle).text =
                buildString {
                    append(p.typ)
                    if (p.adresse.isNotBlank()) append(" · ").append(p.adresse)
                    append(propStatusMarks[p.status] ?: "")
                }
            row.findViewById<TextView>(R.id.tvPropCity).text = p.ort

            val priceView = row.findViewById<TextView>(R.id.tvPropPrice)
            val price = p.preis.toLongOrNull()
            if (price != null) {
                priceView.text = fmt.format(price)
                priceView.visibility = View.VISIBLE
            } else {
                priceView.visibility = View.GONE
            }
            propsContainer.addView(row)
        }
    }
}
