package de.immokarte.anrufkarte.data

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val STATUS_LABELS = mapOf(
    "interessent" to "Interessent",
    "besichtigung" to "Besichtigung vereinbart",
    "abschluss" to "Kauf abgeschlossen",
)

/** Erzeugt einen einseitigen (bei Bedarf mehrseitigen) PDF-Steckbrief für
 *  einen Kunden inkl. Objekte und Notiz-Verlauf — zum Ausdrucken/Weiterleiten. */
object PdfExporter {

    fun export(context: Context, uri: Uri, data: CustomerWithProperties) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 bei 72dpi
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val titlePaint = Paint().apply { textSize = 22f; isFakeBoldText = true }
        val labelPaint = Paint().apply { textSize = 10f; color = 0xFF8B93A0.toInt() }
        val textPaint = Paint().apply { textSize = 13f }
        val sectionPaint = Paint().apply { textSize = 12f; isFakeBoldText = true; color = 0xFFA9823D.toInt() }

        var y = 50f
        val left = 40f
        val fmt = NumberFormat.getCurrencyInstance(Locale.GERMANY).apply { maximumFractionDigits = 0 }
        val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)

        fun newPageIfNeeded(needed: Float) {
            if (y + needed > 800f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
            }
        }

        canvas.drawText(data.customer.name, left, y, titlePaint); y += 26f
        canvas.drawText(data.customer.phone, left, y, textPaint); y += 18f
        if (data.customer.email.isNotBlank()) { canvas.drawText(data.customer.email, left, y, textPaint); y += 18f }
        canvas.drawText("Status: ${STATUS_LABELS[data.customer.status] ?: data.customer.status}", left, y, textPaint); y += 18f
        if (data.customer.tags.isNotBlank()) { canvas.drawText("Tags: ${data.customer.tags}", left, y, textPaint); y += 18f }
        if (data.customer.followUpAt != null) {
            canvas.drawText("Wiedervorlage: ${dateFmt.format(Date(data.customer.followUpAt))}", left, y, textPaint); y += 18f
        }
        y += 12f

        if (data.properties.isNotEmpty()) {
            newPageIfNeeded(24f)
            canvas.drawText("OBJEKTE", left, y, sectionPaint); y += 18f
            data.properties.forEach { p ->
                newPageIfNeeded(36f)
                canvas.drawText("${p.typ} · ${p.adresse}, ${p.ort}", left, y, textPaint); y += 16f
                val price = p.preis.toLongOrNull()
                if (price != null) { canvas.drawText(fmt.format(price), left, y, labelPaint); y += 16f }
                y += 4f
            }
            y += 8f
        }

        val notes = NoteLogUtils.parse(data.customer.noteLog)
        if (notes.isNotEmpty() || data.customer.notes.isNotBlank()) {
            newPageIfNeeded(24f)
            canvas.drawText("NOTIZEN", left, y, sectionPaint); y += 18f
            if (data.customer.notes.isNotBlank()) {
                newPageIfNeeded(16f)
                canvas.drawText(data.customer.notes, left, y, textPaint); y += 16f
            }
            notes.sortedByDescending { it.timestamp }.forEach { n ->
                newPageIfNeeded(32f)
                canvas.drawText(dateFmt.format(Date(n.timestamp)), left, y, labelPaint); y += 14f
                canvas.drawText(n.text, left, y, textPaint); y += 18f
            }
        }

        document.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
        document.close()
    }
}
