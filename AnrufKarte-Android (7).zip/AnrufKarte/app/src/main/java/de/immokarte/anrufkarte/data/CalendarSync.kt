package de.immokarte.anrufkarte.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.TimeZone

/**
 * Legt für die Wiedervorlage automatisch einen Kalender-Termin an, aktualisiert
 * ihn bei einer Datumsänderung oder löscht ihn, wenn die Wiedervorlage entfernt
 * wird. Schreibt in den ersten beschreibbaren Kalender des Geräts (bevorzugt
 * den als "primär" markierten, z. B. das Hauptkonto).
 */
object CalendarSync {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    private fun findWritableCalendarId(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.IS_PRIMARY
        )
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            var fallback: Long? = null
            while (cursor.moveToNext()) {
                val level = cursor.getInt(1)
                if (level >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                    val id = cursor.getLong(0)
                    val isPrimary = runCatching { cursor.getInt(2) == 1 }.getOrDefault(false)
                    if (isPrimary) return id
                    if (fallback == null) fallback = id
                }
            }
            return fallback
        }
        return null
    }

    private fun eventExists(context: Context, eventId: Long): Boolean {
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        return context.contentResolver.query(uri, arrayOf(CalendarContract.Events._ID), null, null, null)
            ?.use { it.moveToFirst() } ?: false
    }

    /** Erstellt/aktualisiert/löscht den Termin passend zu followUpAt.
     *  Gibt die (ggf. neue) Termin-ID zurück, die dauerhaft am Kontakt gespeichert werden sollte. */
    fun syncFollowUp(context: Context, existingEventId: Long?, name: String, phone: String, followUpAt: Long?): Long? {
        if (!hasPermission(context)) return existingEventId

        if (followUpAt == null) {
            existingEventId?.let { deleteEvent(context, it) }
            return null
        }

        val calendarId = findWritableCalendarId(context) ?: return existingEventId
        val start = followUpAt + 9 * 60 * 60 * 1000L // 9:00 Uhr
        val end = start + 30 * 60 * 1000L

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.TITLE, "Wiedervorlage: $name")
            put(CalendarContract.Events.DESCRIPTION, "Anruf-Karte — $phone")
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }

        return if (existingEventId != null && eventExists(context, existingEventId)) {
            runCatching {
                context.contentResolver.update(
                    ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingEventId), values, null, null
                )
            }
            existingEventId
        } else {
            runCatching {
                context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)?.lastPathSegment?.toLongOrNull()
            }.getOrNull()
        }
    }

    fun deleteEvent(context: Context, eventId: Long) {
        if (!hasPermission(context)) return
        runCatching {
            context.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null)
        }
    }
}
