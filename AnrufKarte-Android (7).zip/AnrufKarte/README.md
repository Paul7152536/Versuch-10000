# Anruf-Karte — Android-Projekt

Zeigt bei einem eingehenden Anruf automatisch eine Karte mit Kunden- und
Objektinformationen über dem Anrufbildschirm an.

## Version 11.1 — Notiz-Verlauf durchsuchbar

Die Suche auf der Startseite durchsucht jetzt zusätzlich zu Name/Telefon/Tags
auch den kompletten Notiz-Verlauf aller Kontakte. Passt eine Notiz zum
Suchbegriff, erscheint direkt in der Liste ein kleiner Ausschnitt darunter
("🔍 in Notiz: …"), auch wenn Name oder Nummer selbst nicht getroffen haben.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 11.0 — neue Funktionen

- **Sprachauswahl pro Kontakt**: neues Feld "Bevorzugte Sprache" beim Kontakt
  (Deutsch/Englisch) — das WhatsApp-Vorlagen-Menü zeigt die passenden
  Vorlagen jetzt automatisch zuerst
- **Rückgängig für die letzte Aktion**: ein Banner erscheint nach dem
  Löschen eines Kontakts, dem Zurücksetzen verpasster Anrufe oder dem
  Verschieben einer Wiedervorlage — antippen macht die letzte dieser
  Aktionen rückgängig (nur die jeweils letzte, kein mehrstufiger Verlauf)
- **Vertretungs-Modus**: neuer 🧑‍🤝‍🧑-Button — bündelt alle als "wichtig"
  markierten Kontakte in einer Datei und öffnet den Teilen-Dialog, damit
  ein Kollege sie in seiner App-Kopie übernehmen kann. Zusätzlich lässt sich
  ein Enddatum als Erinnerungs-Banner setzen ("Vertretung aktiv bis …")

⚠️ Erneute Datenbankänderung (Sprachpräferenz) — bestehende lokale Kontakte
werden beim Update einmalig gelöscht. Vorher über "Sichern" ein Backup
machen, danach über "Wiederherstellen" zurückspielen.

**Wichtig zum Vertretungs-Modus:** Da die App komplett lokal ohne Server
läuft, ist kein echter Fernzugriff für einen Kollegen möglich — die Lösung
ist ein teilbares Datenpaket, das der Kollege selbst in seine eigene
App-Installation einspielt.

## Version 10.0 — neue Funktionen

- **Sammelgruß**: neuer 🎉-Button auf der Startseite — Vorlage wählen
  (Weihnachten/Neujahr/Sommer), dann jeden offenen Kontakt einzeln antippen.
  WhatsApp erlaubt keinen echten Massenversand per App, deshalb öffnet sich
  pro Tipp der vorausgefüllte Chat, du bestätigst den Versand selbst —
  bereits geöffnete Kontakte werden mit ✓ markiert
- **"Wen sollte ich heute anrufen?"**: Beim Öffnen der App schlägt sie jetzt
  proaktiv 1–2 Kontakte vor (Kombination aus wichtig-markiert, fälliger
  Wiedervorlage und lange nicht kontaktiert) — als Banner auf der Startseite,
  antippen öffnet direkt den Kontakt
- **Katalog-Link-Vorlage**: neues Feld unter ⚙️ Einstellungen für einen
  frei wählbaren Link (z. B. dein Betterhomes-Profil, sobald es steht) —
  wird in der WhatsApp-Vorlage "📋 Objektübersicht" eingesetzt

Keine Datenbankänderung in diesem Update — kein erneuter Reset nötig.

## Version 9.0 — neue Funktionen

- **Google-Bewertung anfragen**: neue WhatsApp-Vorlage "⭐ Bewertung erbitten"
  mit deinem Bewertungslink — Link einmal über das ⚙️-Zahnrad auf der
  Startseite hinterlegen
- **Angebotspreis vs. Verkaufspreis**: zweites Preisfeld pro Objekt für den
  tatsächlichen Abschlusspreis — Statistik-Seite zeigt die durchschnittliche
  Differenz
- **Objekt-Matching**: Button "🔍 Interessenten" bei jedem Objekt zeigt
  Kontakte, deren hinterlegter Such-Ort und Budget zum Objekt passen
  (dafür bei Kontakten "Gesucht: Ort" und "Budget bis" eintragen)
- **Anrufdauer automatisch erfassen**: bei beantworteten Anrufen (≥ 5 Sek.)
  landet automatisch ein Eintrag mit Dauer im Notiz-Verlauf
- **Exposé-Datei anhängen**: Button "📎 Exposé" pro Objekt zum Anhängen
  einer PDF-Datei, später direkt aus der App wieder öffnen
- **Vertragstermine als eigene Erinnerung**: separates Datumsfeld z. B. für
  Notartermine, inkl. eigener Benachrichtigung und automatischer
  Kalender-Synchronisation (unabhängig von der Wiedervorlage)

⚠️ Erneute Datenbankänderung — bestehende lokale Kontakte werden beim Update
einmalig gelöscht. Vorher über "Sichern" ein Backup machen, danach über
"Wiederherstellen" zurückspielen.

**Bewusst nicht umgesetzt:** eine echte Umkreissuche mit Kilometer-Radius
würde eine externe Karten-/Geocoding-API mit Internetzugriff erfordern —
das Objekt-Matching sucht stattdessen textbasiert nach dem hinterlegten Ort.

## Version 8.0 — neue Funktionen

- **Kunden-Karte teilen**: Button "Teilen" beim Kontakt exportiert ihn als
  Datei und öffnet den normalen Android-Teilen-Dialog (WhatsApp, E-Mail,
  Drive, …). Ein Kollege mit derselben App kann die Datei direkt öffnen
  ("Öffnen mit Anruf-Karte") — der Kontakt wird automatisch übernommen,
  inklusive Objekte und Notizen
- **Automatische Kalender-Synchronisation**: Jede Wiedervorlage landet jetzt
  von selbst als Termin im Standard-Kalender — Anlegen, Ändern und Löschen
  läuft automatisch mit, sobald du eine Wiedervorlage setzt/änderst/entfernst.
  Der bisherige manuelle "Im Kalender speichern"-Button ist entfallen, da er
  jetzt überflüssig ist
- Dafür ist eine **neue Berechtigung** nötig (Kalender lesen/schreiben) —
  einmal über "Berechtigungen einrichten" erlauben

⚠️ Erneute Datenbankänderung (Kalender-Termin-Verknüpfung) — bestehende
lokale Kontakte werden beim Update einmalig gelöscht. Vorher über "Sichern"
ein Backup machen, danach über "Wiederherstellen" zurückspielen.

## Version 7.0 — neue Funktionen

- **Dubletten-Warnung** jetzt auch beim manuellen Anlegen und beim Foto-Import
  (nicht mehr nur beim CSV-Import): existiert die Nummer schon, kannst du den
  bestehenden Kontakt öffnen oder trotzdem einen neuen anlegen
- **Jahresrückblick** auf der Statistik-Seite: Abschlüsse und Provisionen
  des laufenden Kalenderjahres auf einen Blick
- **Statistik exportieren** als CSV oder PDF (z. B. für Steuerberater/eigene
  Auswertung)
- **Wisch-Aktionen** in der Kundenliste: nach rechts wischen ruft an, nach
  links wischen verschiebt die Wiedervorlage um 1 Woche
- **Englische WhatsApp-Vorlagen** zusätzlich zu den deutschen im selben Menü

⚠️ Erneute Datenbankänderung (Abschluss-Datum für den Jahresrückblick) —
**bestehende lokale Kontakte werden beim Update einmalig gelöscht.** Vorher
über "Sichern" ein Backup machen, danach über "Wiederherstellen" zurückspielen.

## Version 6.0 — Kontakte per Foto anlegen

- Neuer Button **"📷 Aus Foto"** auf der Startseite
- Foto aufnehmen (z. B. CRM-Bildschirm abfotografieren) oder ein
  vorhandenes Foto/Screenshot aus der Galerie wählen
- Die App erkennt Text automatisch auf dem Gerät (Google ML Kit, läuft
  komplett offline, keine Internetverbindung nötig) und versucht, Name,
  Telefonnummer und E-Mail herauszufiltern
- Öffnet danach den normalen "Neuer Kontakt"-Bildschirm mit den erkannten
  Werten vorausgefüllt — **immer kurz prüfen und ggf. korrigieren**, die
  Erkennung ist eine Heuristik und nicht immer perfekt (besonders bei
  unscharfen Fotos oder ungewöhnlichen Layouts)
- Der komplette erkannte Text landet zusätzlich im Notizfeld, falls die
  App etwas Wichtiges nicht automatisch zuordnen konnte

**Tipp für gute Erkennung:** möglichst scharfes, gut ausgeleuchtetes Foto,
Bildschirm möglichst gerade/parallel fotografieren, nicht zu weit weg.

Keine Datenbankänderung in diesem Update — kein erneuter Reset nötig.

## Version 5.0 — neue Funktionen

- **Provisions-Tracking**: Provision pro Abschluss hinterlegen, Gesamtsumme
  auf der Statistik-Seite
- **Empfehlungs-Verknüpfung**: Kontakte können als "empfohlen von" einem
  anderen Kontakt markiert werden — Top-Empfehler-Rangliste auf der
  Statistik-Seite
- **Erreichbarkeits-Notiz**: kurzer Hinweis wie "abends besser erreichbar",
  erscheint direkt auf der Anruf-Karte
- **App-Shortcuts**: langer Druck aufs App-Icon → direkt "Neuer Kontakt"
  oder "CSV importieren"
- **Objekt-Status unabhängig vom Kunden-Status**: jedes Objekt einzeln als
  Interessiert/Reserviert/Verkauft-Vermietet markierbar
- **Backup-Erinnerung**: Hinweis-Banner, falls das letzte Backup länger als
  eine Woche her ist
- **Schnellnotizen-Buttons** auf der Anruf-Karte ("Kein Interesse mehr",
  "Rückruf gewünscht") — ein Tipp genügt

⚠️ Erneute Datenbankänderung (Provision, Empfehlung, Erreichbarkeit,
Objekt-Status) — **bestehende lokale Kontakte werden beim Update einmalig
gelöscht.** Vorher über "Sichern" ein Backup machen, danach über
"Wiederherstellen" zurückspielen.

## Version 4.0 — neue Funktionen

- **Jahrestag-Erinnerung**: Bei Status "Kauf abgeschlossen" wird automatisch —
  zusätzlich zur 1-Monats-Nachfrage — eine Erinnerung nach 12 Monaten gesetzt,
  um sich nach einem Jahr nochmal zu melden
- **Rückruf-Snooze**: Nach einem verpassten Anruf erscheint eine Benachrichtigung
  mit "Anrufen" und "In 1 Std. erinnern" — bei Snooze meldet sich die App
  eine Stunde später erneut
- **WhatsApp-Textvorlagen**: Tippen auf den WhatsApp-Button der Anruf-Karte
  öffnet ein Auswahlmenü mit vorformulierten Nachrichten (Terminbestätigung,
  Rückfrage, Rückruf erbeten, Glückwunsch zum Kauf) — der Name wird automatisch
  eingesetzt, "Ohne Vorlage öffnen" bleibt weiterhin möglich

⚠️ Auch dieses Update ändert die Datenbankstruktur (Jahrestag-Feld) —
**bestehende lokale Kontakte werden beim Update erneut einmalig gelöscht.**
Vorher über "Sichern" ein Backup machen, danach über "Wiederherstellen"
wieder einspielen.

## Version 3.0 — neue Funktionen

- **App-Sperre** per Fingerabdruck/Gesicht/PIN beim Öffnen der App (nutzt die
  Displaysperre deines Handys — kein separates Passwort nötig)
- **Direktanruf** durch Antippen der Telefonnummer in der Kundenliste
- **Kalender-Verknüpfung** — Wiedervorlage per Knopfdruck als Termin in deine
  normale Kalender-App übernehmen
- **Dubletten-Warnung beim CSV-Import** — zeigt Konflikte (gleiche Nummer,
  unterschiedlicher Name) vor dem Import an
- **Freie Tags** pro Kontakt (z. B. "ImmoScout, Empfehlung"), durchsuchbar
- **Statistik-Seite** (📊-Button) mit Kennzahlen auf einen Blick
- **PDF-Steckbrief** pro Kontakt zum Ausdrucken/Weiterleiten
- **Kontakt ins Telefonbuch übernehmen** per Knopfdruck
- **Verpasste Anrufe** mit einem Tipp als gesehen markieren
- Neuer Filter **"Lange nicht kontaktiert"**

⚠️ Auch dieses Update ändert die Datenbankstruktur (Tags-Feld) — **bestehende
lokale Kontakte werden beim Update erneut einmalig gelöscht.** Vorher per
Backup-Funktion sichern (Button "Sichern" auf der Startseite) und danach
wiederherstellen.

### Zur App-Sperre
Es wird die auf dem Handy bereits eingerichtete Displaysperre verwendet
(Fingerabdruck, Gesichtserkennung, PIN, Muster) — es gibt kein separates
App-Passwort. Ist auf dem Handy keine Displaysperre eingerichtet, startet die
App ohne Abfrage.

## Version 2.0 — neue Funktionen

- **Suche & Filter** in der Kundenliste (auch "nur fällige Wiedervorlagen")
- **Status pro Kunde** (Interessent / Besichtigung vereinbart / Kauf abgeschlossen)
- **Wiedervorlage mit echter Erinnerungs-Benachrichtigung** (täglich 8 Uhr geprüft,
  übersteht auch einen Handy-Neustart)
- **Notiz-Verlauf** statt einzelner Notiz — jeder Eintrag mit Zeitstempel
- **Schnellaktionen auf der Anruf-Karte**: WhatsApp & E-Mail direkt aus dem Overlay
- **Notizfeld direkt auf der Anruf-Karte**, sofort während des Gesprächs nutzbar
- **Verpasste Anrufe** werden automatisch gezählt und angezeigt
- **Wichtige Kontakte** (Stern-Markierung) — siehe Hinweis unten zur Nicht-stören-Funktion
- **Backup sichern/wiederherstellen** als Datei (kein Cloud-Abgleich, du behältst die Kontrolle)
- **Homescreen-Widget** mit den heutigen Wiedervorlagen

### Wichtiger Hinweis zum Update
Weil sich die Datenbankstruktur geändert hat, **werden bestehende lokale Kontakte beim
Update einmalig gelöscht**. Am besten vorher die aktuellen Kontakte per CSV oder
manuell notieren und danach neu anlegen bzw. importieren.

### Zur "Wichtiger Kontakt"-Markierung
Die App selbst kann die Nicht-stören-Funktion von Android nicht direkt umgehen — das
kann technisch nur die Standard-Telefon-App. Der Stern markiert den Kontakt aber
oben in der Liste und auf der Anruf-Karte deutlich sichtbar. Für einen echten
Nicht-stören-Durchlass: den Kontakt zusätzlich in den Telefon-Kontakten als
Favorit markieren und unter Einstellungen → Töne & Benachrichtigungen →
Nicht stören → Ausnahmen → "Anrufe von Favoriten zulassen" aktivieren.

### Zum Homescreen-Widget
Nach der Installation lange auf den Homescreen tippen → Widgets → "Anruf-Karte"
auswählen → "Wiedervorlagen heute" platzieren.

## Schnellster Weg zur fertigen APK (ohne Android Studio)

Das Projekt enthält eine automatische Bauanleitung für GitHub. Du brauchst
nur einen Browser und einen kostenlosen GitHub-Account.

1. Auf [github.com](https://github.com) einen kostenlosen Account anlegen
   (falls noch nicht vorhanden).
2. **New repository** klicken, z. B. `anruf-karte` nennen, "Create".
3. Auf der leeren Projektseite auf **"uploading an existing file"**
   klicken und den kompletten Inhalt des entpackten `AnrufKarte`-Ordners
   per Drag & Drop hochladen (inkl. der versteckten `.github`-Mappe —
   ggf. im Datei-Explorer "versteckte Dateien anzeigen" aktivieren).
   Danach **"Commit changes"**.
4. Oben im Repository auf den Reiter **"Actions"** klicken.
5. Den Workflow **"APK bauen"** auswählen → Button **"Run workflow"** →
   nochmal **"Run workflow"** bestätigen.
6. Ca. 3–5 Minuten warten, bis der Lauf ein grünes Häkchen zeigt.
7. Auf den fertigen Lauf klicken, ganz unten bei **"Artifacts"** auf
   **"AnrufKarte-apk"** klicken — lädt eine ZIP-Datei mit der `app-debug.apk`
   herunter.
8. Diese `.apk`-Datei aufs Handy übertragen (z. B. per E-Mail an dich
   selbst, Google Drive oder USB-Kabel) und dort antippen, um sie zu
   installieren. Android fragt beim ersten Mal, ob "Installation aus
   unbekannten Quellen" erlaubt werden soll — das musst du einmalig
   bestätigen (Einstellungen → z. B. für die "Dateien"- oder "Gmail"-App).

Danach ist die App ganz normal auf deinem Handy installiert, ohne dass du
je Android Studio geöffnet hast.

## Projekt öffnen (alternativ: klassisch mit Android Studio)

1. Android Studio installieren (aktuelle Version, "Iguana" oder neuer).
2. **File → Open** → diesen Ordner (`AnrufKarte/`) auswählen.
3. Android Studio synchronisiert Gradle automatisch (dauert beim ersten
   Mal ein paar Minuten, lädt Abhängigkeiten herunter).
4. Handy per USB anschließen (USB-Debugging aktiviert) oder Emulator
   starten, dann auf **Run ▶** klicken.

## Einrichtung nach der Installation

Die App braucht zwei Berechtigungen, die Android aus Datenschutzgründen
nicht automatisch vergibt:

1. **Telefonstatus lesen** — normaler Berechtigungsdialog beim ersten
   Tippen auf „Berechtigungen einrichten".
2. **Über anderen Apps anzeigen** (Overlay) — öffnet die Systemeinstellung
   direkt; muss manuell angeschaltet werden.

Zusätzlich bei manchen Herstellern (Xiaomi, Huawei, Oppo, Samsung mit
strengem Akku-Management) nötig, damit der Hintergrunddienst beim Klingeln
zuverlässig läuft:
- Autostart / Hintergrundaktivität für die App erlauben
- Akkuoptimierung für die App deaktivieren

## Kundendaten importieren

„CSV importieren" antippen und eine Datei mit dieser Kopfzeile wählen
(Reihenfolge der Spalten egal):

```
Name,Telefon,Typ,Adresse,Ort,Preis,Notizen
Anna Beispiel,+49 151 2345678,Wohnung,Musterstraße 1,Berlin,349000,Sucht 3 Zimmer
```

Klingelt danach diese Nummer an, erscheint automatisch die Karte mit
Name, Notizen und Objekt(en).

## Wichtiger Hinweis zum Vertrieb der App

Diese App liest sensible, von Google streng regulierte Berechtigungen
(Telefonstatus, Anrufprotokoll). Für die **private Nutzung** (Installation
direkt über Android Studio / als APK auf dein eigenes Gerät) ist das kein
Problem. Willst du die App später über den **Google Play Store**
veröffentlichen, verlangt Google dafür eine gesonderte Begründung/Freigabe
(„Permissions Declaration Form") — nicht jede App wird dafür zugelassen.
Für den Eigenbedarf als Immobilienmakler ist die direkte Installation der
unkomplizierteste Weg.

## Projektstruktur

```
app/src/main/java/de/immokarte/anrufkarte/
  MainActivity.kt              Kundenliste, Berechtigungen, CSV-Import
  data/                        Room-Datenbank (Kunden + Objekte), CSV-Parser
  call/CallReceiver.kt         Erkennt eingehende Anrufe
  call/OverlayService.kt       Zeigt/entfernt das Overlay-Fenster
  call/OverlayBinder.kt        Befüllt die Karte mit den Kundendaten
  ui/CustomerAdapter.kt        Liste in der App
app/src/main/res/layout/
  overlay_card.xml             Design der Anruf-Karte (Vorschau-Layout)
  activity_main.xml            Haupt-App-Oberfläche
```

## Nächste sinnvolle Ausbaustufen

- Karte antippbar machen → öffnet den vollen Kundendatensatz in der App
- Property-Typ-Icons (Haus/Wohnung) als eigene Vektorgrafiken statt Text
- Eigene Schriftart (Fraunces) einbinden für exakt das Vorschau-Design
- Automatischer Start des Hintergrunddienstes nach Neustart des Handys
