# Anruf-Karte — Android-Projekt

Zeigt bei einem eingehenden Anruf automatisch eine Karte mit Kunden- und
Objektinformationen über dem Anrufbildschirm an.

## Version 15.0 — Wichtiger Bugfix + Icon-Leisten + aufgeräumte Startseite

**🐛 Bugfix:** Die Anruf-Karte blieb bisher fälschlich über die **gesamte
Gesprächsdauer** sichtbar (auch beim Wechsel in andere Apps) — sie
verschwindet jetzt sofort, sobald der Anruf **angenommen** wird, nicht erst
wenn er komplett beendet ist.

**Anruf-Karte:** Die Aktions-Buttons (WhatsApp, E-Mail, Notiz, Wichtig,
Anrufen, Kontakt anlegen) sind jetzt eine einheitliche **Icon-Leiste unten**
statt verstreuter Text-Buttons. Neu dabei: ein **Anrufen-Icon** (vorher gab
es keine Möglichkeit, direkt aus der Karte zurückzurufen) und ein
**Wichtig-Icon** (markiert den Kontakt direkt aus der Karte heraus).

**Startseite aufgeräumt:**
- Einheitliche Icon-Leiste oben: ➕ Kontakt, 📷 Foto, 📄 CSV, 📊 Statistik,
  ⚙️ Einstellungen
- **⚙️ Einstellungen** ist jetzt die zentrale Anlaufstelle für alles
  Einstellungs-Bezogene: Sichern/Wiederherstellen, WhatsApp-Vorlagen-Links,
  Kalenderauswahl, SIM-Auswahl, Sammelgruß, Vertretung — alles an einem Ort
  statt verteilt
- Die Berechtigungs-Anzeige ist jetzt selbst antippbar (öffnet direkt die
  Berechtigungs-Einrichtung), der separate Button ist entfallen
- **Kundenliste übersichtlicher sortiert**: in der Ansicht "Alle" jetzt nach
  Status gruppiert (offene Fälle zuerst, dann Kunde/Abgelehnt/Abschluss),
  innerhalb jeder Gruppe wichtige Kontakte zuerst

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.5 — Automatische Bewertungs-Nachfrage beim Abschluss

Sobald du bei einem Kontakt den Status auf **"Kauf abgeschlossen"** stellst,
fragt die App jetzt direkt: "🎉 Glückwunsch zum Abschluss! Jetzt direkt per
WhatsApp um eine Google-Bewertung bitten?" — bei "Ja" öffnet sich WhatsApp
sofort mit der vorausgefüllten Bewertungs-Vorlage (inkl. deinem hinterlegten
Google-Bewertungslink). Kein Link hinterlegt? Dann wird die Nachfrage
übersprungen mit Hinweis, ihn unter ⚙️ Einstellungen einzutragen.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.4 — Reserveweg: In-App-Banner, wenn App selbst offen ist

Der Grund für das Verdeckt-Werden aus Version 15.3 ist geklärt: Ist die
Anruf-Karte-App selbst gerade geöffnet, wenn ein Anruf reinkommt, kann
Samsungs eigene (kompakte) Anruf-Oberfläche das System-Overlay-Fenster
komplett verdecken — das ist eine harte, nicht umgehbare Systembeschränkung
(keine App kann über echte System-UI-Elemente gezeichnet werden).

Der passende Fix dafür ist kein weiterer Fenster-Trick, sondern ein
**Banner direkt in der App**: Ist Anruf-Karte selbst offen, erscheint jetzt
oben ein dunkler Balken mit Name/Nummer des Anrufers — den kann Samsungs
Oberfläche nicht verdecken, weil er Teil der ohnehin schon sichtbaren App
ist. Bei unbekannten Anrufern antippen öffnet direkt "Neuer Kontakt".

Ist eine ANDERE App offen (WhatsApp, Startbildschirm, …) oder das Handy
gesperrt, funktioniert das bisherige System-Overlay weiterhin normal —
der Banner ist nur die Ergänzung für den speziellen Fall "App ist gerade
offen".

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.3 — SIM-Namen-Bug behoben

- **Bug behoben**: Eigene SIM-Namen wurden bisher unter einem gemeinsamen
  Schlüssel gespeichert — dadurch hat das Umbenennen einer SIM versehentlich
  auch den Namen der anderen überschrieben. Jetzt wird jeder Name eindeutig
  der jeweiligen SIM zugeordnet
- Fenster-Verdeckung bei der Geschäfts-SIM (Samsung-Telefon-Oberfläche
  liegt darüber): dazu unten mehr — das ist vermutlich kein Bug, den ich
  wegcoden kann, sondern eine Systembeschränkung

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.2 — SIM-Namen, Fenster-Verdeckung behoben

- **SIM-Namen unterscheidbar**: Die Auswahl zeigt jetzt zusätzlich den
  Steckplatz an ("Telekom — Steckplatz 1" / "Telekom — Steckplatz 2"),
  falls beide SIMs beim selben Anbieter sind. Nach der Auswahl kannst du
  optional einen eigenen Namen vergeben (z. B. "Geschäftlich") — der
  erscheint dann auch in der dauerhaften Benachrichtigung
- **Fenster-Verdeckung bei Geschäfts-SIM**: Ein bekannter Kniff gegen
  einen Timing-Effekt — das Overlay-Fenster wird jetzt kurz nach dem
  ersten Anzeigen automatisch neu eingefügt, um es zuverlässig vor die
  native Telefon-Oberfläche zu holen, falls die minimal langsamere
  SIM-Erkennung sie kurz gewinnen lässt
- **Kontakte-Icon geprüft**: Verdrahtung und neue Seite nochmal komplett
  durchgesehen, kein Fehler gefunden — bitte mit dieser Version erneut
  testen, ob es jetzt funktioniert

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.1 — Eigene, vollflächige Kontakte-Seite

Das **👥 Kontakte**-Icon öffnet jetzt eine eigene Seite statt nur die
kompakte Liste im Hauptbildschirm zu filtern:

- Größere, luftigere Karten (Name/Telefon/Status deutlich größer als in
  der kompakten Vorschau) — besser lesbar auf einen Blick
- Eigene Suche und eigene Status-Filter, unabhängig vom Hauptbildschirm
- Volle Bildschirmhöhe verfügbar, keine Banner/Icons im Weg
- Der Hauptbildschirm behält seine kompakte Vorschauliste weiterhin für
  den schnellen Überblick

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 15.0 — Icon-Redesign, hängendes Fenster behoben, übersichtlichere Liste

- **Wichtiger Bugfix**: Das Overlay-Fenster verschwindet jetzt sofort, sobald
  du den Anruf annimmst — vorher blieb es fälschlich über die ganze
  Gesprächsdauer sichtbar, auch über anderen Apps
- **Overlay komplett neu gestaltet**: Icon-Leiste unten statt verteilter
  Text-Buttons — Anrufen/WhatsApp/E-Mail/Notiz/Wichtig (bzw. bei unbekannten
  Anrufern nur Anrufen/Anlegen). Notiz-Icon klappt den Notizbereich auf/zu
- **Startbildschirm entschlackt**: einheitliche Icon-Leiste oben
  (Kontakte/Kontakt hinzufügen/Foto/CSV/Statistik/Einstellungen) statt
  verteilter Buttons. "Sichern"/"Wiederherstellen" sowie Sammelgruß,
  Vertretung und SIM-Auswahl sind jetzt im ⚙️-Einstellungen-Dialog
  gebündelt (mit Abschnitts-Überschriften)
- **Kontakte übersichtlicher sortiert**: Liste gruppiert sich jetzt nach
  Status-Fortschritt (offene Fälle wie Interessent/Besichtigung zuerst,
  abgeschlossene/abgelehnte weiter unten) statt nur alphabetisch —
  wichtig markierte Kontakte bleiben immer ganz oben

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 14.3 — Zuverlässige SIM-Erkennung (echter Fix nach Praxistest)

Die einfache Methode von Version 14.1 hat sich beim echten Test auf einem
Samsung S23 Ultra als nicht zuverlässig herausgestellt (Overlay erschien bei
beiden SIMs). Jetzt läuft stattdessen ein **dauerhafter, pro SIM einzeln
lauschender Hintergrunddienst** — die offiziell dafür vorgesehene, robuste
Methode.

- **Neu:** Ein dezentes, dauerhaftes Benachrichtigungssymbol ("Anruf-Karte:
  SIM-Erkennung aktiv") erscheint, sobald unter "📱 Overlay nur für
  bestimmte SIM" eine Geschäfts-SIM ausgewählt ist — das ist auf Android
  zwingend nötig, damit ein Dienst dauerhaft mithören darf. Ohne
  eingerichtete Geschäfts-SIM läuft nichts davon, kein Symbol sichtbar
- Der Dienst startet automatisch beim Auswählen einer SIM, beim App-Start
  und nach einem Geräteneustart; wählst du "Alle Anrufe zeigen (aus)",
  stoppt er wieder komplett
- **Bitte nochmal testen** (dich von beiden Nummern anrufen lassen) — das
  ist jetzt der technisch korrekte Weg, sollte also zuverlässig funktionieren

⚠️ Erneute Datenbankänderung? **Nein** — hier keine Datenbankänderung, aber
diesmal solltest du die App einmal **komplett schließen und neu öffnen**
(oder das Handy neu starten), damit der neue Dienst sauber initialisiert.

## Version 14.2 — Unbekannte Anrufer direkt anlegen (nur bei Geschäfts-SIM)

Ruft eine unbekannte Nummer an, zeigt die Anruf-Karte jetzt einen Button
**"+ Als Kontakt anlegen"** — antippen öffnet direkt den "Neuer
Kontakt"-Bildschirm mit bereits eingetragener Nummer.

**Wichtig:** Dieser Button erscheint **nur**, wenn unter "📱 Overlay nur für
bestimmte SIM" eine Geschäfts-SIM eingerichtet ist UND der Anruf ihr sicher
zugeordnet werden kann — bewusst strenger als die Overlay-Anzeige selbst
(die zeigt sich im Zweifel lieber, dieser Button hier bewusst lieber nicht).
Damit landen nicht aus Versehen private Anrufer im Geschäfts-CRM. Ist keine
Geschäfts-SIM eingerichtet, bleibt der Button komplett unsichtbar.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 14.1 — Overlay nur für bestimmte SIM (Mehr-SIM-Geräte)

Neuer Menüpunkt **"📱 Overlay nur für bestimmte SIM"** (im ⋮-Menü) — für
Geräte mit zwei SIMs/Rufnummern (z. B. privat + dienstlich, wie beim
S23 Ultra möglich). Damit lässt sich einstellen, dass die Anruf-Karte nur
erscheint, wenn die ausgewählte SIM angerufen wird.

⚠️ **Wichtige Einschränkung, ehrlich benannt:** Anders als "wer ruft mich
an" (das funktioniert zuverlässig) gibt es auf Android **keinen offiziell
einheitlichen Weg**, um bei einem eingehenden Anruf zu erkennen, welche der
eigenen SIM-Karten angerufen wurde — das unterscheidet sich je nach
Hersteller/Android-Version. Die App probiert mehrere in der Praxis
gebräuchliche Erkennungswege durch; lässt sich keiner davon auslesen, zeigt
sie das Overlay sicherheitshalber trotzdem (lieber einmal zu viel als ein
wichtiger Anruf verpasst). **Bitte nach dem Einrichten kurz testen** (dich
selbst von beiden Nummern anrufen lassen) und mir Bescheid geben, ob es auf
deinem S23 Ultra zuverlässig funktioniert — falls nicht, justiere ich
gezielt nach.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 14.0 — Zweite Telefonnummer & freie Sammelgruß-Nachricht

- **Zweite Telefonnummer pro Kontakt**: neues optionales Feld "Telefon 2"
  (z. B. für Festnetz/Büro). Beim Antippen der Nummer in der Kundenliste
  oder der Wisch-Anruf-Aktion fragt die App nach, welche Nummer verwendet
  werden soll, falls beide hinterlegt sind. Auch die automatische
  Anrufer-Erkennung berücksichtigt jetzt beide Nummern
- **Sammelgruß mit frei geschriebenem Text**: neues Textfeld statt nur
  fester Vorlagen — eine Vorlage auswählen füllt den Text zum Anpassen vor,
  oder direkt komplett selbst schreiben. `{name}` wird beim Versand pro
  Kontakt automatisch durch den jeweiligen Namen ersetzt

⚠️ Erneute Datenbankänderung (zweite Telefonnummer) — bestehende lokale
Kontakte werden beim Update einmalig gelöscht. Vorher über "Sichern" ein
Backup machen (die zweite Nummer wird jetzt mitgesichert), danach über
"Wiederherstellen" zurückspielen.

## Version 13.4 — Angepasst für Samsung-Geräte (z. B. S23 Ultra)

Bildschirmgröße/-auflösung passen sich bei modernen Geräten wie dem S23 Ultra
schon automatisch an — das eigentlich Wichtige war etwas anderes: **Samsungs
One UI verwaltet Hintergrunddienste besonders aggressiv** und kann den
Anruf-Erkennungsdienst nach einiger Zeit im Standby einfach beenden, selbst
wenn alle anderen Berechtigungen erteilt sind.

- Beim Tippen auf **"Berechtigungen einrichten"** fragt die App jetzt
  zusätzlich eine echte System-Ausnahme von der Akku-Optimierung an (ein
  Android-Bordmittel, funktioniert herstellerübergreifend, nicht nur bei
  Samsung) — das ist der zuverlässigste Weg, damit der Dienst nicht
  einschläft
- Die Statusanzeige auf der Startseite zeigt jetzt auch an, wenn genau
  diese Ausnahme noch fehlt

**Falls die App auf deinem S23 Ultra trotzdem irgendwann aussetzt**, zusätzlich
manuell prüfen: Einstellungen → Akku und Gerätewartung → Hintergrundnutzung
limitieren → Anruf-Karte aus der Liste "Schlafende Apps" herausnehmen bzw.
zu "Nie schlafende Apps" hinzufügen. Das ist eine separate, Samsung-eigene
Liste, die die App selbst nicht direkt ansteuern kann (Samsung bietet dafür
keine offizielle Schnittstelle für Drittanbieter-Apps).

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 13.3 — Kalender-Synchronisation abgesichert (Mehrkonten/-geräte)

Auf deine Bitte hin die ganze App nochmal speziell auf Mehrkonten-/
Mehrkalender-Probleme durchgesehen. Gefunden und behoben:

- **Kompatibilitätslücke auf älteren Android-Geräten**: Die Funktion zur
  Erkennung des "primären" Kalenders (`IS_PRIMARY`) gibt es technisch erst
  ab Android 11 — die App unterstützt aber Geräte ab Android 8. Auf
  älteren Geräten hätte das theoretisch zu Problemen bei der
  automatischen Kalenderauswahl führen können. Der Zugriff läuft jetzt
  über eine sichere Methode, die auch bei fehlender Spalte nicht
  abstürzt, sondern einfach ohne "primär"-Erkennung auf den ersten
  beschreibbaren Kalender zurückfällt
- **Klarere Kalenderauswahl-Beschriftung**: In den Einstellungen steht bei
  reinen Gerätekalendern (ohne Konto-Anbindung) jetzt "Nur auf diesem
  Gerät" statt eines leeren/unklaren Kontonamens
- **Neue Warnung**: Falls die Kalender-Berechtigung zwar erteilt ist, aber
  gar kein Kalender-Konto auf dem Gerät eingerichtet ist (kommt vor, wenn
  z. B. kein Google-Konto hinzugefügt wurde), zeigt der Bearbeiten-Bildschirm
  das jetzt klar an, statt fälschlich "wird synchronisiert" zu behaupten
- Falls sich der gewählte Kalender selbst ändert oder ein Konto entfernt
  wird, erkennt die App das automatisch und wechselt selbstständig auf
  den nächsten verfügbaren Kalender (bereits vorher so, nochmal bestätigt)

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 13.2 — Tabellen-Erkennung getestet und verbessert

Ich habe die Tabellen-Erkennung tatsächlich gegen deine beiden hochgeladenen
Fotos getestet (mit einer lokalen Texterkennung als Näherung an die im
Handy verwendete Google-ML-Kit-Engine) und dabei zwei echte Schwachstellen
gefunden und behoben:

- **Getrennt erkannte Telefonnummern** (z. B. Vorwahl "0049" als eigenes
  Fragment von der restlichen Nummer) wurden vorher falsch der Nachbarspalte
  zugeordnet — jetzt werden alle Fragmente in der Telefon-Spalte zunächst
  nach vertikaler Nähe zu Zeilen gruppiert, unabhängig davon, ob die Nummer
  in einem oder mehreren Stücken erkannt wurde
- **Zu strikte Spaltengrenzen**: Text, der nur ein paar Pixel neben der
  exakten Kopfzeilen-Position liegt, landete in der falschen Spalte —
  jetzt gilt der Mittelpunkt zwischen zwei benachbarten Kopfzeilen als
  Grenze, das ist deutlich toleranter

Mit diesen Korrekturen wurden bei deinen Testfotos Name, Telefon und
Objekt-Adresse in allen 6 bzw. allen 9 Zeilen korrekt erkannt.

**Bekannte Grenze, ehrlich benannt:** Der kleine, gelb hervorgehobene
Status-Badge ("pendent") wurde bei einem der beiden Fotos von der
Texterkennung komplett übersehen — auch bei höherer Auflösung. Das ist
unkritisch, da Name/Telefon/Objekt davon unabhängig funktionieren und du
den Status beim Durchgehen der Kontakte jederzeit manuell nachtragen
kannst. **Tipp für bessere Erkennung:** die Tabelle beim Fotografieren
möglichst formatfüllend/nah aufnehmen, das hilft besonders bei kleinem Text.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 13.1 — Foto-Import: Kontakte nacheinander statt Sammel-Liste

Bei einem erkannten Tabellen-Foto (Status/Name/Telefon/Objekt) zeigt die
App die erkannten Kontakte jetzt **nicht mehr als Häkchen-Liste**, sondern
**einen nach dem anderen im normalen Bearbeiten-Bildschirm** — vorausgefüllt
mit Name, Telefon, Status und Objekt-Adresse. Du prüfst, korrigierst bei
Bedarf und tippst "Speichern" — danach erscheint automatisch der nächste
erkannte Kontakt, bis alle durch sind. Der Fortschritt steht oben im Titel
("Neuer Kontakt (3 von 6)"). Zurück/Abbrechen überspringt einen Kontakt
und geht zum nächsten weiter.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 13.0 — Foto-Import erkennt jetzt ganze Tabellen

Fotografierst du eine Liste wie im Betterhomes-CRM (Kopfzeile Status | Name |
Telefon | Objekt), erkennt die App das automatisch und liest **alle Zeilen
auf einmal** aus — statt wie bisher nur einen einzelnen Kontakt.

- **Status** wird übernommen, wo möglich einem der 7 App-Status zugeordnet
  (z. B. "pendent" → Status "Pendent"). Passt der erkannte Text zu keinem
  Status (z. B. "Wiedervorlage"), bleibt der Status auf "Interessent" und
  der Text landet stattdessen als **Tag**, damit nichts verloren geht
- **Name**, **Telefon** und **Objekt** (als Adresse des Objekts) werden
  automatisch übernommen
- Vor dem eigentlichen Import zeigt die App eine **Prüfliste** aller
  erkannten Zeilen — einzeln abwählbar, falls die Texterkennung mal
  danebenliegt (z. B. bei schrägen Fotos)
- Fotografierst du stattdessen nur einen einzelnen Kontakt (keine
  Tabellen-Kopfzeile erkennbar), funktioniert der bisherige Ablauf
  unverändert weiter

**Technischer Hinweis:** Die Zuordnung zu den Spalten basiert auf der
Position des erkannten Texts im Bild — bei sehr ungewöhnlichen Layouts oder
schlecht lesbaren Fotos kann das danebenliegen, deshalb immer erst die
Prüfliste kontrollieren, bevor du auf "Ausgewählte importieren" tippst.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 12.0 — Kalender-Verbesserungen

- **Kalender-Auswahl bei mehreren Konten**: unter ⚙️ Einstellungen lässt sich
  jetzt der Kalender, in den synchronisiert wird, explizit auswählen —
  praktisch, wenn mehrere Konten (z. B. privat + geschäftlich) auf dem
  Handy eingerichtet sind. "Automatisch" bleibt weiterhin die Standard-Option
- **Terminfarbe einstellbar**: ebenfalls unter ⚙️ Einstellungen, als Hex-Code
  (z. B. `#A9823D`) — wird auf alle automatisch angelegten Termine angewendet
  (Wiedervorlage, Vertragstermin, Besichtigung). Hängt vom jeweiligen
  Kalender-Anbieter ab, ob die Farbe exakt übernommen wird
- **Besichtigungstermine direkt übernehmen**: neues Feld "Besichtigungstermin"
  am Kontakt mit Datum **und** Uhrzeit — wird beim Speichern automatisch als
  eigener Kalender-Termin angelegt/aktualisiert/gelöscht, genau wie
  Wiedervorlage und Vertragstermin
- Nebenbei behoben: Vertragstermine hatten bisher fälschlich "Wiedervorlage:"
  im Termintitel stehen (Kopierfehler) — jetzt korrekt "Vertragstermin: …"

⚠️ Erneute Datenbankänderung (Besichtigungstermin-Feld) — bestehende lokale
Kontakte werden beim Update einmalig gelöscht. Vorher über "Sichern" ein
Backup machen, danach über "Wiederherstellen" zurückspielen.

## Version 11.2 — Erweiterte Status-Liste

Der Kunden-Status hat jetzt sieben Stufen statt drei:
**Interessent → Besichtigung vereinbart → Angebot abgegeben → Pendent (Entscheidung offen) → Kunde / Abgelehnt / Kauf abgeschlossen**

- "Kunde", "Abgelehnt" und "Kauf abgeschlossen" gelten als abgeschlossene
  Fälle — sie tauchen nicht mehr im Filter "Lange nicht kontaktiert (offen)",
  im Sammelgruß und im "Wen sollte ich heute anrufen?"-Vorschlag auf
- Die automatische 1-Monats-/Jahrestag-Erinnerung bleibt speziell an
  "Kauf abgeschlossen" geknüpft (nicht an "Kunde")
- Statistik-Seite zeigt jetzt Kennzahlen für alle sieben Status

Keine Datenbankänderung — kein erneuter Reset nötig (der Status wird
weiterhin als einfacher Text gespeichert, nur die Auswahlmöglichkeiten
sind erweitert).

## Version 11.1 — Notiz-Verlauf durchsuchbar

Die Suche auf der Startseite durchsucht jetzt zusätzlich zu Name/Telefon/Tags
auch den kompletten Notiz-Verlauf aller Kontakte. Passt eine Notiz zum
Suchbegriff, erscheint direkt in der Liste ein kleiner Ausschnitt darunter
("🔍 in Notiz: …"), auch wenn Name oder Nummer selbst nicht getroffen haben.

Keine Datenbankänderung — kein erneuter Reset nötig.

## Version 11.0 — neue Funktionen

- **Sprachauswahl pro Kontakt**: neues Feld "Bevorzugte Sprache" beim Kontakt
  (Deutsch/Englisch) — das WhatsApp-Vorlagen-Menü zeigt die passenden
  Vorlagen jetzt automatisch zuerst
- **Rückgängig für die letzte Aktion**: ein Banner erscheint nach dem
  Löschen eines Kontakts, dem Zurücksetzen verpasster Anrufe oder dem
  Verschieben einer Wiedervorlage — antippen macht die letzte dieser
  Aktionen rückgängig (nur die jeweils letzte, kein mehrstufiger Verlauf)
- **Vertretungs-Modus**: neuer 🧑‍🤝‍🧑-Button — bündelt alle als "wichtig"
  markierten Kontakte in einer Datei und öffnet den Teilen-Dialog, damit
  ein Kollege sie in seiner App-Kopie übernehmen kann. Zusätzlich lässt sich
  ein Enddatum als Erinnerungs-Banner setzen ("Vertretung aktiv bis …")

⚠️ Erneute Datenbankänderung (Sprachpräferenz) — bestehende lokale Kontakte
werden beim Update einmalig gelöscht. Vorher über "Sichern" ein Backup
machen, danach über "Wiederherstellen" zurückspielen.

**Wichtig zum Vertretungs-Modus:** Da die App komplett lokal ohne Server
läuft, ist kein echter Fernzugriff für einen Kollegen möglich — die Lösung
ist ein teilbares Datenpaket, das der Kollege selbst in seine eigene
App-Installation einspielt.

## Version 10.0 — neue Funktionen

- **Sammelgruß**: neuer 🎉-Button auf der Startseite — Vorlage wählen
  (Weihnachten/Neujahr/Sommer), dann jeden offenen Kontakt einzeln antippen.
  WhatsApp erlaubt keinen echten Massenversand per App, deshalb öffnet sich
  pro Tipp der vorausgefüllte Chat, du bestätigst den Versand selbst —
  bereits geöffnete Kontakte werden mit ✓ markiert
- **"Wen sollte ich heute anrufen?"**: Beim Öffnen der App schlägt sie jetzt
  proaktiv 1–2 Kontakte vor (Kombination aus wichtig-markiert, fälliger
  Wiedervorlage und lange nicht kontaktiert) — als Banner auf der Startseite,
  antippen öffnet direkt den Kontakt
- **Katalog-Link-Vorlage**: neues Feld unter ⚙️ Einstellungen für einen
  frei wählbaren Link (z. B. dein Betterhomes-Profil, sobald es steht) —
  wird in der WhatsApp-Vorlage "📋 Objektübersicht" eingesetzt

Keine Datenbankänderung in diesem Update — kein erneuter Reset nötig.

## Version 9.0 — neue Funktionen

- **Google-Bewertung anfragen**: neue WhatsApp-Vorlage "⭐ Bewertung erbitten"
  mit deinem Bewertungslink — Link einmal über das ⚙️-Zahnrad auf der
  Startseite hinterlegen
- **Angebotspreis vs. Verkaufspreis**: zweites Preisfeld pro Objekt für den
  tatsächlichen Abschlusspreis — Statistik-Seite zeigt die durchschnittliche
  Differenz
- **Objekt-Matching**: Button "🔍 Interessenten" bei jedem Objekt zeigt
  Kontakte, deren hinterlegter Such-Ort und Budget zum Objekt passen
  (dafür bei Kontakten "Gesucht: Ort" und "Budget bis" eintragen)
- **Anrufdauer automatisch erfassen**: bei beantworteten Anrufen (≥ 5 Sek.)
  landet automatisch ein Eintrag mit Dauer im Notiz-Verlauf
- **Exposé-Datei anhängen**: Button "📎 Exposé" pro Objekt zum Anhängen
  einer PDF-Datei, später direkt aus der App wieder öffnen
- **Vertragstermine als eigene Erinnerung**: separates Datumsfeld z. B. für
  Notartermine, inkl. eigener Benachrichtigung und automatischer
  Kalender-Synchronisation (unabhängig von der Wiedervorlage)

⚠️ Erneute Datenbankänderung — bestehende lokale Kontakte werden beim Update
einmalig gelöscht. Vorher über "Sichern" ein Backup machen, danach über
"Wiederherstellen" zurückspielen.

**Bewusst nicht umgesetzt:** eine echte Umkreissuche mit Kilometer-Radius
würde eine externe Karten-/Geocoding-API mit Internetzugriff erfordern —
das Objekt-Matching sucht stattdessen textbasiert nach dem hinterlegten Ort.

## Version 8.0 — neue Funktionen

- **Kunden-Karte teilen**: Button "Teilen" beim Kontakt exportiert ihn als
  Datei und öffnet den normalen Android-Teilen-Dialog (WhatsApp, E-Mail,
  Drive, …). Ein Kollege mit derselben App kann die Datei direkt öffnen
  ("Öffnen mit Anruf-Karte") — der Kontakt wird automatisch übernommen,
  inklusive Objekte und Notizen
- **Automatische Kalender-Synchronisation**: Jede Wiedervorlage landet jetzt
  von selbst als Termin im Standard-Kalender — Anlegen, Ändern und Löschen
  läuft automatisch mit, sobald du eine Wiedervorlage setzt/änderst/entfernst.
  Der bisherige manuelle "Im Kalender speichern"-Button ist entfallen, da er
  jetzt überflüssig ist
- Dafür ist eine **neue Berechtigung** nötig (Kalender lesen/schreiben) —
  einmal über "Berechtigungen einrichten" erlauben

⚠️ Erneute Datenbankänderung (Kalender-Termin-Verknüpfung) — bestehende
lokale Kontakte werden beim Update einmalig gelöscht. Vorher über "Sichern"
ein Backup machen, danach über "Wiederherstellen" zurückspielen.

## Version 7.0 — neue Funktionen

- **Dubletten-Warnung** jetzt auch beim manuellen Anlegen und beim Foto-Import
  (nicht mehr nur beim CSV-Import): existiert die Nummer schon, kannst du den
  bestehenden Kontakt öffnen oder trotzdem einen neuen anlegen
- **Jahresrückblick** auf der Statistik-Seite: Abschlüsse und Provisionen
  des laufenden Kalenderjahres auf einen Blick
- **Statistik exportieren** als CSV oder PDF (z. B. für Steuerberater/eigene
  Auswertung)
- **Wisch-Aktionen** in der Kundenliste: nach rechts wischen ruft an, nach
  links wischen verschiebt die Wiedervorlage um 1 Woche
- **Englische WhatsApp-Vorlagen** zusätzlich zu den deutschen im selben Menü

⚠️ Erneute Datenbankänderung (Abschluss-Datum für den Jahresrückblick) —
**bestehende lokale Kontakte werden beim Update einmalig gelöscht.** Vorher
über "Sichern" ein Backup machen, danach über "Wiederherstellen" zurückspielen.

## Version 6.0 — Kontakte per Foto anlegen

- Neuer Button **"📷 Aus Foto"** auf der Startseite
- Foto aufnehmen (z. B. CRM-Bildschirm abfotografieren) oder ein
  vorhandenes Foto/Screenshot aus der Galerie wählen
- Die App erkennt Text automatisch auf dem Gerät (Google ML Kit, läuft
  komplett offline, keine Internetverbindung nötig) und versucht, Name,
  Telefonnummer und E-Mail herauszufiltern
- Öffnet danach den normalen "Neuer Kontakt"-Bildschirm mit den erkannten
  Werten vorausgefüllt — **immer kurz prüfen und ggf. korrigieren**, die
  Erkennung ist eine Heuristik und nicht immer perfekt (besonders bei
  unscharfen Fotos oder ungewöhnlichen Layouts)
- Der komplette erkannte Text landet zusätzlich im Notizfeld, falls die
  App etwas Wichtiges nicht automatisch zuordnen konnte

**Tipp für gute Erkennung:** möglichst scharfes, gut ausgeleuchtetes Foto,
Bildschirm möglichst gerade/parallel fotografieren, nicht zu weit weg.

Keine Datenbankänderung in diesem Update — kein erneuter Reset nötig.

## Version 5.0 — neue Funktionen

- **Provisions-Tracking**: Provision pro Abschluss hinterlegen, Gesamtsumme
  auf der Statistik-Seite
- **Empfehlungs-Verknüpfung**: Kontakte können als "empfohlen von" einem
  anderen Kontakt markiert werden — Top-Empfehler-Rangliste auf der
  Statistik-Seite
- **Erreichbarkeits-Notiz**: kurzer Hinweis wie "abends besser erreichbar",
  erscheint direkt auf der Anruf-Karte
- **App-Shortcuts**: langer Druck aufs App-Icon → direkt "Neuer Kontakt"
  oder "CSV importieren"
- **Objekt-Status unabhängig vom Kunden-Status**: jedes Objekt einzeln als
  Interessiert/Reserviert/Verkauft-Vermietet markierbar
- **Backup-Erinnerung**: Hinweis-Banner, falls das letzte Backup länger als
  eine Woche her ist
- **Schnellnotizen-Buttons** auf der Anruf-Karte ("Kein Interesse mehr",
  "Rückruf gewünscht") — ein Tipp genügt

⚠️ Erneute Datenbankänderung (Provision, Empfehlung, Erreichbarkeit,
Objekt-Status) — **bestehende lokale Kontakte werden beim Update einmalig
gelöscht.** Vorher über "Sichern" ein Backup machen, danach über
"Wiederherstellen" zurückspielen.

## Version 4.0 — neue Funktionen

- **Jahrestag-Erinnerung**: Bei Status "Kauf abgeschlossen" wird automatisch —
  zusätzlich zur 1-Monats-Nachfrage — eine Erinnerung nach 12 Monaten gesetzt,
  um sich nach einem Jahr nochmal zu melden
- **Rückruf-Snooze**: Nach einem verpassten Anruf erscheint eine Benachrichtigung
  mit "Anrufen" und "In 1 Std. erinnern" — bei Snooze meldet sich die App
  eine Stunde später erneut
- **WhatsApp-Textvorlagen**: Tippen auf den WhatsApp-Button der Anruf-Karte
  öffnet ein Auswahlmenü mit vorformulierten Nachrichten (Terminbestätigung,
  Rückfrage, Rückruf erbeten, Glückwunsch zum Kauf) — der Name wird automatisch
  eingesetzt, "Ohne Vorlage öffnen" bleibt weiterhin möglich

⚠️ Auch dieses Update ändert die Datenbankstruktur (Jahrestag-Feld) —
**bestehende lokale Kontakte werden beim Update erneut einmalig gelöscht.**
Vorher über "Sichern" ein Backup machen, danach über "Wiederherstellen"
wieder einspielen.

## Version 3.0 — neue Funktionen

- **App-Sperre** per Fingerabdruck/Gesicht/PIN beim Öffnen der App (nutzt die
  Displaysperre deines Handys — kein separates Passwort nötig)
- **Direktanruf** durch Antippen der Telefonnummer in der Kundenliste
- **Kalender-Verknüpfung** — Wiedervorlage per Knopfdruck als Termin in deine
  normale Kalender-App übernehmen
- **Dubletten-Warnung beim CSV-Import** — zeigt Konflikte (gleiche Nummer,
  unterschiedlicher Name) vor dem Import an
- **Freie Tags** pro Kontakt (z. B. "ImmoScout, Empfehlung"), durchsuchbar
- **Statistik-Seite** (📊-Button) mit Kennzahlen auf einen Blick
- **PDF-Steckbrief** pro Kontakt zum Ausdrucken/Weiterleiten
- **Kontakt ins Telefonbuch übernehmen** per Knopfdruck
- **Verpasste Anrufe** mit einem Tipp als gesehen markieren
- Neuer Filter **"Lange nicht kontaktiert"**

⚠️ Auch dieses Update ändert die Datenbankstruktur (Tags-Feld) — **bestehende
lokale Kontakte werden beim Update erneut einmalig gelöscht.** Vorher per
Backup-Funktion sichern (Button "Sichern" auf der Startseite) und danach
wiederherstellen.

### Zur App-Sperre
Es wird die auf dem Handy bereits eingerichtete Displaysperre verwendet
(Fingerabdruck, Gesichtserkennung, PIN, Muster) — es gibt kein separates
App-Passwort. Ist auf dem Handy keine Displaysperre eingerichtet, startet die
App ohne Abfrage.

## Version 2.0 — neue Funktionen

- **Suche & Filter** in der Kundenliste (auch "nur fällige Wiedervorlagen")
- **Status pro Kunde** (Interessent / Besichtigung vereinbart / Kauf abgeschlossen)
- **Wiedervorlage mit echter Erinnerungs-Benachrichtigung** (täglich 8 Uhr geprüft,
  übersteht auch einen Handy-Neustart)
- **Notiz-Verlauf** statt einzelner Notiz — jeder Eintrag mit Zeitstempel
- **Schnellaktionen auf der Anruf-Karte**: WhatsApp & E-Mail direkt aus dem Overlay
- **Notizfeld direkt auf der Anruf-Karte**, sofort während des Gesprächs nutzbar
- **Verpasste Anrufe** werden automatisch gezählt und angezeigt
- **Wichtige Kontakte** (Stern-Markierung) — siehe Hinweis unten zur Nicht-stören-Funktion
- **Backup sichern/wiederherstellen** als Datei (kein Cloud-Abgleich, du behältst die Kontrolle)
- **Homescreen-Widget** mit den heutigen Wiedervorlagen

### Wichtiger Hinweis zum Update
Weil sich die Datenbankstruktur geändert hat, **werden bestehende lokale Kontakte beim
Update einmalig gelöscht**. Am besten vorher die aktuellen Kontakte per CSV oder
manuell notieren und danach neu anlegen bzw. importieren.

### Zur "Wichtiger Kontakt"-Markierung
Die App selbst kann die Nicht-stören-Funktion von Android nicht direkt umgehen — das
kann technisch nur die Standard-Telefon-App. Der Stern markiert den Kontakt aber
oben in der Liste und auf der Anruf-Karte deutlich sichtbar. Für einen echten
Nicht-stören-Durchlass: den Kontakt zusätzlich in den Telefon-Kontakten als
Favorit markieren und unter Einstellungen → Töne & Benachrichtigungen →
Nicht stören → Ausnahmen → "Anrufe von Favoriten zulassen" aktivieren.

### Zum Homescreen-Widget
Nach der Installation lange auf den Homescreen tippen → Widgets → "Anruf-Karte"
auswählen → "Wiedervorlagen heute" platzieren.

## Schnellster Weg zur fertigen APK (ohne Android Studio)

Das Projekt enthält eine automatische Bauanleitung für GitHub. Du brauchst
nur einen Browser und einen kostenlosen GitHub-Account.

1. Auf [github.com](https://github.com) einen kostenlosen Account anlegen
   (falls noch nicht vorhanden).
2. **New repository** klicken, z. B. `anruf-karte` nennen, "Create".
3. Auf der leeren Projektseite auf **"uploading an existing file"**
   klicken und den kompletten Inhalt des entpackten `AnrufKarte`-Ordners
   per Drag & Drop hochladen (inkl. der versteckten `.github`-Mappe —
   ggf. im Datei-Explorer "versteckte Dateien anzeigen" aktivieren).
   Danach **"Commit changes"**.
4. Oben im Repository auf den Reiter **"Actions"** klicken.
5. Den Workflow **"APK bauen"** auswählen → Button **"Run workflow"** →
   nochmal **"Run workflow"** bestätigen.
6. Ca. 3–5 Minuten warten, bis der Lauf ein grünes Häkchen zeigt.
7. Auf den fertigen Lauf klicken, ganz unten bei **"Artifacts"** auf
   **"AnrufKarte-apk"** klicken — lädt eine ZIP-Datei mit der `app-debug.apk`
   herunter.
8. Diese `.apk`-Datei aufs Handy übertragen (z. B. per E-Mail an dich
   selbst, Google Drive oder USB-Kabel) und dort antippen, um sie zu
   installieren. Android fragt beim ersten Mal, ob "Installation aus
   unbekannten Quellen" erlaubt werden soll — das musst du einmalig
   bestätigen (Einstellungen → z. B. für die "Dateien"- oder "Gmail"-App).

Danach ist die App ganz normal auf deinem Handy installiert, ohne dass du
je Android Studio geöffnet hast.

## Projekt öffnen (alternativ: klassisch mit Android Studio)

1. Android Studio installieren (aktuelle Version, "Iguana" oder neuer).
2. **File → Open** → diesen Ordner (`AnrufKarte/`) auswählen.
3. Android Studio synchronisiert Gradle automatisch (dauert beim ersten
   Mal ein paar Minuten, lädt Abhängigkeiten herunter).
4. Handy per USB anschließen (USB-Debugging aktiviert) oder Emulator
   starten, dann auf **Run ▶** klicken.

## Einrichtung nach der Installation

Die App braucht zwei Berechtigungen, die Android aus Datenschutzgründen
nicht automatisch vergibt:

1. **Telefonstatus lesen** — normaler Berechtigungsdialog beim ersten
   Tippen auf „Berechtigungen einrichten".
2. **Über anderen Apps anzeigen** (Overlay) — öffnet die Systemeinstellung
   direkt; muss manuell angeschaltet werden.

Zusätzlich bei manchen Herstellern (Xiaomi, Huawei, Oppo, Samsung mit
strengem Akku-Management) nötig, damit der Hintergrunddienst beim Klingeln
zuverlässig läuft:
- Autostart / Hintergrundaktivität für die App erlauben
- Akkuoptimierung für die App deaktivieren

## Kundendaten importieren

„CSV importieren" antippen und eine Datei mit dieser Kopfzeile wählen
(Reihenfolge der Spalten egal):

```
Name,Telefon,Typ,Adresse,Ort,Preis,Notizen
Anna Beispiel,+49 151 2345678,Wohnung,Musterstraße 1,Berlin,349000,Sucht 3 Zimmer
```

Klingelt danach diese Nummer an, erscheint automatisch die Karte mit
Name, Notizen und Objekt(en).

## Wichtiger Hinweis zum Vertrieb der App

Diese App liest sensible, von Google streng regulierte Berechtigungen
(Telefonstatus, Anrufprotokoll). Für die **private Nutzung** (Installation
direkt über Android Studio / als APK auf dein eigenes Gerät) ist das kein
Problem. Willst du die App später über den **Google Play Store**
veröffentlichen, verlangt Google dafür eine gesonderte Begründung/Freigabe
(„Permissions Declaration Form") — nicht jede App wird dafür zugelassen.
Für den Eigenbedarf als Immobilienmakler ist die direkte Installation der
unkomplizierteste Weg.

## Projektstruktur

```
app/src/main/java/de/immokarte/anrufkarte/
  MainActivity.kt              Kundenliste, Berechtigungen, CSV-Import
  data/                        Room-Datenbank (Kunden + Objekte), CSV-Parser
  call/CallReceiver.kt         Erkennt eingehende Anrufe
  call/OverlayService.kt       Zeigt/entfernt das Overlay-Fenster
  call/OverlayBinder.kt        Befüllt die Karte mit den Kundendaten
  ui/CustomerAdapter.kt        Liste in der App
app/src/main/res/layout/
  overlay_card.xml             Design der Anruf-Karte (Vorschau-Layout)
  activity_main.xml            Haupt-App-Oberfläche
```

## Nächste sinnvolle Ausbaustufen

- Karte antippbar machen → öffnet den vollen Kundendatensatz in der App
- Property-Typ-Icons (Haus/Wohnung) als eigene Vektorgrafiken statt Text
- Eigene Schriftart (Fraunces) einbinden für exakt das Vorschau-Design
- Automatischer Start des Hintergrunddienstes nach Neustart des Handys
