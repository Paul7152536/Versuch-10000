package de.immokarte.anrufkarte

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Führt Wiedervorlagen, Shootings, Besichtigungen, Notar-/Mietvertrags-
 * Termine und Jahrestage aus
 * allen Kontakten chronologisch zusammen — bisher waren diese nur getrennt
 * je Kontakt sichtbar. Zeigt überfällige Einträge sowie die kommenden
 * 30 Tage, gruppiert nach Tag.
 *
 * Jeder Tag startet eingeklappt und zeigt nur "Tag — n Termine" — antippen
 * klappt die einzelnen Einträge auf, nochmal antippen klappt wieder zu.
 * Verhindert, dass die Liste bei vielen Terminen unübersichtlich wird.
 */
class WeekPlanActivity : AppCompatActivity() {

    private data class PlanEntry(val date: Long, val typeLabel: String, val icon: String, val customer: CustomerWithProperties)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_week_plan)

        val container = findViewById<LinearLayout>(R.id.planContainer)

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val allCustomers = withContext(Dispatchers.IO) { dao.getAllWithProperties() }

            val now = System.currentTimeMillis()
            val startWindow = now - 3L * 24 * 60 * 60 * 1000
            val endWindow = now + 30L * 24 * 60 * 60 * 1000

            val entries = mutableListOf<PlanEntry>()
            allCustomers.forEach { c ->
                c.customer.followUpAt?.let { if (it in startWindow..endWindow) entries += PlanEntry(it, "Wiedervorlage", "🔔", c) }
                c.customer.shootingAt?.let { if (it in startWindow..endWindow) entries += PlanEntry(it, "Shooting", "📸", c) }
                c.customer.viewingAt?.let { if (it in startWindow..endWindow) entries += PlanEntry(it, "Besichtigung", "🏠", c) }
                c.customer.contractDateAt?.let { if (it in startWindow..endWindow) entries += PlanEntry(it, "Notar/Mietvertrag", "📝", c) }
                c.customer.anniversaryAt?.let { if (it in startWindow..endWindow) entries += PlanEntry(it, "Jahrestag", "🎂", c) }
            }
            entries.sortBy { it.date }

            if (entries.isEmpty()) {
                container.addView(TextView(this@WeekPlanActivity).apply {
                    text = "Keine Termine in den nächsten 30 Tagen."
                    setTextColor(0xFF8B93A0.toInt())
                    setPadding(0, 20, 0, 0)
                })
                return@launch
            }

            // Nach Tag gruppieren, Reihenfolge bleibt chronologisch (entries ist bereits sortiert)
            val grouped = LinkedHashMap<String, MutableList<PlanEntry>>()
            entries.forEach { grouped.getOrPut(dayLabel(it.date)) { mutableListOf() }.add(it) }

            grouped.forEach { (label, list) ->
                val headerRow = LinearLayout(this@WeekPlanActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(18, 16, 18, 16)
                    setBackgroundResource(R.drawable.bg_card)
                    isClickable = true
                    isFocusable = true
                    val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    params.topMargin = 14
                    layoutParams = params
                }
                val tvLabel = TextView(this@WeekPlanActivity).apply {
                    text = label
                    textSize = 13.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (label == "Überfällig") 0xFF8C3B2B.toInt() else 0xFF20242B.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvCount = TextView(this@WeekPlanActivity).apply {
                    text = "${list.size} Termin${if (list.size == 1) "" else "e"}"
                    textSize = 11.5f
                    setTextColor(0xFF8B93A0.toInt())
                }
                val tvChevron = TextView(this@WeekPlanActivity).apply {
                    text = "▸"
                    textSize = 13f
                    setTextColor(0xFF8B93A0.toInt())
                    setPadding(10, 0, 0, 0)
                }
                headerRow.addView(tvLabel)
                headerRow.addView(tvCount)
                headerRow.addView(tvChevron)
                container.addView(headerRow)

                val detailContainer = LinearLayout(this@WeekPlanActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                    setPadding(0, 8, 0, 0)
                }
                list.forEach { entry -> detailContainer.addView(buildEntryCard(entry)) }
                container.addView(detailContainer)

                headerRow.setOnClickListener {
                    val expand = detailContainer.visibility != View.VISIBLE
                    detailContainer.visibility = if (expand) View.VISIBLE else View.GONE
                    tvChevron.text = if (expand) "▾" else "▸"
                }
            }
        }
    }

    private fun buildEntryCard(entry: PlanEntry): LinearLayout {
        val hasTime = entry.typeLabel == "Besichtigung" || entry.typeLabel == "Shooting"
        val timeFmt = if (hasTime) SimpleDateFormat("HH:mm", Locale.GERMANY) else SimpleDateFormat("dd.MM.", Locale.GERMANY)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundResource(R.drawable.bg_card)
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = 6
            layoutParams = params
            setOnClickListener {
                startActivity(Intent(this@WeekPlanActivity, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, entry.customer.customer.id))
            }
        }
        card.addView(TextView(this).apply {
            text = entry.icon
            textSize = 17f
            setPadding(0, 0, 14, 0)
        })
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textCol.addView(TextView(this).apply {
            text = entry.customer.customer.name
            textSize = 13.5f
            setTextColor(0xFF20242B.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        textCol.addView(TextView(this).apply {
            text = entry.typeLabel
            textSize = 11f
            setTextColor(0xFF8B93A0.toInt())
        })
        card.addView(textCol)
        card.addView(TextView(this).apply {
            text = timeFmt.format(Date(entry.date))
            textSize = 12.5f
            setTextColor(0xFF1E2C3B.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        return card
    }

    private fun dayLabel(date: Long): String {
        val target = Calendar.getInstance().apply { timeInMillis = date }
        val today = Calendar.getInstance()
        val targetDay = target.get(Calendar.YEAR) * 1000 + target.get(Calendar.DAY_OF_YEAR)
        val todayDay = today.get(Calendar.YEAR) * 1000 + today.get(Calendar.DAY_OF_YEAR)
        val diff = targetDay - todayDay
        return when {
            diff < 0 -> "Überfällig"
            diff == 0 -> "Heute"
            diff == 1 -> "Morgen"
            else -> SimpleDateFormat("EEEE, dd.MM.", Locale.GERMANY).format(Date(date))
        }
    }
}
