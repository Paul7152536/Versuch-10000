package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.CustomerEditActivity

/** Feuert 45 Minuten vor einem Besichtigungstermin (siehe ViewingReminderScheduler). */
class ViewingReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_CUSTOMER_ID = "extra_customer_id"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_TIME_LABEL = "extra_time_label"
        private const val CHANNEL_ID = "viewing_reminder"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val customerId = intent.getLongExtra(EXTRA_CUSTOMER_ID, -1L)
        val name = intent.getStringExtra(EXTRA_NAME) ?: return
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        val timeLabel = intent.getStringExtra(EXTRA_TIME_LABEL).orEmpty()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Besichtigungs-Erinnerung", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            context, customerId.toInt(),
            Intent(context, CustomerEditActivity::class.java).apply {
                putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, customerId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val callIntent = if (phone.isNotBlank()) {
            PendingIntent.getActivity(
                context, customerId.toInt() + 500_000, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("🏠 Besichtigung gleich: $name")
            .setContentText(if (timeLabel.isNotBlank()) "Termin um $timeLabel" else "Termin steht bald an")
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        if (callIntent != null) builder.addAction(android.R.drawable.sym_action_call, "Anrufen", callIntent)

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(2004 + customerId.toInt(), builder.build())
    }
}
