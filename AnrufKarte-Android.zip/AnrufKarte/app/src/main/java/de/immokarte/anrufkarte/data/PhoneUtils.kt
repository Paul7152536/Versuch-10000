package de.immokarte.anrufkarte.data

object PhoneUtils {
    /** Reduziert eine Telefonnummer auf Ziffern (+ führendes '+'), damit
     *  unterschiedliche Schreibweisen ("0151 234", "+49151234") zusammenfinden. */
    fun normalize(raw: String): String =
        raw.filter { it.isDigit() || it == '+' }
}
