package de.immokarte.anrufkarte.data

/** Kurzlebiger Zwischenspeicher, um die per Foto erkannten Tabellenzeilen
 *  von MainActivity an PhotoTableReviewActivity zu übergeben, ohne dafür
 *  Parcelable-Boilerplate zu brauchen. Nur für die Dauer eines Imports gültig. */
object PendingImportHolder {
    var rows: List<TableRow> = emptyList()
}
