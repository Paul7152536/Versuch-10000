package de.immokarte.anrufkarte.call

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import de.immokarte.anrufkarte.R
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.NoteEntry
import de.immokarte.anrufkarte.data.NoteLogUtils
import de.immokarte.anrufkarte.data.StatusInfo
import de.immokarte.anrufkarte.data.WhatsAppTemplates
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

/** Befüllt das Overlay-Layout (overlay_card.xml) mit den Daten des Treffers
 *  und verdrahtet die Icon-Leiste unten (Anrufen/WhatsApp/E-Mail/Notiz/
 *  Wichtig bzw. bei unbekannten Anrufern nur Anrufen/Anlegen). */
object OverlayBinder {

    fun bind(view: View, rawPhone: String, match: CustomerWithProperties?, scope: CoroutineScope, onBusinessSim: Boolean = false) {
        val tvName = view.findViewById<TextView>(R.id.tvName)
        val tvPhone = view.findViewById<TextView>(R.id.tvPhone)
        val tvReachability = view.findViewById<TextView>(R.id.tvReachability)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvNote = view.findViewById<TextView>(R.id.tvNote)
        val tvMissedCalls = view.findViewById<TextView>(R.id.tvMissedCalls)
        val propsContainer = view.findViewById<LinearLayout>(R.id.propsContainer)
        val noteInputArea = view.findViewById<LinearLayout>(R.id.noteInputArea)
        val etQuickNote = view.findViewById<EditText>(R.id.etQuickNote)
        val btnSaveNote = view.findViewById<TextView>(R.id.btnSaveNote)
        val btnQuickNote1 = view.findViewById<TextView>(R.id.btnQuickNote1)
        val btnQuickNote2 = view.findViewById<TextView>(R.id.btnQuickNote2)

        val btnIconCall = view.findViewById<LinearLayout>(R.id.btnIconCall)
        val btnIconWhatsApp = view.findViewById<LinearLayout>(R.id.btnIconWhatsApp)
        val btnIconEmail = view.findViewById<LinearLayout>(R.id.btnIconEmail)
        val btnIconNote = view.findViewById<LinearLayout>(R.id.btnIconNote)
        val tvIconNoteCircle = view.findViewById<TextView>(R.id.tvIconNoteCircle)
        val btnIconImportant = view.findViewById<LinearLayout>(R.id.btnIconImportant)
        val tvIconImportantCircle = view.findViewById<TextView>(R.id.tvIconImportantCircle)
        val btnIconAddUnknown = view.findViewById<LinearLayout>(R.id.btnIconAddUnknown)

        tvPhone.text = rawPhone.ifBlank { "Unbekannte Nummer" }
        val digits = rawPhone.filter { it.isDigit() }

        // Anrufen ist immer verfügbar, ob bekannt oder nicht.
        btnIconCall.visibility = View.VISIBLE
        btnIconCall.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$rawPhone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { view.context.startActivity(intent) }
        }

        if (match == null) {
            tvName.text = "Unbekannter Anrufer"
            tvReachability.visibility = View.GONE
            tvStatus.visibility = View.GONE
            tvNote.visibility = View.GONE
            tvMissedCalls.visibility = View.GONE
            propsContainer.visibility = View.GONE
            noteInputArea.visibility = View.GONE
            btnIconWhatsApp.visibility = View.GONE
            btnIconEmail.visibility = View.GONE
            btnIconNote.visibility = View.GONE
            btnIconImportant.visibility = View.GONE

            // Nur bei sicher erkannter Geschäfts-SIM anbieten — siehe Kommentar
            // in CallReceiver.isConfirmedBusinessSim().
            if (onBusinessSim && rawPhone.isNotBlank()) {
                btnIconAddUnknown.visibility = View.VISIBLE
                btnIconAddUnknown.setOnClickListener {
                    val intent = Intent(view.context, de.immokarte.anrufkarte.CustomerEditActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra(de.immokarte.anrufkarte.CustomerEditActivity.EXTRA_PREFILL_PHONE, rawPhone)
                    }
                    runCatching { view.context.startActivity(intent) }
                }
            } else {
                btnIconAddUnknown.visibility = View.GONE
            }
            return
        }
        btnIconAddUnknown.visibility = View.GONE

        val customer = match.customer
        tvName.text = customer.name

        if (customer.reachability.isNotBlank()) {
            tvReachability.text = "📞 ${customer.reachability}"
            tvReachability.visibility = View.VISIBLE
        } else {
            tvReachability.visibility = View.GONE
        }

        tvStatus.text = StatusInfo.label(customer.status)
        tvStatus.visibility = View.VISIBLE

        if (customer.missedCalls > 0) {
            tvMissedCalls.text = "${customer.missedCalls} verpasst"
            tvMissedCalls.visibility = View.VISIBLE
        } else {
            tvMissedCalls.visibility = View.GONE
        }

        val lastNote = NoteLogUtils.parse(customer.noteLog).lastOrNull()
        if (lastNote != null) {
            tvNote.text = "Letzte Notiz: ${lastNote.text}"
            tvNote.visibility = View.VISIBLE
        } else if (customer.notes.isNotBlank()) {
            tvNote.text = customer.notes
            tvNote.visibility = View.VISIBLE
        } else {
            tvNote.visibility = View.GONE
        }

        // WhatsApp-Icon: Vorlagen-Menü wie gehabt
        btnIconWhatsApp.visibility = View.VISIBLE
        btnIconWhatsApp.setOnClickListener {
            val prefs = view.context.getSharedPreferences("anruf_karte_prefs", android.content.Context.MODE_PRIVATE)
            val reviewLink = prefs.getString("google_review_link", "").orEmpty()
            val catalogLink = prefs.getString("catalog_link", "").orEmpty()
            val orderedTemplates = WhatsAppTemplates.templatesFor(customer.preferredLanguage)
            val popup = PopupMenu(view.context, btnIconWhatsApp)
            orderedTemplates.forEachIndexed { i, t -> popup.menu.add(0, i, i, t.label) }
            popup.menu.add(0, -1, orderedTemplates.size, "Ohne Vorlage öffnen")
            popup.setOnMenuItemClickListener { item ->
                val link = if (item.itemId == -1) {
                    WhatsAppTemplates.buildLinkPlain(digits)
                } else {
                    val t = orderedTemplates[item.itemId]
                    WhatsAppTemplates.buildLink(digits, customer.name, t.text, reviewLink, catalogLink)
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { view.context.startActivity(intent) }
                true
            }
            popup.show()
        }

        // E-Mail-Icon
        if (customer.email.isNotBlank()) {
            btnIconEmail.visibility = View.VISIBLE
            btnIconEmail.setOnClickListener {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${customer.email}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { view.context.startActivity(intent) }
            }
        } else {
            btnIconEmail.visibility = View.GONE
        }

        // Notiz-Icon klappt den Notizbereich auf/zu
        btnIconNote.visibility = View.VISIBLE
        btnIconNote.setOnClickListener {
            val open = noteInputArea.visibility != View.VISIBLE
            noteInputArea.visibility = if (open) View.VISIBLE else View.GONE
            tvIconNoteCircle.setBackgroundResource(if (open) R.drawable.bg_circle_brass else R.drawable.bg_circle_outline)
        }

        fun saveQuickNote(text: String) {
            scope.launch {
                withContext(Dispatchers.IO) {
                    val dao = AppDatabase.getInstance(view.context.applicationContext).customerDao()
                    val current = dao.getByIdWithProperties(customer.id)?.customer?.noteLog ?: customer.noteLog
                    val updated = NoteLogUtils.append(current, NoteEntry(System.currentTimeMillis(), text))
                    dao.updateNoteLog(customer.id, updated)
                }
            }
            tvNote.text = "Letzte Notiz: $text"
            tvNote.visibility = View.VISIBLE
        }
        btnQuickNote1.setOnClickListener { saveQuickNote("Kein Interesse mehr") }
        btnQuickNote2.setOnClickListener { saveQuickNote("Rückruf gewünscht") }
        btnSaveNote.setOnClickListener {
            val text = etQuickNote.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            saveQuickNote(text)
            etQuickNote.text.clear()
        }

        // Wichtig-Icon: schaltet die Markierung direkt in der Datenbank um
        btnIconImportant.visibility = View.VISIBLE
        fun updateImportantIcon(important: Boolean) {
            tvIconImportantCircle.setBackgroundResource(if (important) R.drawable.bg_circle_brass else R.drawable.bg_circle_outline)
        }
        updateImportantIcon(customer.important)
        btnIconImportant.setOnClickListener {
            val newValue = !customer.important
            updateImportantIcon(newValue)
            scope.launch {
                withContext(Dispatchers.IO) {
                    AppDatabase.getInstance(view.context.applicationContext).customerDao().setImportant(customer.id, newValue)
                }
            }
        }

        propsContainer.removeAllViews()
        if (match.properties.isEmpty()) {
            propsContainer.visibility = View.GONE
            return
        }
        propsContainer.visibility = View.VISIBLE

        val inflater = LayoutInflater.from(view.context)
        val fmt = NumberFormat.getCurrencyInstance(Locale.GERMANY).apply { maximumFractionDigits = 0 }
        val propStatusMarks = mapOf("reserviert" to " · reserviert", "verkauft_vermietet" to " · vergeben")

        match.properties.forEach { p ->
            val row = inflater.inflate(R.layout.overlay_property_row, propsContainer, false)
            row.findViewById<TextView>(R.id.tvPropTitle).text =
                buildString {
                    append(p.typ)
                    if (p.adresse.isNotBlank()) append(" · ").append(p.adresse)
                    append(propStatusMarks[p.status] ?: "")
                }
            row.findViewById<TextView>(R.id.tvPropCity).text = p.ort

            val priceView = row.findViewById<TextView>(R.id.tvPropPrice)
            val price = p.preis.toLongOrNull()
            if (price != null) {
                priceView.text = fmt.format(price)
                priceView.visibility = View.VISIBLE
            } else {
                priceView.visibility = View.GONE
            }
            propsContainer.addView(row)
        }
    }
}
