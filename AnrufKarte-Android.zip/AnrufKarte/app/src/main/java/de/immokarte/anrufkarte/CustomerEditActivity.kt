package de.immokarte.anrufkarte

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import androidx.core.content.FileProvider
import java.io.File
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.BackupManager
import de.immokarte.anrufkarte.data.CustomerEntity
import de.immokarte.anrufkarte.data.NoteEntry
import de.immokarte.anrufkarte.data.NoteLogUtils
import de.immokarte.anrufkarte.data.PdfExporter
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.PropertyEntity
import de.immokarte.anrufkarte.databinding.ActivityCustomerEditBinding
import de.immokarte.anrufkarte.databinding.ItemPropertyEditBinding
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class PropertyDraft(val typ: String, val adresse: String, val ort: String, val preis: String, val status: String, val verkaufspreis: String, val exposeUri: String)

private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)

class CustomerEditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CUSTOMER_ID = "extra_customer_id"
        const val EXTRA_PREFILL_NAME = "extra_prefill_name"
        const val EXTRA_PREFILL_PHONE = "extra_prefill_phone"
        const val EXTRA_PREFILL_EMAIL = "extra_prefill_email"
        const val EXTRA_PREFILL_NOTES = "extra_prefill_notes"
        const val EXTRA_PREFILL_STATUS = "extra_prefill_status"
        const val EXTRA_PREFILL_TAGS = "extra_prefill_tags"
        const val EXTRA_PREFILL_OBJEKT = "extra_prefill_objekt"
        const val EXTRA_PREFILL_PROGRESS = "extra_prefill_progress"
    }

    private lateinit var binding: ActivityCustomerEditBinding
    private var customerId: Long = -1L
    private val propertyRows = mutableListOf<ItemPropertyEditBinding>()
    private val propertyTypes = arrayOf("Haus", "Wohnung", "Sonstiges")
    private val propertyStatuses = arrayOf("interessiert", "reserviert", "verkauft_vermietet")
    private val propertyStatusLabels = arrayOf("Interessiert", "Reserviert", "Verkauft/Vermietet")
    private var followUpAt: Long? = null
    private var anniversaryAt: Long? = null
    private var abschlussAt: Long? = null
    private var calendarEventId: Long? = null
    private var contractDateAt: Long? = null
    private var contractEventId: Long? = null
    private var viewingAt: Long? = null
    private var viewingEventId: Long? = null
    private var noteLog: String = ""
    private var statusListenerActive = false
    private var referrerOptions: List<de.immokarte.anrufkarte.data.CustomerNameOnly> = emptyList()
    private val propertyExposeUris = mutableMapOf<ItemPropertyEditBinding, String>()
    private var pendingExposeTarget: ItemPropertyEditBinding? = null

    private val pickExposeFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { docUri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(docUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                pendingExposeTarget?.let { propertyExposeUris[it] = docUri.toString() }
                Toast.makeText(this, "Exposé angehängt.", Toast.LENGTH_SHORT).show()
            }
        }

    private val pickPdfLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
            uri?.let { exportPdf(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        binding = ActivityCustomerEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        customerId = intent.getLongExtra(EXTRA_CUSTOMER_ID, -1L)

        binding.spinnerStatus.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, de.immokarte.anrufkarte.data.StatusInfo.labels)
        binding.spinnerLanguage.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Deutsch", "Englisch"))
        binding.spinnerStatus.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (statusListenerActive && de.immokarte.anrufkarte.data.StatusInfo.keys[position] == "abschluss") {
                    var changed = false
                    if (abschlussAt == null) {
                        abschlussAt = System.currentTimeMillis()
                        changed = true
                    }
                    if (followUpAt == null) {
                        followUpAt = Calendar.getInstance().apply { add(Calendar.MONTH, 1) }.timeInMillis
                        changed = true
                    }
                    if (anniversaryAt == null) {
                        anniversaryAt = Calendar.getInstance().apply { add(Calendar.MONTH, 12) }.timeInMillis
                        changed = true
                    }
                    if (changed) {
                        updateFollowUpLabel()
                        updateAnniversaryLabel()
                        Toast.makeText(
                            this@CustomerEditActivity,
                            "Erinnerungen gesetzt: in 1 Monat nachfragen, in 1 Jahr Jahrestag-Gespräch",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    promptReviewRequest()
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        binding.btnAddProperty.setOnClickListener { addPropertyRow() }
        binding.btnSave.setOnClickListener { save() }
        binding.btnDelete.setOnClickListener { confirmDelete() }
        binding.btnPickDate.setOnClickListener { pickDate() }
        binding.btnComposeMessage.setOnClickListener { showComposeMessageDialog() }
        binding.btnClearDate.setOnClickListener { followUpAt = null; updateFollowUpLabel() }
        binding.btnPickContractDate.setOnClickListener { pickContractDate() }
        binding.btnClearContractDate.setOnClickListener { contractDateAt = null; updateContractDateLabel() }
        binding.btnPickViewing.setOnClickListener { pickViewingDateTime() }
        binding.btnClearViewing.setOnClickListener { viewingAt = null; updateViewingLabel() }
        binding.btnAddNote.setOnClickListener { addNoteFromInput() }
        binding.btnExportPdf.setOnClickListener {
            val safeName = binding.etName.text.toString().trim().ifBlank { "kontakt" }.replace(Regex("[^A-Za-z0-9-]+"), "_")
            pickPdfLocation.launch("$safeName-steckbrief.pdf")
        }
        binding.btnAddContact.setOnClickListener { addToPhoneContacts() }
        binding.btnShareCustomer.setOnClickListener { shareCustomer() }

        loadReferrerOptions()

        if (customerId >= 0) {
            binding.tvTitle.text = getString(R.string.edit_title_edit)
            binding.btnDelete.visibility = View.VISIBLE
            binding.noteLogSection.visibility = View.VISIBLE
            loadCustomer()
        } else {
            binding.tvTitle.text = getString(R.string.edit_title_new)
            binding.noteLogSection.visibility = View.GONE // Notizen erst möglich, sobald der Kontakt gespeichert ist
            addPropertyRow()
            updateFollowUpLabel()

            val prefillName = intent.getStringExtra(EXTRA_PREFILL_NAME).orEmpty()
            val prefillPhone = intent.getStringExtra(EXTRA_PREFILL_PHONE).orEmpty()
            val prefillEmail = intent.getStringExtra(EXTRA_PREFILL_EMAIL).orEmpty()
            val prefillNotes = intent.getStringExtra(EXTRA_PREFILL_NOTES).orEmpty()
            val prefillStatus = intent.getStringExtra(EXTRA_PREFILL_STATUS).orEmpty()
            val prefillTags = intent.getStringExtra(EXTRA_PREFILL_TAGS).orEmpty()
            val prefillObjekt = intent.getStringExtra(EXTRA_PREFILL_OBJEKT).orEmpty()
            val prefillProgress = intent.getStringExtra(EXTRA_PREFILL_PROGRESS).orEmpty()
            if (prefillName.isNotBlank() || prefillPhone.isNotBlank()) {
                binding.etName.setText(prefillName)
                binding.etPhone.setText(prefillPhone)
                binding.etEmail.setText(prefillEmail)
                if (prefillNotes.isNotBlank()) {
                    binding.etNotes.setText("Aus Foto erkannt:\n$prefillNotes")
                }
                if (prefillStatus.isNotBlank()) {
                    val idx = de.immokarte.anrufkarte.data.StatusInfo.keys.indexOf(prefillStatus)
                    if (idx >= 0) binding.spinnerStatus.setSelection(idx)
                }
                if (prefillTags.isNotBlank()) binding.etTags.setText(prefillTags)
                if (prefillObjekt.isNotBlank()) propertyRows.firstOrNull()?.etAdresse?.setText(prefillObjekt)
                if (prefillProgress.isNotBlank()) {
                    binding.tvTitle.text = "${getString(R.string.edit_title_new)} ($prefillProgress)"
                }
                Toast.makeText(this, "Bitte erkannte Daten kurz prüfen und ggf. korrigieren.", Toast.LENGTH_LONG).show()
            }
        }
        binding.spinnerStatus.post { statusListenerActive = true }
    }

    private fun loadReferrerOptions() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            referrerOptions = withContext(Dispatchers.IO) { dao.getNamesForPicker(customerId) }
            val labels = listOf("Keiner") + referrerOptions.map { it.name }
            binding.spinnerReferrer.adapter = ArrayAdapter(this@CustomerEditActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            pendingReferrerSelection?.let { selectReferrer(it) }
        }
    }

    private var pendingReferrerSelection: Long? = null

    private fun selectReferrer(id: Long?) {
        if (id == null) { binding.spinnerReferrer.setSelection(0); return }
        val index = referrerOptions.indexOfFirst { it.id == id }
        if (index >= 0) binding.spinnerReferrer.setSelection(index + 1) else pendingReferrerSelection = id
    }

    private fun loadCustomer() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val match = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) }
            if (match == null) { finish(); return@launch }

            binding.etName.setText(match.customer.name)
            binding.etPhone.setText(match.customer.phone)
            binding.etPhone2.setText(match.customer.phone2)
            binding.etEmail.setText(match.customer.email)
            binding.spinnerLanguage.setSelection(if (match.customer.preferredLanguage == "en") 1 else 0)
            binding.etNotes.setText(match.customer.notes)
            binding.etTags.setText(match.customer.tags)
            binding.etProvision.setText(match.customer.provision)
            binding.etReachability.setText(match.customer.reachability)
            binding.etSearchOrt.setText(match.customer.searchOrt)
            binding.etBudgetMax.setText(match.customer.budgetMax)
            contractDateAt = match.customer.contractDateAt
            contractEventId = match.customer.contractEventId
            updateContractDateLabel()
            viewingAt = match.customer.viewingAt
            viewingEventId = match.customer.viewingEventId
            updateViewingLabel()
            binding.cbImportant.isChecked = match.customer.important
            selectReferrer(match.customer.referredById)
            binding.spinnerStatus.setSelection(de.immokarte.anrufkarte.data.StatusInfo.keys.indexOf(match.customer.status).coerceAtLeast(0))
            followUpAt = match.customer.followUpAt
            anniversaryAt = match.customer.anniversaryAt
            abschlussAt = match.customer.abschlussAt
            calendarEventId = match.customer.calendarEventId
            updateCalendarSyncLabel()
            noteLog = match.customer.noteLog
            updateFollowUpLabel()
            updateAnniversaryLabel()
            renderNoteLog()

            if (match.properties.isEmpty()) addPropertyRow()
            else match.properties.forEach { p -> addPropertyRow(p.typ, p.adresse, p.ort, p.preis, p.status, p.verkaufspreis, p.exposeUri) }
        }
    }

    private fun pickDate() {
        val cal = Calendar.getInstance()
        followUpAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            val picked = Calendar.getInstance().apply {
                set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            followUpAt = picked.timeInMillis
            updateFollowUpLabel()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun pickContractDate() {
        val cal = Calendar.getInstance()
        contractDateAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            val picked = Calendar.getInstance().apply {
                set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            contractDateAt = picked.timeInMillis
            updateContractDateLabel()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateContractDateLabel() {
        binding.tvContractDateValue.text = contractDateAt?.let { dateFmt.format(Date(it)) } ?: "—"
    }

    /** Besichtigungen brauchen anders als Wiedervorlage/Vertragstermin eine
     *  konkrete Uhrzeit — deshalb Datum- und Uhrzeit-Dialog nacheinander. */
    private fun pickViewingDateTime() {
        val cal = Calendar.getInstance()
        viewingAt?.let { cal.timeInMillis = it }
        DatePickerDialog(this, { _, year, month, day ->
            android.app.TimePickerDialog(this, { _, hour, minute ->
                val picked = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0)
                }
                viewingAt = picked.timeInMillis
                updateViewingLabel()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateViewingLabel() {
        binding.tvViewingValue.text = viewingAt?.let {
            SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(it))
        } ?: "—"
    }

    private fun updateFollowUpLabel() {
        binding.tvFollowUpValue.text = followUpAt?.let { dateFmt.format(Date(it)) } ?: "—"
        updateCalendarSyncLabel()
    }

    /** Öffnet ein Bearbeiten-Fenster für eine WhatsApp-Nachricht — du kannst
     *  den Text frei schreiben/anpassen, bevor irgendwas verschickt wird.
     *  Der "✨ Mit KI personalisieren"-Knopf erstellt (nur wenn ein eigener
     *  API-Schlüssel hinterlegt ist) einen Entwurf, der konkrete Details aus
     *  den Notizen zum Kontakt aufgreift. */
    private fun showComposeMessageDialog(initialText: String = "") {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (phone.isBlank()) {
            Toast.makeText(this, "Bitte zuerst eine Telefonnummer eintragen.", Toast.LENGTH_SHORT).show()
            return
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }
        val input = android.widget.EditText(this).apply {
            setText(initialText)
            minLines = 5
            gravity = android.view.Gravity.TOP
            hint = "Deine Nachricht…"
        }
        container.addView(input)

        AlertDialog.Builder(this)
            .setTitle("Nachricht schreiben")
            .setView(container)
            .setPositiveButton("WhatsApp öffnen") { _, _ ->
                val digits = phone.filter { it.isDigit() || it == '+' }.removePrefix("+")
                val link = de.immokarte.anrufkarte.data.WhatsAppTemplates.buildLinkFromText(digits, input.text.toString())
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    /** Fragt beim Setzen auf "Kauf abgeschlossen" direkt nach, ob die
     *  Abschluss-Nachricht (Bewertungs-/Tippgeber-Links) per WhatsApp
     *  vorbereitet werden soll — spart das manuelle Dran-Denken zum
     *  passenden Zeitpunkt. Die drei Links lassen sich unter ⚙️ Einstellungen
     *  jederzeit ändern, falls sie sich mal ändern sollten. */
    private fun promptReviewRequest() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val googleLink = prefs.getString("google_review_link", "").orEmpty()
            .ifBlank { "https://maps.app.goo.gl/Kt8qygixF1S9Hs8u9?g_st=ac" }
        val trustpilotLink = prefs.getString("trustpilot_link", "").orEmpty()
            .ifBlank { "https://de.trustpilot.com/review/betterhomes.de" }
        val referralLink = prefs.getString("referral_link", "").orEmpty()
            .ifBlank { "https://www.betterhomes.de/de/immobilie-verkaufen-oder-vermieten/tippgeber-programm" }
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()

        if (phone.isBlank()) return

        AlertDialog.Builder(this)
            .setTitle("🎉 Glückwunsch zum Abschluss!")
            .setMessage("Jetzt eine Nachricht mit Bewertungs-/Tippgeber-Links vorbereiten?")
            .setPositiveButton("Ja, Nachricht vorbereiten") { _, _ ->
                val text = """
                    Hallo $name,

                    es hat mich sehr gefreut, Sie auf dem Weg in Ihr neues Zuhause begleiten zu dürfen! 😊

                    Wenn Sie mit meiner Betreuung zufrieden waren, würde ich mich sehr über eine kurze Bewertung freuen:

                    ⭐ Google: $googleLink
                    ⭐ Trustpilot: $trustpilotLink

                    🎁 Jemanden im Umfeld, der eine Immobilie sucht oder verkaufen möchte?
                    Mehr Infos zu unserem Tippgeberprogramm: $referralLink

                    Vielen Dank für Ihre Unterstützung! 🙏
                """.trimIndent()
                showComposeMessageDialog(text)
            }
            .setNegativeButton("Später", null)
            .show()
    }

    private fun updateCalendarSyncLabel() {
        binding.tvCalendarSync.text = when {
            followUpAt == null -> ""
            !de.immokarte.anrufkarte.data.CalendarSync.hasPermission(this) -> "⚠ Kalender-Berechtigung fehlt — Termin wird nicht synchronisiert (in den App-Berechtigungen erlauben)"
            !de.immokarte.anrufkarte.data.CalendarSync.hasAnyCalendar(this) -> "⚠ Kein Kalender-Konto auf dem Gerät gefunden — Termin kann nicht synchronisiert werden"
            else -> "📅 Wird automatisch im Kalender synchronisiert"
        }
    }

    private fun updateAnniversaryLabel() {
        if (anniversaryAt != null) {
            binding.tvAnniversary.visibility = View.VISIBLE
            binding.tvAnniversary.text = "🎉 Jahrestag-Erinnerung: ${dateFmt.format(Date(anniversaryAt!!))}  (zum Entfernen tippen)"
            binding.tvAnniversary.setOnClickListener { anniversaryAt = null; updateAnniversaryLabel() }
        } else {
            binding.tvAnniversary.visibility = View.GONE
        }
    }

    private fun renderNoteLog() {
        binding.noteLogContainer.removeAllViews()
        val entries = NoteLogUtils.parse(noteLog).sortedByDescending { it.timestamp }
        if (entries.isEmpty()) {
            val tv = TextView(this).apply {
                text = "Noch keine Notizen."
                textSize = 12f
                setTextColor(0xFF8B93A0.toInt())
            }
            binding.noteLogContainer.addView(tv)
            return
        }
        entries.forEach { entry ->
            val row = LayoutInflater.from(this).let { _ ->
                android.widget.LinearLayout(this).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    setPadding(20, 14, 20, 14)
                    setBackgroundResource(R.drawable.bg_paper_pill)
                    val params = android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.bottomMargin = 8
                    layoutParams = params
                }
            }
            val tvDate = TextView(this).apply {
                text = SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(Date(entry.timestamp))
                textSize = 10.5f
                setTextColor(0xFF8B93A0.toInt())
            }
            val tvText = TextView(this).apply {
                text = entry.text
                textSize = 13f
                setTextColor(0xFF20242B.toInt())
            }
            row.addView(tvDate)
            row.addView(tvText)
            binding.noteLogContainer.addView(row)
        }
    }

    private fun addNoteFromInput() {
        val text = binding.etNewNote.text.toString().trim()
        if (text.isEmpty() || customerId < 0) return
        noteLog = NoteLogUtils.append(noteLog, NoteEntry(System.currentTimeMillis(), text))
        binding.etNewNote.text.clear()
        renderNoteLog()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().updateNoteLog(customerId, noteLog) }
        }
    }

    private fun addPropertyRow(
        typ: String = "Wohnung", adresse: String = "", ort: String = "", preis: String = "",
        status: String = "interessiert", verkaufspreis: String = "", exposeUri: String = ""
    ) {
        val rowBinding = ItemPropertyEditBinding.inflate(LayoutInflater.from(this), binding.propertiesContainer, false)
        rowBinding.spinnerTyp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, propertyTypes)
        rowBinding.spinnerTyp.setSelection(propertyTypes.indexOf(typ).let { if (it >= 0) it else 1 })
        rowBinding.spinnerPropStatus.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, propertyStatusLabels)
        rowBinding.spinnerPropStatus.setSelection(propertyStatuses.indexOf(status).coerceAtLeast(0))
        rowBinding.etAdresse.setText(adresse)
        rowBinding.etOrt.setText(ort)
        rowBinding.etPreis.setText(preis)
        rowBinding.etVerkaufspreis.setText(verkaufspreis)
        if (exposeUri.isNotBlank()) propertyExposeUris[rowBinding] = exposeUri
        updateExposeButtonLabel(rowBinding)

        rowBinding.btnAttachExpose.setOnClickListener {
            val current = propertyExposeUris[rowBinding]
            if (current != null) {
                // Bereits ein Exposé dran → anzeigen/öffnen
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(Uri.parse(current), "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                }.onFailure { Toast.makeText(this, "Kein PDF-Betrachter gefunden.", Toast.LENGTH_SHORT).show() }
            } else {
                pendingExposeTarget = rowBinding
                pickExposeFile.launch(arrayOf("application/pdf"))
            }
        }

        rowBinding.btnMatchInterested.setOnClickListener {
            showMatchingInterested(rowBinding.etOrt.text.toString().trim(), rowBinding.etPreis.text.toString().trim().filter { it.isDigit() })
        }

        rowBinding.btnRemoveProperty.setOnClickListener {
            binding.propertiesContainer.removeView(rowBinding.root)
            propertyRows.remove(rowBinding)
            propertyExposeUris.remove(rowBinding)
        }
        propertyRows += rowBinding
        binding.propertiesContainer.addView(rowBinding.root)
    }

    private fun updateExposeButtonLabel(rowBinding: ItemPropertyEditBinding) {
        rowBinding.btnAttachExpose.text = if (propertyExposeUris.containsKey(rowBinding)) "📎 Exposé ✓" else "📎 Exposé"
    }

    /** Zeigt Kontakte, deren gesuchter Ort zum Objekt passt und deren Budget
     *  (falls angegeben) ausreicht. */
    private fun showMatchingInterested(ort: String, preis: String) {
        if (ort.isBlank()) {
            Toast.makeText(this, "Bitte zuerst einen Ort beim Objekt eintragen.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val candidates = withContext(Dispatchers.IO) { dao.getCustomersWithSearchCriteria(customerId) }
            val preisLong = preis.toLongOrNull()
            val matches = candidates.filter { c ->
                val ortMatch = c.searchOrt.contains(ort, ignoreCase = true) || ort.contains(c.searchOrt, ignoreCase = true)
                val budgetOk = c.budgetMax.isBlank() || preisLong == null || (c.budgetMax.toLongOrNull() ?: Long.MAX_VALUE) >= preisLong
                ortMatch && budgetOk
            }
            if (matches.isEmpty()) {
                Toast.makeText(this@CustomerEditActivity, "Keine passenden Interessenten gefunden.", Toast.LENGTH_SHORT).show()
            } else {
                AlertDialog.Builder(this@CustomerEditActivity)
                    .setTitle("Passende Interessenten (${matches.size})")
                    .setItems(matches.map { "${it.name} — sucht in „${it.searchOrt}“${if (it.budgetMax.isNotBlank()) ", Budget bis ${it.budgetMax} €" else ""}" }.toTypedArray()) { _, i ->
                        startActivity(Intent(this@CustomerEditActivity, CustomerEditActivity::class.java).putExtra(EXTRA_CUSTOMER_ID, matches[i].id))
                    }
                    .setNegativeButton("Schließen", null)
                    .show()
            }
        }
    }

    private fun save() {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_name_phone_required), Toast.LENGTH_SHORT).show()
            return
        }
        val phone2 = binding.etPhone2.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val preferredLanguage = if (binding.spinnerLanguage.selectedItemPosition == 1) "en" else "de"
        val notes = binding.etNotes.text.toString().trim()
        val tags = binding.etTags.text.toString().trim()
        val provision = binding.etProvision.text.toString().trim().filter { it.isDigit() }
        val reachability = binding.etReachability.text.toString().trim()
        val searchOrt = binding.etSearchOrt.text.toString().trim()
        val budgetMax = binding.etBudgetMax.text.toString().trim().filter { it.isDigit() }
        val referredById = binding.spinnerReferrer.selectedItemPosition
            .let { pos -> if (pos <= 0) null else referrerOptions.getOrNull(pos - 1)?.id }
        val status = de.immokarte.anrufkarte.data.StatusInfo.keys[binding.spinnerStatus.selectedItemPosition]
        val important = binding.cbImportant.isChecked
        val normalized = PhoneUtils.normalize(phone)
        val normalized2 = if (phone2.isNotBlank()) PhoneUtils.normalize(phone2) else ""

        val properties = propertyRows.mapNotNull { row ->
            val adresse = row.etAdresse.text.toString().trim()
            val ort = row.etOrt.text.toString().trim()
            val preis = row.etPreis.text.toString().trim().filter { it.isDigit() }
            val verkaufspreis = row.etVerkaufspreis.text.toString().trim().filter { it.isDigit() }
            val typ = propertyTypes[row.spinnerTyp.selectedItemPosition]
            val propStatus = propertyStatuses[row.spinnerPropStatus.selectedItemPosition]
            val exposeUri = propertyExposeUris[row] ?: ""
            if (adresse.isBlank() && ort.isBlank() && preis.isBlank()) null
            else PropertyDraft(typ, adresse, ort, preis, propStatus, verkaufspreis, exposeUri)
        }

        if (customerId < 0) {
            // Neuer Kontakt: prüfen, ob die Nummer schon existiert, bevor gespeichert wird
            // (deckt auch den Foto-Import ab, der über denselben Weg läuft).
            lifecycleScope.launch {
                val dao = AppDatabase.getInstance(applicationContext).customerDao()
                val existingId = withContext(Dispatchers.IO) { dao.findIdByPhone(normalized) }
                if (existingId != null) {
                    val existing = withContext(Dispatchers.IO) { dao.getByIdWithProperties(existingId) }
                    AlertDialog.Builder(this@CustomerEditActivity)
                        .setTitle("Nummer bereits vorhanden")
                        .setMessage("Diese Telefonnummer gehört bereits zu „${existing?.customer?.name}“. Wie möchtest du fortfahren?")
                        .setPositiveButton("Bestehenden bearbeiten") { _, _ ->
                            startActivity(Intent(this@CustomerEditActivity, CustomerEditActivity::class.java).putExtra(EXTRA_CUSTOMER_ID, existingId))
                            setResult(RESULT_OK)
                            finish()
                        }
                        .setNeutralButton("Trotzdem neu anlegen") { _, _ -> performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties) }
                        .setNegativeButton("Abbrechen", null)
                        .show()
                } else {
                    performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties)
                }
            }
        } else {
            performSave(name, phone, normalized, phone2, normalized2, email, preferredLanguage, notes, tags, provision, reachability, searchOrt, budgetMax, referredById, status, important, properties)
        }
    }

    private fun performSave(
        name: String, phone: String, normalized: String, phone2: String, normalized2: String, email: String, preferredLanguage: String, notes: String, tags: String,
        provision: String, reachability: String, searchOrt: String, budgetMax: String, referredById: Long?,
        status: String, important: Boolean, properties: List<PropertyDraft>
    ) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val syncedEventId = withContext(Dispatchers.IO) {
                val start = followUpAt?.plus(9 * 60 * 60 * 1000L)
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, calendarEventId, "Wiedervorlage: $name", "Anruf-Karte — $phone", start, start?.plus(30 * 60 * 1000L)
                )
            }
            val syncedContractEventId = withContext(Dispatchers.IO) {
                val start = contractDateAt?.plus(9 * 60 * 60 * 1000L)
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, contractEventId, "Vertragstermin: $name", "Anruf-Karte — $phone", start, start?.plus(60 * 60 * 1000L)
                )
            }
            val syncedViewingEventId = withContext(Dispatchers.IO) {
                de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                    applicationContext, viewingEventId, "Besichtigung: $name", "Anruf-Karte — $phone", viewingAt, viewingAt?.plus(45 * 60 * 1000L)
                )
            }
            withContext(Dispatchers.IO) {
                val id = dao.insertCustomer(
                    CustomerEntity(
                        id = if (customerId >= 0) customerId else 0,
                        name = name, phone = phone, phoneNormalized = normalized, phone2 = phone2, phone2Normalized = normalized2,
                        email = email, notes = notes,
                        noteLog = noteLog, status = status, followUpAt = followUpAt, important = important, tags = tags,
                        anniversaryAt = anniversaryAt, provision = provision, referredById = referredById,
                        reachability = reachability, abschlussAt = abschlussAt, calendarEventId = syncedEventId,
                        searchOrt = searchOrt, budgetMax = budgetMax, contractDateAt = contractDateAt,
                        contractEventId = syncedContractEventId, preferredLanguage = preferredLanguage,
                        viewingAt = viewingAt, viewingEventId = syncedViewingEventId
                    )
                )
                dao.deletePropertiesForCustomer(id)
                if (properties.isNotEmpty()) {
                    dao.insertProperties(properties.map {
                        PropertyEntity(
                            customerId = id, typ = it.typ, adresse = it.adresse, ort = it.ort, preis = it.preis,
                            status = it.status, verkaufspreis = it.verkaufspreis, exposeUri = it.exposeUri
                        )
                    })
                }
            }
            FollowUpWidgetProvider.updateAll(applicationContext)
            setResult(RESULT_OK)
            finish()
        }
    }



    /** Öffnet den Telefon-Kontakte-Dialog vorausgefüllt — Nutzer speichert selbst,
     *  kein WRITE_CONTACTS-Recht nötig. */
    private fun addToPhoneContacts() {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_name_phone_required), Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, name)
            putExtra(ContactsContract.Intents.Insert.PHONE, phone)
        }
        runCatching { startActivity(intent) }
            .onFailure { Toast.makeText(this, "Kontakte-App konnte nicht geöffnet werden.", Toast.LENGTH_SHORT).show() }
    }

    /** Exportiert genau diesen Kontakt als JSON-Datei und öffnet den System-Teilen-Dialog.
     *  Ein Kollege mit derselben App kann die Datei direkt über "Wiederherstellen"
     *  importieren — die Daten (inkl. Objekte, Notizen) werden dann automatisch übernommen. */
    private fun shareCustomer() {
        if (customerId < 0) {
            Toast.makeText(this, "Bitte den Kontakt zuerst speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val data = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch

            val safeName = data.customer.name.ifBlank { "kontakt" }.replace(Regex("[^A-Za-z0-9-]+"), "_")
            val file = File(cacheDir, "$safeName-anrufkarte.json")
            withContext(Dispatchers.IO) {
                val uri = Uri.fromFile(file)
                BackupManager.export(this@CustomerEditActivity, uri, listOf(data))
            }

            val contentUri = FileProvider.getUriForFile(this@CustomerEditActivity, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Kontakt: ${data.customer.name}")
                putExtra(Intent.EXTRA_TEXT, "Kontakt „${data.customer.name}“ aus der Anruf-Karte — mit derselben App über \"Wiederherstellen\" importierbar.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Kontakt teilen"))
        }
    }

    private fun exportPdf(uri: Uri) {
        if (customerId < 0) {
            Toast.makeText(this, "Bitte den Kontakt zuerst speichern.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val data = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) } ?: return@launch
            withContext(Dispatchers.IO) { PdfExporter.export(this@CustomerEditActivity, uri, data) }
            Toast.makeText(this@CustomerEditActivity, "PDF-Steckbrief gespeichert.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_message))
            .setPositiveButton(getString(R.string.btn_delete)) { _, _ -> deleteCustomer() }
            .setNegativeButton(getString(R.string.btn_cancel), null)
            .show()
    }

    private fun deleteCustomer() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val fullData = withContext(Dispatchers.IO) { dao.getByIdWithProperties(customerId) }
            withContext(Dispatchers.IO) {
                calendarEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                contractEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                viewingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                dao.deleteCustomerById(customerId)
            }
            if (fullData != null) {
                de.immokarte.anrufkarte.data.UndoManager.set("Kontakt gelöscht: ${fullData.customer.name}") {
                    withContext(Dispatchers.IO) {
                        dao.insertCustomer(fullData.customer)
                        if (fullData.properties.isNotEmpty()) dao.insertProperties(fullData.properties)
                    }
                }
            }
            FollowUpWidgetProvider.updateAll(applicationContext)
            setResult(RESULT_OK)
            finish()
        }
    }
}
