package de.immokarte.anrufkarte.data

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class TableRow(
    val statusRaw: String,
    val name: String,
    val phone: String,
    val objekt: String
)

/**
 * Erkennt tabellarische Kontaktlisten (Status | Name | Telefon | Objekt),
 * wie sie z. B. aus dem Betterhomes-CRM abfotografiert werden.
 *
 * Vorgehen (gegen echte Testfotos geprüft und danach angepasst):
 * 1. Kopfzeile finden (Status/Name/Telefon/Objekt) und daraus Spaltengrenzen
 *    als MITTELPUNKT zwischen benachbarten Kopfzeilen ableiten — robuster als
 *    eine harte Kante an der exakten Kopfzeilen-Position, da einzelne
 *    Buchstaben durch die Texterkennung leicht ein paar Pixel daneben liegen.
 * 2. Als Zeilen-Anker dient nicht "eine Zeile mit vollständiger Telefonnummer"
 *    (Telefonnummern werden von der Texterkennung manchmal in zwei Fragmente
 *    zerlegt, z. B. Vorwahl "0049" getrennt von der restlichen Nummer),
 *    sondern alle Textfragmente INNERHALB der Telefon-Spalte werden zunächst
 *    nach vertikaler Nähe gruppiert — das ergibt zuverlässig eine Gruppe pro
 *    Tabellenzeile, unabhängig davon, ob die Nummer in einem oder mehreren
 *    Fragmenten erkannt wurde.
 *
 * Bekannte Grenze: Sehr kleine/farbig hervorgehobene Status-Badges werden von
 * der Texterkennung manchmal komplett übersehen (bei Tests beobachtet). Das
 * ist unkritisch — Name/Telefon/Objekt sind davon unabhängig, und der Status
 * lässt sich beim Durchgehen der Kontakte jederzeit manuell nachtragen.
 */
object TableOcrHelper {

    private val statusSynonyms = mapOf(
        "pendent" to "pendent",
        "interessent" to "interessent",
        "besichtigung" to "besichtigung",
        "besichtigung vereinbart" to "besichtigung",
        "kunde" to "kunde",
        "abgelehnt" to "abgelehnt",
        "abschluss" to "abschluss",
        "kauf abgeschlossen" to "abschluss",
        "angebot" to "angebot",
        "angebot abgegeben" to "angebot",
    )

    /** Ordnet den erkannten Status-Text einem App-Status zu, falls möglich.
     *  Sonst bleibt der Status auf "Interessent" und der Originaltext wird
     *  als Tag zurückgegeben (z. B. "Wiedervorlage"), damit nichts verloren geht. */
    fun resolveStatus(raw: String): Pair<String, String?> {
        val key = raw.trim().lowercase()
        val matched = statusSynonyms[key]
        return if (matched != null) matched to null else "interessent" to raw.trim().ifBlank { null }
    }

    /** Liefert eine leere Liste, wenn keine Tabelle mit Name- und
     *  Telefon-Kopfzeile erkannt wurde (dann sollte der Aufrufer auf die
     *  Einzelkontakt-Erkennung zurückfallen). */
    suspend fun parseTable(bitmap: Bitmap): List<TableRow> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val result = recognizer.process(image).await()

        val lines = result.textBlocks.flatMap { it.lines }
            .mapNotNull { line -> line.boundingBox?.let { box -> Pair(line.text.trim(), box) } }
            .filter { it.first.isNotBlank() }
        if (lines.isEmpty()) return emptyList()

        var statusX: Int? = null
        var nameX: Int? = null
        var telefonX: Int? = null
        var objektX: Int? = null
        var headerBottom = 0

        lines.forEach { (text, box) ->
            val t = text.lowercase()
            when {
                t.contains("status") && statusX == null -> { statusX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("name") && nameX == null -> { nameX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("telefon") && telefonX == null -> { telefonX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
                t.contains("objekt") && objektX == null -> { objektX = box.left; headerBottom = maxOf(headerBottom, box.bottom) }
            }
        }

        // Ohne erkennbare Name- und Telefon-Spalte lohnt sich der Tabellenmodus nicht.
        val nX = nameX ?: return emptyList()
        val tX = telefonX ?: return emptyList()
        val sX = statusX ?: 0

        // Spaltengrenzen als Mittelpunkt zwischen den Kopfzeilen (siehe Klassen-Kommentar).
        val statusEnd = (sX + nX) / 2
        val nameEnd = (nX + tX) / 2
        val telefonEnd = if (objektX != null) (tX + objektX!!) / 2 else tX + 300

        val dataLines = lines.filter { it.second.top > headerBottom }
        val heights = dataLines.map { it.second.height() }.sorted()
        val lineHeight = if (heights.isNotEmpty()) heights[heights.size / 2] else 40

        // Telefon-Spalten-Fragmente sammeln und nach vertikaler Nähe zu Zeilen gruppieren.
        val telCandidates = dataLines
            .filter { it.second.left in nameEnd until telefonEnd }
            .sortedBy { it.second.top }

        val clusters = mutableListOf<MutableList<Pair<String, android.graphics.Rect>>>()
        telCandidates.forEach { line ->
            val last = clusters.lastOrNull()
            if (last != null && line.second.top - last.last().second.top < (lineHeight * 0.8).toInt()) {
                last.add(line)
            } else {
                clusters.add(mutableListOf(line))
            }
        }

        val rows = mutableListOf<TableRow>()
        clusters.forEach { cluster ->
            val top = cluster.minOf { it.second.top }
            val bottom = cluster.maxOf { it.second.bottom }
            val bandTop = top - (lineHeight * 1.3).toInt()
            val bandBottom = bottom + (lineHeight * 1.3).toInt()

            fun cellText(colStart: Int, colEnd: Int): String =
                dataLines.filter {
                    it.second.top in bandTop..bandBottom && it.second.left in colStart until colEnd
                }.sortedBy { it.second.top }.joinToString(" ") { it.first }.trim()

            val statusText = cellText(0, statusEnd)
            val nameText = cellText(statusEnd, nameEnd)
            val objektText = cellText(telefonEnd, telefonEnd + 10_000)
            val phoneText = cluster.sortedBy { it.second.left }.joinToString(" ") { it.first }.trim()

            if (nameText.isNotBlank() && phoneText.isNotBlank()) {
                rows += TableRow(statusRaw = statusText, name = nameText, phone = phoneText, objekt = objektText)
            }
        }

        return rows
    }
}
