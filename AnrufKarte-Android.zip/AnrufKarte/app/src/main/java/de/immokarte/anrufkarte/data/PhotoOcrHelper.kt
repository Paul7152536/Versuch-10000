package de.immokarte.anrufkarte.data

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class OcrResult(val name: String, val phone: String, val email: String, val rawText: String)

/** Erkennt Text auf einem Foto (z. B. abfotografierter CRM-Bildschirm) und
 *  versucht, Name/Telefon/E-Mail heuristisch herauszufiltern. Läuft
 *  vollständig offline auf dem Gerät (Google ML Kit). */
object PhotoOcrHelper {

    private val phoneRegex = Regex("""(\+?\d[\d\s\-/()]{7,}\d)""")
    private val emailRegex = Regex("""[\w.+-]+@[\w-]+\.[\w.-]+""")

    suspend fun recognize(bitmap: Bitmap): OcrResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val result = recognizer.process(image).await()
        val lines = result.textBlocks.flatMap { it.lines }.map { it.text.trim() }.filter { it.isNotBlank() }

        val phone = lines.firstNotNullOfOrNull { line -> phoneRegex.find(line)?.value?.trim() } ?: ""
        val email = lines.firstNotNullOfOrNull { line -> emailRegex.find(line)?.value } ?: ""

        // Grobe Heuristik: erste Zeile, die wie ein Name aussieht (2–4 großgeschriebene Wörter,
        // keine Telefonnummer/E-Mail).
        val name = lines.firstOrNull { line ->
            !phoneRegex.containsMatchIn(line) && !emailRegex.containsMatchIn(line) &&
                line.split(" ").count { it.isNotBlank() } in 2..4 &&
                line.firstOrNull { it.isLetter() }?.isUpperCase() == true
        } ?: ""

        return OcrResult(name = name, phone = phone, email = email, rawText = lines.joinToString("\n"))
    }
}
