package de.immokarte.anrufkarte

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerEntity
import de.immokarte.anrufkarte.data.PendingImportHolder
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.PropertyEntity
import de.immokarte.anrufkarte.data.StatusInfo
import de.immokarte.anrufkarte.data.TableOcrHelper
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Zeigt die aus einem Tabellen-Foto erkannten Kontakte zur Prüfung an —
 *  einzeln abwählbar, bevor irgendwas in der Datenbank landet. */
class PhotoTableReviewActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_photo_table_review)

        val rows = PendingImportHolder.rows
        val container = findViewById<LinearLayout>(R.id.reviewContainer)
        val tvCount = findViewById<TextView>(R.id.tvReviewCount)
        val btnImport = findViewById<Button>(R.id.btnImportSelected)

        tvCount.text = "${rows.size} Kontakt${if (rows.size == 1) "" else "e"} erkannt — bitte kurz prüfen, unpassende Zeilen abwählen"

        val checkBoxes = mutableListOf<CheckBox>()

        rows.forEach { row ->
            val (statusKey, tag) = TableOcrHelper.resolveStatus(row.statusRaw)

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 20, 24, 20)
                setBackgroundResource(R.drawable.bg_card)
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = 10
                layoutParams = params
            }

            val topRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val cb = CheckBox(this).apply { isChecked = true }
            checkBoxes += cb
            val tvName = TextView(this).apply {
                text = row.name.ifBlank { "(kein Name erkannt)" }
                textSize = 14f
                setTextColor(0xFF20242B.toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            topRow.addView(cb)
            topRow.addView(tvName)
            card.addView(topRow)

            val tvDetails = TextView(this).apply {
                text = buildString {
                    append(row.phone)
                    if (row.objekt.isNotBlank()) append(" · ").append(row.objekt)
                    append(" · Status: ").append(StatusInfo.label(statusKey))
                    if (tag != null) append(" (Tag: $tag)")
                }
                textSize = 11.5f
                setTextColor(0xFF8B93A0.toInt())
                setPadding(64, 4, 0, 0)
            }
            card.addView(tvDetails)
            container.addView(card)
        }

        if (rows.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Keine Zeilen erkannt."
                setTextColor(0xFF8B93A0.toInt())
            })
            btnImport.isEnabled = false
        }

        btnImport.setOnClickListener {
            lifecycleScope.launch {
                val dao = AppDatabase.getInstance(applicationContext).customerDao()
                var count = 0
                withContext(Dispatchers.IO) {
                    rows.forEachIndexed { i, row ->
                        if (!checkBoxes[i].isChecked) return@forEachIndexed
                        if (row.name.isBlank() || row.phone.isBlank()) return@forEachIndexed
                        val (statusKey, tag) = TableOcrHelper.resolveStatus(row.statusRaw)
                        val normalized = PhoneUtils.normalize(row.phone)
                        val existingId = dao.findIdByPhone(normalized)
                        val id = dao.insertCustomer(
                            CustomerEntity(
                                id = existingId ?: 0,
                                name = row.name,
                                phone = row.phone,
                                phoneNormalized = normalized,
                                status = statusKey,
                                tags = tag ?: ""
                            )
                        )
                        if (row.objekt.isNotBlank()) {
                            dao.deletePropertiesForCustomer(id)
                            dao.insertProperties(
                                listOf(PropertyEntity(customerId = id, typ = "Wohnung", adresse = row.objekt, ort = "", preis = ""))
                            )
                        }
                        count++
                    }
                }
                FollowUpWidgetProvider.updateAll(applicationContext)
                Toast.makeText(this@PhotoTableReviewActivity, "$count Kontakte importiert.", Toast.LENGTH_LONG).show()
                PendingImportHolder.rows = emptyList()
                setResult(RESULT_OK)
                finish()
            }
        }
    }
}
