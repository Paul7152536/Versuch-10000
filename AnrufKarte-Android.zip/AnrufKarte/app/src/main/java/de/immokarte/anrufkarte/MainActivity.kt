package de.immokarte.anrufkarte

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.BackupManager
import de.immokarte.anrufkarte.data.CsvImporter
import de.immokarte.anrufkarte.data.CustomerEntity
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.PhotoOcrHelper
import de.immokarte.anrufkarte.data.PropertyEntity
import de.immokarte.anrufkarte.databinding.ActivityMainBinding
import de.immokarte.anrufkarte.reminder.AlarmScheduler
import de.immokarte.anrufkarte.ui.CustomerAdapter
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: CustomerAdapter
    private var allCustomers: List<CustomerWithProperties> = emptyList()
    private var query: String = ""
    private var filter: String = "alle"
    private var unlocked = false

    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { checkPermissionState() }

    private val pickCsv =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { importCsv(it) } }

    private val pickBackupToImport =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { importBackup(it) } }

    private val pickBackupLocation =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? -> uri?.let { exportBackup(it) } }

    private val editCustomer =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) loadCustomers()
            if (walkthroughRows.isNotEmpty()) showNextWalkthroughContact()
        }

    private var walkthroughRows: List<de.immokarte.anrufkarte.data.TableRow> = emptyList()
    private var walkthroughIndex: Int = 0

    private var pendingCameraUri: Uri? = null

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) pendingCameraUri?.let { processImageForOcr(it) }
        }

    private val pickImageForOcr =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> uri?.let { processImageForOcr(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.visibility = android.view.View.INVISIBLE

        authenticateThenInit()
    }

    private fun authenticateThenInit() {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            // Kein PIN/Muster/Biometrie auf dem Gerät eingerichtet — App-Sperre übersprungen.
            unlocked = true
            initApp()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true
                initApp()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (!unlocked) finish()
            }
        })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Anruf-Karte entsperren")
            .setSubtitle("Schützt die Kundendaten")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(promptInfo)
    }

    private fun initApp() {
        binding.root.visibility = android.view.View.VISIBLE

        adapter = CustomerAdapter(
            onClick = { id ->
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, id))
            },
            onToggleStar = { id, important -> toggleImportant(id, important) },
            onCall = { phone -> startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) },
            onDismissMissed = { id -> dismissMissed(id) }
        )
        binding.recyclerCustomers.layoutManager = LinearLayoutManager(this)
        binding.recyclerCustomers.adapter = adapter
        attachSwipeActions()

        binding.btnPermissions.setOnClickListener { requestNeededPermissions() }
        binding.btnImportCsv.setOnClickListener { pickCsv.launch(arrayOf("text/comma-separated-values", "text/csv", "text/*")) }
        binding.btnAddCustomer.setOnClickListener { editCustomer.launch(Intent(this, CustomerEditActivity::class.java)) }
        binding.btnPhotoImport.setOnClickListener { startPhotoImport() }
        binding.btnExport.setOnClickListener { pickBackupLocation.launch("anruf-karte-backup.json") }
        binding.btnImportBackup.setOnClickListener { pickBackupToImport.launch(arrayOf("application/json", "text/*")) }
        binding.btnMore.setOnClickListener { showMoreMenu() }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty(); applyFilters() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        setupFilterChips()
        checkPermissionState()
        loadCustomers()
        AlarmScheduler.scheduleDaily(this)
        checkBackupReminder()
        handleShortcutIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (unlocked) handleShortcutIntent(intent)
    }

    private fun handleShortcutIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data?.let { importSharedFile(it) }
            Intent.ACTION_SEND -> (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { importSharedFile(it) }
        }
        when (intent?.getStringExtra("shortcut_action")) {
            "new_contact" -> editCustomer.launch(Intent(this, CustomerEditActivity::class.java))
            "import_csv" -> pickCsv.launch(arrayOf("text/comma-separated-values", "text/csv", "text/*"))
        }
    }

    private fun importSharedFile(uri: Uri) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val count = runCatching {
                withContext(Dispatchers.IO) { BackupManager.import(this@MainActivity, uri, dao) }
            }.getOrNull()
            if (count == null || count == 0) {
                Toast.makeText(this@MainActivity, "Datei konnte nicht als Kontakt gelesen werden.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@MainActivity, "$count Kontakt${if (count == 1) "" else "e"} übernommen.", Toast.LENGTH_LONG).show()
                loadCustomers()
            }
        }
    }

    private fun checkBackupReminder() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val lastBackup = prefs.getLong("last_backup_at", 0L)
        val sevenDays = 7 * 24 * 60 * 60 * 1000L
        if (System.currentTimeMillis() - lastBackup > sevenDays) {
            binding.tvBackupReminder.visibility = android.view.View.VISIBLE
            binding.tvBackupReminder.text = if (lastBackup == 0L)
                "💾 Noch kein Backup gemacht — jetzt sichern?" else
                "💾 Letztes Backup ist über eine Woche her — jetzt sichern?"
        } else {
            binding.tvBackupReminder.visibility = android.view.View.GONE
        }
        binding.tvBackupReminder.setOnClickListener { pickBackupLocation.launch("anruf-karte-backup.json") }
    }

    override fun onResume() {
        super.onResume()
        if (unlocked) checkPermissionState()
    }

    private fun setupFilterChips() {
        val filters = listOf(
            "alle" to getString(R.string.filter_alle),
            "faellig" to getString(R.string.filter_faellig),
            "unbetreut" to "Lange nicht kontaktiert (offen)"
        ) + de.immokarte.anrufkarte.data.StatusInfo.options.map { it.key to it.label }

        binding.filterContainer.removeAllViews()
        filters.forEach { (key, label) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12.5f
                setPadding(28, 16, 28, 16)
                setTextColor(if (key == filter) 0xFFF5F1E7.toInt() else 0xFF5C6470.toInt())
                setBackgroundResource(if (key == filter) R.drawable.bg_navy_pill else R.drawable.bg_card)
                setOnClickListener { filter = key; setupFilterChips(); applyFilters() }
            }
            val params = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 8
            binding.filterContainer.addView(tv, params)
        }
    }

    private fun showMoreMenu() {
        val popup = android.widget.PopupMenu(this, binding.btnMore)
        popup.menu.add(0, 1, 0, "📊 Statistik")
        popup.menu.add(0, 2, 1, "⚙️ Einstellungen")
        popup.menu.add(0, 3, 2, "🎉 Sammelgruß")
        popup.menu.add(0, 4, 3, "🧑‍🤝‍🧑 Vertretung")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> startActivity(Intent(this, StatsActivity::class.java))
                2 -> showSettingsDialog()
                3 -> startActivity(Intent(this, BulkGreetingActivity::class.java))
                4 -> showVertretungDialog()
            }
            true
        }
        popup.show()
    }

    private fun showSettingsDialog() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val scroll = android.widget.ScrollView(this)
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 10, 40, 10)
        }
        scroll.addView(container)

        val label1 = TextView(this).apply { text = "Google-Bewertungslink"; textSize = 12f; setPadding(0, 10, 0, 4) }
        val input1 = android.widget.EditText(this).apply {
            setText(prefs.getString("google_review_link", ""))
            hint = "https://g.page/r/....../review"
        }
        val label2 = TextView(this).apply { text = "Katalog-/Objektübersicht-Link"; textSize = 12f; setPadding(0, 16, 0, 4) }
        val input2 = android.widget.EditText(this).apply {
            setText(prefs.getString("catalog_link", ""))
            hint = "z. B. dein Betterhomes-Profil"
        }

        val label3 = TextView(this).apply { text = "Kalender für Termine (bei mehreren Konten)"; textSize = 12f; setPadding(0, 16, 0, 4) }
        val spinnerCalendar = android.widget.Spinner(this)
        val calendars = de.immokarte.anrufkarte.data.CalendarSync.listCalendars(this)
        val calendarLabels = listOf("Automatisch (Standard-Kalender)") + calendars.map { "${it.displayName} (${it.accountName})" }
        spinnerCalendar.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, calendarLabels)
        val currentCalendarId = prefs.getLong("selected_calendar_id", -1L)
        val preselect = calendars.indexOfFirst { it.id == currentCalendarId }
        spinnerCalendar.setSelection(if (preselect >= 0) preselect + 1 else 0)

        val label4 = TextView(this).apply { text = "Terminfarbe (Hex, leer = Kalender-Standardfarbe)"; textSize = 12f; setPadding(0, 16, 0, 4) }
        val input4 = android.widget.EditText(this).apply {
            setText(prefs.getString("calendar_event_color", ""))
            hint = "z. B. #A9823D"
        }

        listOf(label1, input1, label2, input2, label3, spinnerCalendar, label4, input4).forEach { container.addView(it) }

        AlertDialog.Builder(this)
            .setTitle("Einstellungen")
            .setView(scroll)
            .setPositiveButton("Speichern") { _, _ ->
                val chosenCalendarId = if (spinnerCalendar.selectedItemPosition == 0) -1L else calendars[spinnerCalendar.selectedItemPosition - 1].id
                val colorText = input4.text.toString().trim()
                val validColor = colorText.isBlank() || runCatching { android.graphics.Color.parseColor(colorText) }.isSuccess
                if (!validColor) {
                    Toast.makeText(this, "Ungültige Farbe — bitte Format #RRGGBB verwenden.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                prefs.edit()
                    .putString("google_review_link", input1.text.toString().trim())
                    .putString("catalog_link", input2.text.toString().trim())
                    .putLong("selected_calendar_id", chosenCalendarId)
                    .putString("calendar_event_color", colorText)
                    .apply()
                Toast.makeText(this, "Gespeichert.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun startPhotoImport() {
        AlertDialog.Builder(this)
            .setTitle("Kontakt aus Foto anlegen")
            .setItems(arrayOf("📷 Foto aufnehmen", "🖼 Aus Galerie wählen")) { _, which ->
                if (which == 0) launchCamera() else pickImageForOcr.launch("image/*")
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun launchCamera() {
        val file = File(cacheDir, "ocr_capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePicture.launch(uri)
    }

    /** Zeigt den nächsten aus dem Foto erkannten Kontakt im normalen
     *  Bearbeiten-Bildschirm — vorausgefüllt inkl. Status, Tag und Objekt.
     *  Wird nach jedem Speichern/Zurück automatisch für den nächsten
     *  erkannten Kontakt erneut aufgerufen (siehe editCustomer-Callback). */
    private fun showNextWalkthroughContact() {
        if (walkthroughIndex >= walkthroughRows.size) {
            if (walkthroughRows.isNotEmpty()) {
                Toast.makeText(this, "Alle erkannten Kontakte durchgegangen.", Toast.LENGTH_LONG).show()
            }
            walkthroughRows = emptyList()
            walkthroughIndex = 0
            return
        }
        val row = walkthroughRows[walkthroughIndex]
        val progress = "${walkthroughIndex + 1} von ${walkthroughRows.size}"
        walkthroughIndex++

        val (statusKey, tag) = de.immokarte.anrufkarte.data.TableOcrHelper.resolveStatus(row.statusRaw)
        val intent = Intent(this, CustomerEditActivity::class.java).apply {
            putExtra(CustomerEditActivity.EXTRA_PREFILL_NAME, row.name)
            putExtra(CustomerEditActivity.EXTRA_PREFILL_PHONE, row.phone)
            putExtra(CustomerEditActivity.EXTRA_PREFILL_STATUS, statusKey)
            putExtra(CustomerEditActivity.EXTRA_PREFILL_TAGS, tag ?: "")
            putExtra(CustomerEditActivity.EXTRA_PREFILL_OBJEKT, row.objekt)
            putExtra(CustomerEditActivity.EXTRA_PREFILL_PROGRESS, progress)
        }
        editCustomer.launch(intent)
    }

    private fun processImageForOcr(uri: Uri) {
        Toast.makeText(this, "Text wird erkannt …", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }.getOrNull()
            }
            if (bitmap == null) {
                Toast.makeText(this@MainActivity, "Foto konnte nicht gelesen werden.", Toast.LENGTH_SHORT).show()
                return@launch
            }

            // Erst prüfen, ob es eine Tabelle mit mehreren Kontakten ist
            // (erkennbar an einer Status/Name/Telefon-Kopfzeile).
            val tableRows = runCatching { de.immokarte.anrufkarte.data.TableOcrHelper.parseTable(bitmap) }.getOrNull().orEmpty()
            if (tableRows.isNotEmpty()) {
                Toast.makeText(
                    this@MainActivity,
                    "${tableRows.size} Kontakte erkannt — gehe sie nacheinander durch …",
                    Toast.LENGTH_LONG
                ).show()
                walkthroughRows = tableRows
                walkthroughIndex = 0
                showNextWalkthroughContact()
                return@launch
            }

            // Sonst wie gewohnt als Einzelkontakt behandeln.
            val result = runCatching { PhotoOcrHelper.recognize(bitmap) }.getOrNull()
            if (result == null || (result.name.isBlank() && result.phone.isBlank())) {
                Toast.makeText(this@MainActivity, "Kein Name/Telefon erkannt — bitte manuell eintragen.", Toast.LENGTH_LONG).show()
            }
            val intent = Intent(this@MainActivity, CustomerEditActivity::class.java).apply {
                putExtra(CustomerEditActivity.EXTRA_PREFILL_NAME, result?.name ?: "")
                putExtra(CustomerEditActivity.EXTRA_PREFILL_PHONE, result?.phone ?: "")
                putExtra(CustomerEditActivity.EXTRA_PREFILL_EMAIL, result?.email ?: "")
                putExtra(CustomerEditActivity.EXTRA_PREFILL_NOTES, result?.rawText ?: "")
            }
            editCustomer.launch(intent)
        }
    }

    private fun attachSwipeActions() {
        val callPaint = Paint().apply { color = Color.parseColor("#3E6B4F"); isAntiAlias = true }
        val snoozePaint = Paint().apply { color = Color.parseColor("#A9823D"); isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.WHITE; textSize = 34f; isAntiAlias = true; textAlign = Paint.Align.CENTER }

        val callback = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                val customer = adapter.itemAt(position) ?: return
                if (direction == ItemTouchHelper.RIGHT) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.customer.phone}")))
                } else {
                    postponeFollowUp(customer.customer.id, customer.customer.followUpAt)
                }
                adapter.notifyItemChanged(position)
            }

            override fun onChildDraw(
                c: Canvas, rv: RecyclerView, vh: RecyclerView.ViewHolder,
                dX: Float, dY: Float, actionState: Int, isActive: Boolean
            ) {
                super.onChildDraw(c, rv, vh, dX, dY, actionState, isActive)
                val itemView = vh.itemView
                val rect = RectF(itemView.left.toFloat(), itemView.top.toFloat(), itemView.right.toFloat(), itemView.bottom.toFloat())
                if (dX > 0) {
                    c.drawRoundRect(rect, 16f, 16f, callPaint)
                    c.drawText("📞 Anrufen", itemView.left + dX / 2, itemView.top + itemView.height / 2f + 12, textPaint)
                } else if (dX < 0) {
                    c.drawRoundRect(rect, 16f, 16f, snoozePaint)
                    c.drawText("⏰ +1 Woche", itemView.right + dX / 2, itemView.top + itemView.height / 2f + 12, textPaint)
                }
            }
        }
        ItemTouchHelper(callback).attachToRecyclerView(binding.recyclerCustomers)
    }

    private fun postponeFollowUp(id: Long, current: Long?) {
        val base = if (current != null && current > System.currentTimeMillis()) current else System.currentTimeMillis()
        val newDate = Calendar.getInstance().apply { timeInMillis = base; add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val customer = withContext(Dispatchers.IO) { dao.getByIdWithProperties(id)?.customer }
            withContext(Dispatchers.IO) {
                dao.setFollowUp(id, newDate)
                if (customer != null) {
                    val eventId = de.immokarte.anrufkarte.data.CalendarSync.syncFollowUp(
                        applicationContext, customer.calendarEventId, customer.name, customer.phone, newDate
                    )
                    dao.setCalendarEventId(id, eventId)
                }
            }
            if (customer != null) {
                de.immokarte.anrufkarte.data.UndoManager.set("Wiedervorlage verschoben") {
                    withContext(Dispatchers.IO) {
                        if (customer.followUpAt != null) {
                            dao.setFollowUp(id, customer.followUpAt)
                            val restoredEventId = de.immokarte.anrufkarte.data.CalendarSync.syncFollowUp(
                                applicationContext, dao.getByIdWithProperties(id)?.customer?.calendarEventId, customer.name, customer.phone, customer.followUpAt
                            )
                            dao.setCalendarEventId(id, restoredEventId)
                        }
                    }
                }
            }
            Toast.makeText(this@MainActivity, "Wiedervorlage um 1 Woche verschoben.", Toast.LENGTH_SHORT).show()
            loadCustomers()
        }
    }

    private fun toggleImportant(id: Long, important: Boolean) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().setImportant(id, important) }
            loadCustomers()
        }
    }

    private fun showVertretungDialog() {
        val prefs = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE)
        val activeUntil = prefs.getLong("vertretung_until", 0L)
        val importantCount = allCustomers.count { it.customer.important }

        val message = if (activeUntil > System.currentTimeMillis()) {
            "Vertretung ist aktiv bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(activeUntil))}.\n\n" +
                "$importantCount wichtige Kontakte können als Paket geteilt werden."
        } else {
            "Bündelt alle als „wichtig“ markierten Kontakte ($importantCount) in einer Datei und öffnet den Teilen-Dialog — " +
                "ein Kollege mit derselben App kann sie direkt übernehmen. Zusätzlich kannst du ein Enddatum als Erinnerung setzen."
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("🧑‍🤝‍🧑 Vertretung")
            .setMessage(message)
            .setPositiveButton("Paket teilen") { _, _ -> shareImportantContacts() }
            .setNeutralButton("Bis wann?") { _, _ -> pickVertretungDate() }
            .setNegativeButton("Schließen", null)

        if (activeUntil > 0) {
            builder.setNeutralButton("Beenden") { _, _ ->
                prefs.edit().putLong("vertretung_until", 0L).apply()
                updateVertretungBanner()
            }
        }
        builder.show()
    }

    private fun pickVertretungDate() {
        val cal = Calendar.getInstance()
        android.app.DatePickerDialog(this, { _, year, month, day ->
            val picked = Calendar.getInstance().apply { set(year, month, day, 23, 59, 59) }.timeInMillis
            getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).edit().putLong("vertretung_until", picked).apply()
            updateVertretungBanner()
            Toast.makeText(this, "Vertretung bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(picked))} vorgemerkt.", Toast.LENGTH_LONG).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun shareImportantContacts() {
        val important = allCustomers.filter { it.customer.important }
        if (important.isEmpty()) {
            Toast.makeText(this, "Keine als „wichtig“ markierten Kontakte vorhanden.", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val file = java.io.File(cacheDir, "vertretung-wichtige-kontakte.json")
            withContext(Dispatchers.IO) { BackupManager.export(this@MainActivity, Uri.fromFile(file), important) }
            val contentUri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Vertretung: ${important.size} wichtige Kontakte")
                putExtra(Intent.EXTRA_TEXT, "Wichtige Kontakte für die Vertretung — mit derselben App über \"Wiederherstellen\" importierbar.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Vertretungs-Paket teilen"))
        }
    }

    private fun updateVertretungBanner() {
        val until = getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).getLong("vertretung_until", 0L)
        if (until > System.currentTimeMillis()) {
            binding.tvVertretung.visibility = android.view.View.VISIBLE
            binding.tvVertretung.text = "🧑‍🤝‍🧑 Vertretung aktiv bis ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(until))} — Kontakte danach wieder selbst übernehmen"
        } else {
            binding.tvVertretung.visibility = android.view.View.GONE
        }
    }

    private fun updateUndoBanner() {
        val desc = de.immokarte.anrufkarte.data.UndoManager.peek()
        if (desc == null) {
            binding.tvUndo.visibility = android.view.View.GONE
            return
        }
        binding.tvUndo.visibility = android.view.View.VISIBLE
        binding.tvUndo.text = "↩️ $desc — antippen zum Rückgängigmachen"
        binding.tvUndo.setOnClickListener {
            lifecycleScope.launch {
                de.immokarte.anrufkarte.data.UndoManager.consume()
                binding.tvUndo.visibility = android.view.View.GONE
                loadCustomers()
            }
        }
    }

    private fun dismissMissed(id: Long) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val previous = withContext(Dispatchers.IO) { dao.getByIdWithProperties(id)?.customer?.missedCalls } ?: 0
            withContext(Dispatchers.IO) { dao.resetMissedCalls(id) }
            de.immokarte.anrufkarte.data.UndoManager.set("Verpasste Anrufe zurückgesetzt") {
                withContext(Dispatchers.IO) { dao.setMissedCalls(id, previous) }
            }
            loadCustomers()
        }
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf(android.Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) perms += android.Manifest.permission.READ_CALL_LOG
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms += android.Manifest.permission.POST_NOTIFICATIONS
        perms += android.Manifest.permission.READ_CALENDAR
        perms += android.Manifest.permission.WRITE_CALENDAR
        requestPermissions.launch(perms.toTypedArray())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        // Wichtig auf Geräten mit aggressivem Akku-Management (z. B. Samsung One UI):
        // ohne diese Ausnahme kann das System den Hintergrunddienst zum Erkennen von
        // Anrufen nach einiger Zeit im Standby-Modus einfach beenden.
        requestIgnoreBatteryOptimizations()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            }
        }
    }

    private fun checkPermissionState() {
        val phoneOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val callLogOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.P || ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
        val overlayOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        val calendarOk = de.immokarte.anrufkarte.data.CalendarSync.hasPermission(this)
        val batteryOk = (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)

        binding.tvPermissionStatus.text = when {
            phoneOk && callLogOk && overlayOk && calendarOk && batteryOk -> "✓ Berechtigungen erteilt — Erkennung + Kalender-Sync aktiv"
            !callLogOk -> "⚠ Anrufliste-Berechtigung fehlt — Rufnummer kann nicht gelesen werden"
            !calendarOk -> "⚠ Kalender-Berechtigung fehlt — Wiedervorlagen werden nicht synchronisiert"
            !batteryOk -> "⚠ Akku-Optimierung aktiv — Erkennung kann im Standby aussetzen (auf „Berechtigungen einrichten" tippen)"
            else -> "⚠ Berechtigungen fehlen: Telefonstatus & „Über anderen Apps anzeigen“"
        }
    }

    private fun importCsv(uri: Uri) {
        lifecycleScope.launch {
            val rows = withContext(Dispatchers.IO) { CsvImporter.parse(this@MainActivity, uri) }
            if (rows.isEmpty()) {
                Toast.makeText(this@MainActivity, "Keine gültigen Zeilen gefunden.", Toast.LENGTH_LONG).show()
                return@launch
            }
            val dao = AppDatabase.getInstance(applicationContext).customerDao()

            // Dubletten-Check: gleiche Nummer mehrfach in der Datei, oder Nummer existiert
            // schon mit einem anderen Namen.
            val conflicts = mutableListOf<String>()
            val seenInFile = mutableMapOf<String, String>()
            withContext(Dispatchers.IO) {
                rows.forEach { row ->
                    val normalized = PhoneUtils.normalize(row.telefon)
                    seenInFile[normalized]?.let { existingName ->
                        if (existingName != row.name) conflicts += "${row.telefon}: „$existingName“ vs. „${row.name}“ (in der Datei)"
                    }
                    seenInFile[normalized] = row.name
                    val existingId = dao.findIdByPhone(normalized)
                    if (existingId != null) {
                        val existing = dao.getByIdWithProperties(existingId)
                        if (existing != null && existing.customer.name != row.name) {
                            conflicts += "${row.telefon}: bereits gespeichert als „${existing.customer.name}“, neu: „${row.name}“"
                        }
                    }
                }
            }

            if (conflicts.isNotEmpty()) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Mögliche Dubletten gefunden")
                    .setMessage(conflicts.joinToString("\n\n") + "\n\nTrotzdem importieren? Bestehende Namen werden dabei überschrieben.")
                    .setPositiveButton("Trotzdem importieren") { _, _ -> doImportCsv(rows) }
                    .setNegativeButton("Abbrechen", null)
                    .show()
            } else {
                doImportCsv(rows)
            }
        }
    }

    private fun doImportCsv(rows: List<CsvImporter.Row>) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            withContext(Dispatchers.IO) {
                rows.forEach { row ->
                    val normalized = PhoneUtils.normalize(row.telefon)
                    val existingId = dao.findIdByPhone(normalized)
                    val customerId = dao.insertCustomer(
                        CustomerEntity(id = existingId ?: 0, name = row.name, phone = row.telefon, phoneNormalized = normalized, notes = row.notizen)
                    )
                    dao.deletePropertiesForCustomer(customerId)
                    dao.insertProperties(listOf(PropertyEntity(customerId = customerId, typ = row.typ, adresse = row.adresse, ort = row.ort, preis = row.preis)))
                }
            }
            Toast.makeText(this@MainActivity, "${rows.size} Kontakte importiert.", Toast.LENGTH_LONG).show()
            loadCustomers()
        }
    }

    private fun exportBackup(uri: Uri) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { BackupManager.export(this@MainActivity, uri, allCustomers) }
            getSharedPreferences("anruf_karte_prefs", MODE_PRIVATE).edit()
                .putLong("last_backup_at", System.currentTimeMillis()).apply()
            binding.tvBackupReminder.visibility = android.view.View.GONE
            Toast.makeText(this@MainActivity, "Backup gesichert.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importBackup(uri: Uri) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val count = withContext(Dispatchers.IO) { BackupManager.import(this@MainActivity, uri, dao) }
            Toast.makeText(this@MainActivity, "$count Kontakte wiederhergestellt.", Toast.LENGTH_LONG).show()
            loadCustomers()
        }
    }

    private fun loadCustomers() {
        lifecycleScope.launch {
            allCustomers = withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().getAllWithProperties() }
            applyFilters()
            updateSuggestion()
            updateUndoBanner()
            updateVertretungBanner()
            FollowUpWidgetProvider.updateAll(applicationContext)
        }
    }

    /** Schlägt beim Öffnen 1–2 Kontakte vor, die am dringendsten dran sind:
     *  wichtige Kontakte zuerst, dann fällige Wiedervorlagen, dann lange
     *  nicht kontaktierte (noch offene) Kontakte. */
    private fun updateSuggestion() {
        val now = System.currentTimeMillis()
        val thirtyDaysMs = 30L * 24 * 60 * 60 * 1000
        val candidates = allCustomers.filter { it.customer.status !in de.immokarte.anrufkarte.data.StatusInfo.closedStatuses }
        val scored = candidates.sortedWith(
            compareByDescending<CustomerWithProperties> { it.customer.important }
                .thenBy { it.customer.followUpAt ?: Long.MAX_VALUE }
                .thenBy { it.customer.lastContactAt ?: 0L }
        ).filter { c ->
            c.customer.important ||
                (c.customer.followUpAt != null && c.customer.followUpAt <= now) ||
                (c.customer.lastContactAt == null || now - c.customer.lastContactAt > thirtyDaysMs)
        }.take(2)

        if (scored.isNotEmpty()) {
            binding.tvSuggestion.visibility = android.view.View.VISIBLE
            binding.tvSuggestion.text = "📋 Heute anrufen: ${scored.joinToString(", ") { it.customer.name }}"
            binding.tvSuggestion.setOnClickListener {
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, scored.first().customer.id))
            }
        } else {
            binding.tvSuggestion.visibility = android.view.View.GONE
        }
    }

    private fun applyFilters() {
        val endOfToday = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
        var list = allCustomers

        val q = query.trim()
        val qLower = q.lowercase()
        if (qLower.isNotEmpty()) {
            list = list.filter { c ->
                c.customer.name.lowercase().contains(qLower) ||
                    c.customer.phone.replace(" ", "").contains(qLower.replace(" ", "")) ||
                    c.customer.tags.lowercase().contains(qLower) ||
                    c.customer.notes.lowercase().contains(qLower) ||
                    de.immokarte.anrufkarte.data.NoteLogUtils.parse(c.customer.noteLog).any { it.text.lowercase().contains(qLower) }
            }
        }

        list = when (filter) {
            "faellig" -> list.filter { it.customer.followUpAt != null && it.customer.followUpAt!! <= endOfToday }
            "unbetreut" -> list.filter { it.customer.status !in de.immokarte.anrufkarte.data.StatusInfo.closedStatuses }.sortedBy { it.customer.lastContactAt ?: 0L }
            "alle" -> list
            else -> list.filter { it.customer.status == filter }
        }

        adapter.submit(list, q)

        val due = allCustomers.count { it.customer.followUpAt != null && it.customer.followUpAt!! <= endOfToday }
        if (due > 0) {
            binding.tvDueBanner.visibility = android.view.View.VISIBLE
            binding.tvDueBanner.text = "🔔 $due Wiedervorlage${if (due == 1) "" else "n"} heute fällig"
        } else {
            binding.tvDueBanner.visibility = android.view.View.GONE
        }
    }
}
