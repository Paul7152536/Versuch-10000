package de.immokarte.anrufkarte.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Plant/entfernt die Erinnerung "1 Tag vorher an den Kunden wegen des
 *  Shootings melden" — anders als die Besichtigungs-Erinnerung geht es
 *  hier NICHT um den eigenen Termin selbst, sondern als Erinnerung, den
 *  Kunden nochmal selbst zu benachrichtigen. Feuert bewusst um 09:00 Uhr
 *  am Vortag (statt exakt 24h vorher), damit es nicht mitten in der Nacht
 *  ankommt, falls das Shooting früh morgens stattfindet. */
object ShootingReminderScheduler {

    fun schedule(context: Context, customerId: Long, name: String, phone: String, shootingAt: Long?) {
        cancel(context, customerId)
        if (shootingAt == null) return
        if (!de.immokarte.anrufkarte.data.ReminderPrefs.isEnabled(context, de.immokarte.anrufkarte.data.ReminderPrefs.Kind.SHOOTING)) return

        val fireAt = Calendar.getInstance().apply {
            timeInMillis = shootingAt
            add(Calendar.DAY_OF_YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        if (fireAt <= System.currentTimeMillis()) return // Termin ist schon zu nah/vorbei

        val dateLabel = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date(shootingAt))
        val timeLabel = SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(shootingAt))
        val intent = Intent(context, ShootingReminderReceiver::class.java).apply {
            putExtra(ShootingReminderReceiver.EXTRA_CUSTOMER_ID, customerId)
            putExtra(ShootingReminderReceiver.EXTRA_NAME, name)
            putExtra(ShootingReminderReceiver.EXTRA_PHONE, phone)
            putExtra(ShootingReminderReceiver.EXTRA_DATE_LABEL, dateLabel)
            putExtra(ShootingReminderReceiver.EXTRA_TIME_LABEL, timeLabel)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching { alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pendingIntent) }
    }

    fun cancel(context: Context, customerId: Long) {
        val intent = Intent(context, ShootingReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }

    private fun requestCode(customerId: Long): Int = (6_000_000 + customerId).toInt()
}
