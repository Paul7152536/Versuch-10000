package de.immokarte.anrufkarte.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Plant/entfernt die Erinnerung "45 Minuten vor der Besichtigung" für einen
 *  Kontakt. Nutzt setAndAllowWhileIdle (nicht "exact") — braucht dadurch
 *  keine gesonderte Berechtigung, kann in Ausnahmefällen ein paar Minuten
 *  abweichen, was für eine Vorab-Erinnerung unkritisch ist. */
object ViewingReminderScheduler {

    private const val LEAD_TIME_MS = 45 * 60 * 1000L

    fun schedule(context: Context, customerId: Long, name: String, phone: String, viewingAt: Long?, address: String? = null) {
        cancel(context, customerId)
        if (viewingAt == null) return
        val fireAt = viewingAt - LEAD_TIME_MS
        if (fireAt <= System.currentTimeMillis()) return // Termin ist schon zu nah/vorbei

        val timeLabel = SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(viewingAt))
        val intent = Intent(context, ViewingReminderReceiver::class.java).apply {
            putExtra(ViewingReminderReceiver.EXTRA_CUSTOMER_ID, customerId)
            putExtra(ViewingReminderReceiver.EXTRA_NAME, name)
            putExtra(ViewingReminderReceiver.EXTRA_PHONE, phone)
            putExtra(ViewingReminderReceiver.EXTRA_TIME_LABEL, timeLabel)
            putExtra(ViewingReminderReceiver.EXTRA_ADDRESS, address.orEmpty())
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching { alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pendingIntent) }
    }

    fun cancel(context: Context, customerId: Long) {
        val intent = Intent(context, ViewingReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(customerId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }

    private fun requestCode(customerId: Long): Int = (4_000_000 + customerId).toInt()
}
