package de.immokarte.anrufkarte.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val phoneNormalized: String,
    val phone2: String = "",
    val phone2Normalized: String = "",
    val email: String = "",
    val notes: String = "",              // Erstnotiz (z. B. aus CSV-Import)
    val noteLog: String = "",            // Verlauf: Zeilen im Format "epochMillis::Text"
    val status: String = "interessent",  // siehe StatusInfo.kt für die vollständige Liste
    val followUpAt: Long? = null,        // Fälligkeitsdatum der Wiedervorlage (Mitternacht)
    val important: Boolean = false,      // Für Nicht-stören-Ausnahme, siehe Hinweistext in der App
    val missedCalls: Int = 0,
    val lastContactAt: Long? = null,
    val tags: String = "",               // frei, Komma-getrennt, z. B. "ImmoScout, Empfehlung"
    val anniversaryAt: Long? = null,     // 12-Monats-Nachfrage nach Kauf/Miete
    val provision: String = "",          // Provision in vollen Euro, nur bei Abschluss relevant
    val referredById: Long? = null,      // Verweist auf die Kunden-ID, die diesen Kontakt empfohlen hat
    val reachability: String = "",       // z. B. "abends besser erreichbar"
    val abschlussAt: Long? = null,       // Zeitpunkt, an dem der Status auf "abschluss" gesetzt wurde
    val calendarEventId: Long? = null,   // ID des automatisch synchronisierten Wiedervorlage-Termins
    val searchOrt: String = "",          // Gesuchter Ort/Gegend, fürs Objekt-Matching
    val budgetMax: String = "",          // Budget bis (€), fürs Objekt-Matching
    val contractDateAt: Long? = null,    // Vertragstermin (z. B. Notartermin)
    val contractEventId: Long? = null,   // ID des dazu synchronisierten Kalender-Termins
    val preferredLanguage: String = "de", // de | en — für die WhatsApp-Vorlagen-Reihenfolge
    val viewingAt: Long? = null,         // Besichtigungstermin (Datum + Uhrzeit)
    val viewingEventId: Long? = null     // ID des dazu synchronisierten Kalender-Termins
)
