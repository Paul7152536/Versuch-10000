package de.immokarte.anrufkarte.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.R
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.reminder.MissedCallNotifier
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Hintergrunddienst, der bei einem eingehenden Anruf die Kunden-/Objektkarte
 * als System-Overlay über den Anrufbildschirm legt (SYSTEM_ALERT_WINDOW).
 * Aktualisiert außerdem "zuletzt kontaktiert" und verpasste Anrufe.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "de.immokarte.anrufkarte.SHOW"
        const val ACTION_HIDE = "de.immokarte.anrufkarte.HIDE"
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_ANSWERED = "extra_answered"
        const val EXTRA_DURATION_SEC = "extra_duration_sec"
        private const val CHANNEL_ID = "anrufkarte_service"
        private const val NOTIF_ID = 1001
    }

    private var overlayView: View? = null
    private lateinit var windowManager: WindowManager
    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.Main + job)

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        when (intent?.action) {
            ACTION_SHOW -> {
                val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
                scope.launch { showOverlay(phone) }
            }
            ACTION_HIDE -> {
                val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
                val answered = intent.getBooleanExtra(EXTRA_ANSWERED, false)
                val durationSec = intent.getIntExtra(EXTRA_DURATION_SEC, 0)
                removeOverlay()
                scope.launch { recordCallEnd(phone, answered, durationSec) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun showOverlay(rawPhone: String) {
        val normalized = PhoneUtils.normalize(rawPhone)
        val match: CustomerWithProperties? = withContext(Dispatchers.IO) {
            AppDatabase.getInstance(applicationContext).customerDao().findByPhone(normalized)
        }
        removeOverlay()

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_card, null)
        OverlayBinder.bind(view, rawPhone, match, scope)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                @Suppress("DEPRECATION") WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                @Suppress("DEPRECATION") WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP
        params.y = 220

        windowManager.addView(view, params)
        overlayView = view
    }

    private suspend fun recordCallEnd(rawPhone: String, answered: Boolean, durationSec: Int) {
        if (rawPhone.isBlank()) { stopSelf(); return }
        val normalized = PhoneUtils.normalize(rawPhone)
        withContext(Dispatchers.IO) {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            dao.updateLastContact(normalized, System.currentTimeMillis())
            if (!answered) {
                dao.incrementMissedCalls(normalized)
                val match = dao.findByPhone(normalized)
                if (match != null) {
                    MissedCallNotifier.show(applicationContext, match.customer.name, rawPhone)
                }
            } else if (durationSec >= 5) {
                // Nur ab 5 Sekunden protokollieren, um Wähl-Fehlversuche nicht mitzuloggen.
                val match = dao.findByPhone(normalized)
                if (match != null) {
                    val minutes = durationSec / 60
                    val seconds = durationSec % 60
                    val durationText = "%d:%02d".format(minutes, seconds)
                    val current = dao.getByIdWithProperties(match.customer.id)?.customer?.noteLog ?: match.customer.noteLog
                    val updated = de.immokarte.anrufkarte.data.NoteLogUtils.append(
                        current, de.immokarte.anrufkarte.data.NoteEntry(System.currentTimeMillis(), "📞 Anruf beantwortet — Dauer: $durationText")
                    )
                    dao.updateNoteLog(match.customer.id, updated)
                }
            }
        }
        FollowUpWidgetProvider.updateAll(applicationContext)
        stopSelf()
    }

    private fun removeOverlay() {
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
    }

    override fun onDestroy() {
        removeOverlay()
        job.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Anruf-Karte aktiv")
            .setContentText("Erkennt eingehende Anrufe im Hintergrund")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Anruf-Karte Hintergrunddienst", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
