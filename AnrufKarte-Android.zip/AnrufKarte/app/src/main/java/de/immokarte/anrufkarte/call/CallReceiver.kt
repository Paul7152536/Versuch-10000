package de.immokarte.anrufkarte.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/**
 * Lauscht auf Änderungen des Telefonstatus. Bei "RINGING" wird die
 * eingehende Nummer gelesen und der OverlayService gestartet. Bei "IDLE"
 * (Anruf beendet) wird die Karte wieder geschlossen — anhand von
 * "wurde OFFHOOK erreicht?" wird entschieden, ob es ein verpasster/
 * abgelehnter Anruf war, und bei einem angenommenen Anruf wird die
 * ungefähre Gesprächsdauer mitgegeben.
 *
 * Hinweis: Ab Android 9 (API 28) benötigt EXTRA_INCOMING_NUMBER
 * zusätzlich die Berechtigung READ_CALL_LOG (neben READ_PHONE_STATE).
 */
class CallReceiver : BroadcastReceiver() {

    companion object {
        private var ringingNumber: String? = null
        private var wasAnswered: Boolean = false
        private var offHookAt: Long = 0L
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                ringingNumber = number
                wasAnswered = false
                val serviceIntent = Intent(context, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_SHOW
                    putExtra(OverlayService.EXTRA_PHONE, number ?: "")
                }
                context.startForegroundService(serviceIntent)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (!wasAnswered) offHookAt = System.currentTimeMillis()
                wasAnswered = true
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val durationSec = if (wasAnswered && offHookAt > 0) ((System.currentTimeMillis() - offHookAt) / 1000).toInt() else 0
                val serviceIntent = Intent(context, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_HIDE
                    putExtra(OverlayService.EXTRA_PHONE, ringingNumber ?: "")
                    putExtra(OverlayService.EXTRA_ANSWERED, wasAnswered)
                    putExtra(OverlayService.EXTRA_DURATION_SEC, durationSec)
                }
                context.startService(serviceIntent)
                ringingNumber = null
                offHookAt = 0L
            }
        }
    }
}
