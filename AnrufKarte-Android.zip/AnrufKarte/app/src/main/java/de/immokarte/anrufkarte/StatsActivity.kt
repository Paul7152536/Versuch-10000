package de.immokarte.anrufkarte

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class StatsActivity : AppCompatActivity() {

    private var statRows: List<Pair<String, String>> = emptyList()

    private val exportCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        uri?.let { writeCsv(it) }
    }
    private val exportPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
        uri?.let { writePdf(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_stats)
        val container = findViewById<LinearLayout>(R.id.statsContainer)

        findViewById<android.widget.Button>(R.id.btnExportStatsCsv).setOnClickListener { exportCsv.launch("statistik.csv") }
        findViewById<android.widget.Button>(R.id.btnExportStatsPdf).setOnClickListener { exportPdf.launch("statistik.pdf") }

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val endOfToday = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
            }.timeInMillis
            val yearCal = Calendar.getInstance()
            val yearStart = Calendar.getInstance().apply {
                set(yearCal.get(Calendar.YEAR), Calendar.JANUARY, 1, 0, 0, 0)
            }.timeInMillis
            val yearEnd = Calendar.getInstance().apply {
                set(yearCal.get(Calendar.YEAR), Calendar.DECEMBER, 31, 23, 59, 59)
            }.timeInMillis
            val lastYearStart = Calendar.getInstance().apply {
                set(yearCal.get(Calendar.YEAR) - 1, Calendar.JANUARY, 1, 0, 0, 0)
            }.timeInMillis
            val lastYearEnd = Calendar.getInstance().apply {
                set(yearCal.get(Calendar.YEAR) - 1, Calendar.DECEMBER, 31, 23, 59, 59)
            }.timeInMillis
            val fmt = NumberFormat.getCurrencyInstance(Locale.GERMANY).apply { maximumFractionDigits = 0 }

            val (general, yearReview, topReferrers) = withContext(Dispatchers.IO) {
                val statusCounts = de.immokarte.anrufkarte.data.StatusInfo.options.map { it.label to dao.countByStatus(it.key).toString() }
                val general = listOf("Kunden gesamt" to dao.countAll().toString()) + statusCounts + listOf(
                    "Fällige Wiedervorlagen" to dao.countDueFollowUps(endOfToday).toString(),
                    "Verpasste Anrufe gesamt" to dao.sumMissedCalls().toString(),
                    "Provisionen gesamt" to fmt.format(dao.sumProvisions()),
                ) + (dao.avgPriceDifference()?.let {
                    listOf("Ø Preisdifferenz (Verkauf – Angebot)" to fmt.format(it.toLong()))
                } ?: emptyList())
                val thisYearCount = dao.countAbschlussInRange(yearStart, yearEnd)
                val lastYearCount = dao.countAbschlussInRange(lastYearStart, lastYearEnd)
                val diff = thisYearCount - lastYearCount
                val trend = when { diff > 0 -> " (↑ $diff mehr)"; diff < 0 -> " (↓ ${-diff} weniger)"; else -> " (gleich)" }
                val yearReview = listOf(
                    "Abschlüsse ${yearCal.get(Calendar.YEAR)}" to "$thisYearCount",
                    "Abschlüsse ${yearCal.get(Calendar.YEAR) - 1} (Vorjahr)" to "$lastYearCount$trend",
                    "Provisionen ${yearCal.get(Calendar.YEAR)}" to fmt.format(dao.sumProvisionsInRange(yearStart, yearEnd)),
                    "Provisionen ${yearCal.get(Calendar.YEAR) - 1} (Vorjahr)" to fmt.format(dao.sumProvisionsInRange(lastYearStart, lastYearEnd)),
                )
                val ids = dao.getAllReferredByIds()
                val topReferrers = if (ids.isEmpty()) emptyList() else {
                    val counts = ids.groupingBy { it }.eachCount()
                    val all = dao.getAllWithProperties().associateBy { it.customer.id }
                    counts.entries.sortedByDescending { it.value }.take(5).mapNotNull { (id, count) ->
                        all[id]?.let { it.customer.name to "$count Empfehlung${if (count == 1) "" else "en"}" }
                    }
                }
                Triple(general, yearReview, topReferrers)
            }

            statRows = general + yearReview + topReferrers

            general.forEach { (l, v) -> container.addView(statRow(l, v)) }

            container.addView(sectionHeader("📅 JAHRESRÜCKBLICK ${yearCal.get(Calendar.YEAR)}"))
            yearReview.forEach { (l, v) -> container.addView(statRow(l, v)) }

            if (topReferrers.isNotEmpty()) {
                container.addView(sectionHeader("TOP-EMPFEHLER"))
                topReferrers.forEach { (l, v) -> container.addView(statRow(l, v)) }
            }
        }
    }

    private fun sectionHeader(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(0xFF8B93A0.toInt())
        setPadding(4, 30, 4, 10)
    }

    private fun statRow(label: String, value: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 20, 16, 20)
            setBackgroundResource(R.drawable.bg_card)
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = 10
            layoutParams = params
        }
        val tvLabel = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(0xFF20242B.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvValue = TextView(this).apply {
            text = value; textSize = 16f; setTextColor(0xFFA9823D.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        row.addView(tvLabel)
        row.addView(tvValue)
        return row
    }

    private fun writeCsv(uri: Uri) {
        val csv = buildString {
            appendLine("Kennzahl,Wert")
            statRows.forEach { (l, v) -> appendLine("\"$l\",\"$v\"") }
        }
        contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray()) }
        Toast.makeText(this, "Statistik als CSV gespeichert.", Toast.LENGTH_SHORT).show()
    }

    private fun writePdf(uri: Uri) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
        val labelPaint = Paint().apply { textSize = 13f }
        val valuePaint = Paint().apply { textSize = 13f; color = 0xFFA9823D.toInt() }

        var y = 50f
        canvas.drawText("Anruf-Karte — Statistik", 40f, y, titlePaint); y += 34f
        statRows.forEach { (l, v) ->
            canvas.drawText(l, 40f, y, labelPaint)
            canvas.drawText(v, 400f, y, valuePaint)
            y += 22f
        }
        document.finishPage(page)
        contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
        document.close()
        Toast.makeText(this, "Statistik als PDF gespeichert.", Toast.LENGTH_SHORT).show()
    }
}
