package de.immokarte.anrufkarte.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.TimeZone

data class CalendarChoice(val id: Long, val displayName: String, val accountName: String)

/**
 * Legt für Wiedervorlagen, Vertragstermine und Besichtigungen automatisch
 * einen Kalender-Termin an, aktualisiert ihn bei Änderungen oder löscht ihn,
 * wenn das Datum entfernt wird. Nutzt bei mehreren Konten/Kalendern auf dem
 * Gerät bevorzugt den in den Einstellungen gewählten Kalender — sonst den
 * ersten beschreibbaren (bevorzugt "primär" markierten).
 *
 * Wichtig für Mehrkonten-Geräte: CalendarContract.Calendars.IS_PRIMARY gibt
 * es erst ab Android 11 (API 30) — die App unterstützt aber Geräte ab
 * Android 8. Der Spaltenzugriff läuft deshalb über getColumnIndex() (gibt
 * -1 zurück, wenn die Spalte fehlt) statt über eine feste Positions-Nummer,
 * damit ältere Geräte nicht abstürzen, sondern einfach ohne "primär"-Erkennung
 * auf den ersten beschreibbaren Kalender zurückfallen.
 */
object CalendarSync {

    private const val PREFS = "anruf_karte_prefs"
    private const val KEY_CALENDAR_ID = "selected_calendar_id"
    private const val KEY_EVENT_COLOR = "calendar_event_color"

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    /** Listet alle beschreibbaren Kalender des Geräts (über alle Konten hinweg)
     *  für die Auswahl in den Einstellungen. */
    fun listCalendars(context: Context): List<CalendarChoice> {
        if (!hasPermission(context)) return emptyList()
        val result = mutableListOf<CalendarChoice>()
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
        )
        runCatching {
            context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
                val idxId = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                val idxName = cursor.getColumnIndex(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
                val idxAccount = cursor.getColumnIndex(CalendarContract.Calendars.ACCOUNT_NAME)
                val idxAccountType = cursor.getColumnIndex(CalendarContract.Calendars.ACCOUNT_TYPE)
                val idxLevel = cursor.getColumnIndex(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
                while (cursor.moveToNext()) {
                    val level = if (idxLevel >= 0) cursor.getInt(idxLevel) else CalendarContract.Calendars.CAL_ACCESS_OWNER
                    // "Lokale" Gerätekalender (ACCOUNT_TYPE_LOCAL) werden bei Google-Konten-Sync
                    // nicht mit hochgeladen — für Termine, die man auch auf anderen Geräten sehen
                    // möchte, sind Konten-gebundene Kalender meist die sinnvollere Wahl. Wir listen
                    // trotzdem alle beschreibbaren, damit die Auswahl vollständig bleibt.
                    if (level >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                        val accountName = if (idxAccount >= 0) cursor.getString(idxAccount) else null
                        val accountType = if (idxAccountType >= 0) cursor.getString(idxAccountType) else null
                        val accountLabel = when {
                            accountType == CalendarContract.ACCOUNT_TYPE_LOCAL -> "Nur auf diesem Gerät"
                            !accountName.isNullOrBlank() -> accountName
                            else -> "Unbekanntes Konto"
                        }
                        result += CalendarChoice(
                            id = if (idxId >= 0) cursor.getLong(idxId) else continue,
                            displayName = if (idxName >= 0) (cursor.getString(idxName) ?: "Kalender") else "Kalender",
                            accountName = accountLabel
                        )
                    }
                }
            }
        }
        return result
    }

    /** true, wenn mindestens ein beschreibbarer Kalender existiert (Berechtigung vorausgesetzt).
     *  Ist das nicht der Fall (z. B. kein Konto auf dem Gerät eingerichtet), kann keine
     *  automatische Synchronisation stattfinden, ganz unabhängig von der Berechtigung. */
    fun hasAnyCalendar(context: Context): Boolean = listCalendars(context).isNotEmpty()

    private fun findDefaultCalendarId(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.IS_PRIMARY // ab API 30 — Zugriff unten über getColumnIndex abgesichert
        )
        return runCatching {
            context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { cursor ->
                val idxId = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                val idxLevel = cursor.getColumnIndex(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
                val idxPrimary = cursor.getColumnIndex(CalendarContract.Calendars.IS_PRIMARY) // -1 vor API 30

                var fallback: Long? = null
                while (cursor.moveToNext()) {
                    val level = if (idxLevel >= 0) cursor.getInt(idxLevel) else CalendarContract.Calendars.CAL_ACCESS_OWNER
                    if (level >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                        val id = if (idxId >= 0) cursor.getLong(idxId) else continue
                        val isPrimary = idxPrimary >= 0 && cursor.getInt(idxPrimary) == 1
                        if (isPrimary) return@use id
                        if (fallback == null) fallback = id
                    }
                }
                fallback
            }
        }.getOrNull()
    }

    /** Bevorzugt den in den Einstellungen ausgewählten Kalender, sonst automatische Erkennung. */
    private fun resolveCalendarId(context: Context): Long? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val selected = prefs.getLong(KEY_CALENDAR_ID, -1L)
        if (selected > 0) {
            // Prüfen, ob der gewählte Kalender noch existiert (Konto könnte entfernt worden sein) —
            // sonst fällt die Synchronisation sonst dauerhaft und unbemerkt aus.
            val stillExists = listCalendars(context).any { it.id == selected }
            if (stillExists) return selected
        }
        return findDefaultCalendarId(context)
    }

    private fun preferredEventColor(context: Context): Int? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val hex = prefs.getString(KEY_EVENT_COLOR, "") ?: ""
        if (hex.isBlank()) return null
        return runCatching { Color.parseColor(hex) }.getOrNull()
    }

    private fun eventExists(context: Context, eventId: Long): Boolean {
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        return runCatching {
            context.contentResolver.query(uri, arrayOf(CalendarContract.Events._ID), null, null, null)?.use { it.moveToFirst() }
        }.getOrNull() ?: false
    }

    /** Erstellt/aktualisiert/löscht einen Termin. startAt/endAt in Millisekunden;
     *  wenn startAt null ist, wird ein vorhandener Termin gelöscht. */
    fun syncEvent(context: Context, existingEventId: Long?, title: String, description: String, startAt: Long?, endAt: Long?): Long? {
        if (!hasPermission(context)) return existingEventId

        if (startAt == null) {
            existingEventId?.let { deleteEvent(context, it) }
            return null
        }

        val calendarId = resolveCalendarId(context) ?: return existingEventId
        val end = endAt ?: (startAt + 30 * 60 * 1000L)

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startAt)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            preferredEventColor(context)?.let { put(CalendarContract.Events.EVENT_COLOR, it) }
        }

        // Falls der zuvor genutzte Kalender (z. B. nach Kontowechsel) nicht mehr derselbe ist wie
        // der aktuell aufgelöste, aktualisieren wir trotzdem am bestehenden Termin — Events lassen
        // sich in CALENDAR_ID nicht "verschieben"; existiert der alte Termin nicht mehr, wird
        // unten ohnehin ein neuer im aktuell aufgelösten Kalender angelegt (Selbstheilung).
        return if (existingEventId != null && eventExists(context, existingEventId)) {
            runCatching {
                context.contentResolver.update(
                    ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingEventId), values, null, null
                )
            }
            existingEventId
        } else {
            runCatching {
                context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)?.lastPathSegment?.toLongOrNull()
            }.getOrNull()
        }
    }

    fun deleteEvent(context: Context, eventId: Long) {
        if (!hasPermission(context)) return
        runCatching {
            context.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null)
        }
    }
}
