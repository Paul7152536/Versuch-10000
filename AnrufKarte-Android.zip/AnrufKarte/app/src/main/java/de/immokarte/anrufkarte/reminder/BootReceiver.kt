package de.immokarte.anrufkarte.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import de.immokarte.anrufkarte.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Plant den täglichen Erinnerungs-Alarm sowie alle anstehenden
 *  Besichtigungs-Erinnerungen nach einem Geräteneustart neu (Alarme
 *  überleben einen Neustart sonst nicht) und startet — falls eingerichtet —
 *  auch den SIM-Erkennungsdienst wieder. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        AlarmScheduler.scheduleDaily(context)

        val prefs = context.getSharedPreferences("anruf_karte_prefs", Context.MODE_PRIVATE)
        if (prefs.getInt("overlay_sim_subscription_id", -1) >= 0) {
            val serviceIntent = Intent(context, de.immokarte.anrufkarte.call.SimCallStateService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }

        // Besichtigungs-Erinnerungen brauchen einen kurzen Datenbankzugriff —
        // goAsync() hält den Empfänger dafür am Leben, bis finish() aufgerufen wird.
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val dao = AppDatabase.getInstance(context.applicationContext).customerDao()
                val upcoming = dao.getUpcomingViewings(System.currentTimeMillis())
                upcoming.forEach { customer ->
                    val address = dao.getByIdWithProperties(customer.id)?.properties?.firstOrNull()
                        ?.let { listOf(it.adresse, it.ort).filter { part -> part.isNotBlank() }.joinToString(", ") }
                        ?.takeIf { it.isNotBlank() }
                    ViewingReminderScheduler.schedule(context.applicationContext, customer.id, customer.name, customer.phone, customer.viewingAt, address)
                }
            }
            pendingResult.finish()
        }
    }
}
