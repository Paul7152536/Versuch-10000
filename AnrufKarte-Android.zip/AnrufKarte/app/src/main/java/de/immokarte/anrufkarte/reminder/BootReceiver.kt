package de.immokarte.anrufkarte.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Plant den täglichen Erinnerungs-Alarm nach einem Geräteneustart neu
 *  (Alarme überleben einen Neustart sonst nicht). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            AlarmScheduler.scheduleDaily(context)
        }
    }
}
