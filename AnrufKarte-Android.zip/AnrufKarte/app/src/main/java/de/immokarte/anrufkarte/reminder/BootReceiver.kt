package de.immokarte.anrufkarte.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Plant den täglichen Erinnerungs-Alarm nach einem Geräteneustart neu
 *  (Alarme überleben einen Neustart sonst nicht) und startet — falls
 *  eingerichtet — auch den SIM-Erkennungsdienst wieder. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            AlarmScheduler.scheduleDaily(context)

            val prefs = context.getSharedPreferences("anruf_karte_prefs", Context.MODE_PRIVATE)
            if (prefs.getInt("overlay_sim_subscription_id", -1) >= 0) {
                val serviceIntent = Intent(context, de.immokarte.anrufkarte.call.SimCallStateService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
