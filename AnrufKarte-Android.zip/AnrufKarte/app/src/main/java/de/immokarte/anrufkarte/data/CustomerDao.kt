package de.immokarte.anrufkarte.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface CustomerDao {

    @Transaction
    @Query("""
        SELECT * FROM customers ORDER BY important DESC,
        CASE status
            WHEN 'interessent' THEN 0
            WHEN 'besichtigung' THEN 1
            WHEN 'angebot' THEN 2
            WHEN 'pendent' THEN 3
            WHEN 'kunde' THEN 4
            WHEN 'abgelehnt' THEN 5
            WHEN 'abschluss' THEN 6
            ELSE 7
        END,
        name COLLATE NOCASE
    """)
    suspend fun getAllWithProperties(): List<CustomerWithProperties>

    @Transaction
    @Query("SELECT * FROM customers WHERE phoneNormalized = :phoneNormalized OR phone2Normalized = :phoneNormalized LIMIT 1")
    suspend fun findByPhone(phoneNormalized: String): CustomerWithProperties?

    @Transaction
    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getByIdWithProperties(id: Long): CustomerWithProperties?

    @Query("SELECT id FROM customers WHERE phoneNormalized = :phoneNormalized OR phone2Normalized = :phoneNormalized LIMIT 1")
    suspend fun findIdByPhone(phoneNormalized: String): Long?

    @Query("SELECT * FROM customers WHERE followUpAt IS NOT NULL AND followUpAt <= :endOfToday ORDER BY followUpAt ASC")
    suspend fun getDueFollowUps(endOfToday: Long): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE anniversaryAt IS NOT NULL AND anniversaryAt <= :endOfToday ORDER BY anniversaryAt ASC")
    suspend fun getDueAnniversaries(endOfToday: Long): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE contractDateAt IS NOT NULL AND contractDateAt <= :endOfToday ORDER BY contractDateAt ASC")
    suspend fun getDueContracts(endOfToday: Long): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id != :excludeId AND searchOrt != '' ORDER BY name COLLATE NOCASE")
    suspend fun getCustomersWithSearchCriteria(excludeId: Long): List<CustomerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperties(properties: List<PropertyEntity>)

    @Query("DELETE FROM properties WHERE customerId = :customerId")
    suspend fun deletePropertiesForCustomer(customerId: Long)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteCustomerById(id: Long)

    @Query("UPDATE customers SET important = :important WHERE id = :id")
    suspend fun setImportant(id: Long, important: Boolean)

    @Query("UPDATE customers SET noteLog = :noteLog WHERE id = :id")
    suspend fun updateNoteLog(id: Long, noteLog: String)

    @Query("UPDATE customers SET missedCalls = missedCalls + 1 WHERE phoneNormalized = :phoneNormalized")
    suspend fun incrementMissedCalls(phoneNormalized: String)

    @Query("UPDATE customers SET missedCalls = 0 WHERE id = :id")
    suspend fun resetMissedCalls(id: Long)

    @Query("UPDATE customers SET missedCalls = :count WHERE id = :id")
    suspend fun setMissedCalls(id: Long, count: Int)

    @Query("UPDATE customers SET followUpAt = :followUpAt WHERE id = :id")
    suspend fun setFollowUp(id: Long, followUpAt: Long)

    @Query("UPDATE customers SET calendarEventId = :eventId WHERE id = :id")
    suspend fun setCalendarEventId(id: Long, eventId: Long?)

    @Query("UPDATE customers SET lastContactAt = :timestamp WHERE phoneNormalized = :phoneNormalized")
    suspend fun updateLastContact(phoneNormalized: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM customers WHERE status = :status")
    suspend fun countByStatus(status: String): Int

    @Query("SELECT COUNT(*) FROM customers")
    suspend fun countAll(): Int

    @Query("SELECT COALESCE(SUM(missedCalls), 0) FROM customers")
    suspend fun sumMissedCalls(): Int

    @Query("SELECT COUNT(*) FROM customers WHERE followUpAt IS NOT NULL AND followUpAt <= :endOfToday")
    suspend fun countDueFollowUps(endOfToday: Long): Int

    @Query("SELECT COALESCE(SUM(CAST(provision AS INTEGER)), 0) FROM customers WHERE provision != ''")
    suspend fun sumProvisions(): Long

    @Query("SELECT AVG(CAST(verkaufspreis AS INTEGER) - CAST(preis AS INTEGER)) FROM properties WHERE verkaufspreis != '' AND preis != ''")
    suspend fun avgPriceDifference(): Double?

    @Query("SELECT id, name FROM customers WHERE id != :excludeId ORDER BY name COLLATE NOCASE")
    suspend fun getNamesForPicker(excludeId: Long): List<CustomerNameOnly>

    @Query("SELECT referredById FROM customers WHERE referredById IS NOT NULL")
    suspend fun getAllReferredByIds(): List<Long>

    @Query("SELECT COUNT(*) FROM customers WHERE abschlussAt IS NOT NULL AND abschlussAt BETWEEN :yearStart AND :yearEnd")
    suspend fun countAbschlussInRange(yearStart: Long, yearEnd: Long): Int

    @Query("SELECT COALESCE(SUM(CAST(provision AS INTEGER)), 0) FROM customers WHERE provision != '' AND abschlussAt BETWEEN :yearStart AND :yearEnd")
    suspend fun sumProvisionsInRange(yearStart: Long, yearEnd: Long): Long

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)
}
