package de.immokarte.anrufkarte.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.NoteLogUtils
import de.immokarte.anrufkarte.data.StatusInfo
import de.immokarte.anrufkarte.databinding.ItemCustomerBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val dateFmt = SimpleDateFormat("dd.MM.", Locale.GERMANY)

class CustomerAdapter(
    private val onClick: (Long) -> Unit,
    private val onToggleStar: (Long, Boolean) -> Unit,
    private val onCall: (String) -> Unit,
    private val onDismissMissed: (Long) -> Unit
) : RecyclerView.Adapter<CustomerAdapter.VH>() {

    private var items: List<CustomerWithProperties> = emptyList()
    private var noteQuery: String = ""

    /** query wird zusätzlich zur reinen Filterung auch für die Notiz-Treffer-Vorschau
     *  in der Liste verwendet (zeigt an, welche Notiz zum Suchbegriff passt). */
    fun submit(list: List<CustomerWithProperties>, query: String = "") {
        items = list
        noteQuery = query.trim()
        notifyDataSetChanged()
    }

    fun itemAt(position: Int): CustomerWithProperties? = items.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCustomerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val c = item.customer
        val b = holder.binding

        b.tvName.text = c.name
        b.tvPhone.text = c.phone + if (c.phone2.isNotBlank()) " (+1)" else ""
        b.tvStatus.text = StatusInfo.label(c.status)
        b.root.setOnClickListener { onClick(c.id) }
        b.tvPhone.setOnClickListener {
            de.immokarte.anrufkarte.data.PhoneUtils.withChosenNumber(b.root.context, c.phone, c.phone2) { chosen -> onCall(chosen) }
        }

        b.btnStar.setImageResource(
            if (c.important) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        )
        b.btnStar.setOnClickListener { onToggleStar(c.id, !c.important) }

        if (c.missedCalls > 0) {
            b.tvMissedBadge.text = "${c.missedCalls} verpasst"
            b.tvMissedBadge.visibility = View.VISIBLE
        } else {
            b.tvMissedBadge.visibility = View.GONE
        }

        val today = startOfDay(System.currentTimeMillis())
        if (c.followUpAt != null) {
            val isDue = c.followUpAt <= today + 86_400_000L - 1
            b.tvFollowUp.visibility = View.VISIBLE
            b.tvFollowUp.text = if (isDue) "Wiedervorlage fällig" else "Wiedervorlage ${dateFmt.format(Date(c.followUpAt))}"
        } else {
            b.tvFollowUp.visibility = View.GONE
        }

        if (c.lastContactAt != null) {
            val days = ((System.currentTimeMillis() - c.lastContactAt) / 86_400_000L).toInt()
            b.tvLastContact.text = "zuletzt kontaktiert vor $days Tag${if (days == 1) "" else "en"}"
            b.tvLastContact.visibility = View.VISIBLE
        } else {
            b.tvLastContact.visibility = View.GONE
        }

        // Notiz-Treffer-Vorschau: zeigt, welche Notiz zum Suchbegriff passt,
        // falls der Treffer nicht schon über Name/Telefon/Tags erklärt ist.
        if (noteQuery.isNotBlank()) {
            val allNotes = NoteLogUtils.parse(c.noteLog).map { it.text } + listOfNotNull(c.notes.takeIf { it.isNotBlank() })
            val match = allNotes.firstOrNull { it.contains(noteQuery, ignoreCase = true) }
            if (match != null) {
                b.tvNoteMatch.visibility = View.VISIBLE
                b.tvNoteMatch.text = "🔍 in Notiz: „${excerpt(match, noteQuery)}“"
            } else {
                b.tvNoteMatch.visibility = View.GONE
            }
        } else {
            b.tvNoteMatch.visibility = View.GONE
        }
    }

    /** Kürzt lange Notizen auf einen Ausschnitt rund um den Treffer. */
    private fun excerpt(text: String, query: String, radius: Int = 40): String {
        if (text.length <= radius * 2) return text
        val idx = text.indexOf(query, ignoreCase = true).coerceAtLeast(0)
        val start = (idx - radius).coerceAtLeast(0)
        val end = (idx + query.length + radius).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") + text.substring(start, end) + (if (end < text.length) "…" else "")
    }

    private fun startOfDay(millis: Long): Long =
        Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    override fun getItemCount() = items.size

    class VH(val binding: ItemCustomerBinding) : RecyclerView.ViewHolder(binding.root)
}
