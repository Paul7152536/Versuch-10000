package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Sichert/liest alle Kontakte inkl. Objekte als lesbare JSON-Datei —
 *  dient als lokales Backup (kein Cloud-Abgleich).
 *
 *  WICHTIG: Jedes neue Feld auf CustomerEntity/PropertyEntity muss hier in
 *  BEIDEN Richtungen (export UND import) ergänzt werden — sonst geht es
 *  bei einem Sichern/Wiederherstellen-Zyklus unbemerkt verloren. */
object BackupManager {

    private fun optLongOrNull(o: JSONObject, key: String): Long? =
        if (o.isNull(key) || !o.has(key)) null else o.optLong(key)

    fun export(context: Context, uri: Uri, customers: List<CustomerWithProperties>) {
        val arr = JSONArray()
        customers.forEach { cwp ->
            val c = cwp.customer
            val o = JSONObject()
            o.put("name", c.name)
            o.put("phone", c.phone)
            o.put("phone2", c.phone2)
            o.put("email", c.email)
            o.put("notes", c.notes)
            o.put("noteLog", c.noteLog)
            o.put("status", c.status)
            o.put("followUpAt", c.followUpAt ?: JSONObject.NULL)
            o.put("important", c.important)
            o.put("missedCalls", c.missedCalls)
            o.put("lastContactAt", c.lastContactAt ?: JSONObject.NULL)
            o.put("tags", c.tags)
            o.put("anniversaryAt", c.anniversaryAt ?: JSONObject.NULL)
            o.put("provision", c.provision)
            o.put("referredByName", customers.firstOrNull { it.customer.id == c.referredById }?.customer?.name ?: JSONObject.NULL)
            o.put("reachability", c.reachability)
            o.put("abschlussAt", c.abschlussAt ?: JSONObject.NULL)
            o.put("searchOrt", c.searchOrt)
            o.put("budgetMax", c.budgetMax)
            o.put("contractDateAt", c.contractDateAt ?: JSONObject.NULL)
            o.put("preferredLanguage", c.preferredLanguage)
            o.put("viewingAt", c.viewingAt ?: JSONObject.NULL)
            o.put("shootingAt", c.shootingAt ?: JSONObject.NULL)
            val props = JSONArray()
            cwp.properties.forEach { p ->
                val po = JSONObject()
                po.put("typ", p.typ); po.put("adresse", p.adresse); po.put("ort", p.ort); po.put("preis", p.preis)
                po.put("status", p.status); po.put("verkaufspreis", p.verkaufspreis); po.put("exposeUri", p.exposeUri)
                props.put(po)
            }
            o.put("properties", props)
            arr.put(o)
        }
        context.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
    }

    suspend fun import(context: Context, uri: Uri, dao: CustomerDao): Int {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return 0
        val arr = JSONArray(text)

        // Empfehler werden über den Namen aufgelöst (IDs können sich zwischen
        // Installationen unterscheiden) — deshalb zuerst alle Kontakte anlegen,
        // dann in einem zweiten Durchlauf die Empfehler-Verknüpfung setzen.
        val referrerNameByNewId = mutableMapOf<Long, String>()

        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val normalized = PhoneUtils.normalize(o.optString("phone"))
            val phone2 = o.optString("phone2", "")
            val normalized2 = if (phone2.isNotBlank()) PhoneUtils.normalize(phone2) else ""
            val existingId = dao.findIdByPhone(normalized)
            val id = dao.insertCustomer(
                CustomerEntity(
                    id = existingId ?: 0,
                    name = o.optString("name"),
                    phone = o.optString("phone"),
                    phoneNormalized = normalized,
                    phone2 = phone2,
                    phone2Normalized = normalized2,
                    email = o.optString("email", ""),
                    notes = o.optString("notes", ""),
                    noteLog = o.optString("noteLog", ""),
                    status = o.optString("status", "interessent"),
                    followUpAt = optLongOrNull(o, "followUpAt"),
                    important = o.optBoolean("important", false),
                    missedCalls = o.optInt("missedCalls", 0),
                    lastContactAt = optLongOrNull(o, "lastContactAt"),
                    tags = o.optString("tags", ""),
                    anniversaryAt = optLongOrNull(o, "anniversaryAt"),
                    provision = o.optString("provision", ""),
                    reachability = o.optString("reachability", ""),
                    abschlussAt = optLongOrNull(o, "abschlussAt"),
                    searchOrt = o.optString("searchOrt", ""),
                    budgetMax = o.optString("budgetMax", ""),
                    contractDateAt = optLongOrNull(o, "contractDateAt"),
                    preferredLanguage = o.optString("preferredLanguage", "de"),
                    viewingAt = optLongOrNull(o, "viewingAt"),
                    shootingAt = optLongOrNull(o, "shootingAt")
                )
            )
            if (!o.isNull("referredByName") && o.has("referredByName")) {
                referrerNameByNewId[id] = o.optString("referredByName")
            }

            dao.deletePropertiesForCustomer(id)
            val props = o.optJSONArray("properties") ?: JSONArray()
            val propertyList = mutableListOf<PropertyEntity>()
            for (j in 0 until props.length()) {
                val po = props.getJSONObject(j)
                propertyList += PropertyEntity(
                    customerId = id, typ = po.optString("typ", "Wohnung"),
                    adresse = po.optString("adresse", ""), ort = po.optString("ort", ""),
                    preis = po.optString("preis", ""),
                    status = po.optString("status", "interessiert"),
                    verkaufspreis = po.optString("verkaufspreis", ""),
                    exposeUri = po.optString("exposeUri", "")
                )
            }
            if (propertyList.isNotEmpty()) dao.insertProperties(propertyList)
        }

        // Zweiter Durchlauf: Empfehler-Namen zu den (jetzt bekannten) IDs auflösen.
        if (referrerNameByNewId.isNotEmpty()) {
            val allByName = dao.getAllWithProperties().associateBy { it.customer.name }
            referrerNameByNewId.forEach { (customerId, referrerName) ->
                val referrer = allByName[referrerName]
                if (referrer != null) dao.setReferredBy(customerId, referrer.customer.id)
            }
        }

        return arr.length()
    }
}
