package de.immokarte.anrufkarte.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Sichert/liest alle Kontakte inkl. Objekte als lesbare JSON-Datei —
 *  dient als lokales Backup (kein Cloud-Abgleich). */
object BackupManager {

    fun export(context: Context, uri: Uri, customers: List<CustomerWithProperties>) {
        val arr = JSONArray()
        customers.forEach { cwp ->
            val o = JSONObject()
            o.put("name", cwp.customer.name)
            o.put("phone", cwp.customer.phone)
            o.put("phone2", cwp.customer.phone2)
            o.put("email", cwp.customer.email)
            o.put("notes", cwp.customer.notes)
            o.put("noteLog", cwp.customer.noteLog)
            o.put("status", cwp.customer.status)
            o.put("followUpAt", cwp.customer.followUpAt ?: JSONObject.NULL)
            o.put("important", cwp.customer.important)
            o.put("missedCalls", cwp.customer.missedCalls)
            o.put("lastContactAt", cwp.customer.lastContactAt ?: JSONObject.NULL)
            val props = JSONArray()
            cwp.properties.forEach { p ->
                val po = JSONObject()
                po.put("typ", p.typ); po.put("adresse", p.adresse); po.put("ort", p.ort); po.put("preis", p.preis)
                props.put(po)
            }
            o.put("properties", props)
            arr.put(o)
        }
        context.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
    }

    suspend fun import(context: Context, uri: Uri, dao: CustomerDao): Int {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return 0
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val normalized = PhoneUtils.normalize(o.optString("phone"))
            val phone2 = o.optString("phone2", "")
            val normalized2 = if (phone2.isNotBlank()) PhoneUtils.normalize(phone2) else ""
            val existingId = dao.findIdByPhone(normalized)
            val id = dao.insertCustomer(
                CustomerEntity(
                    id = existingId ?: 0,
                    name = o.optString("name"),
                    phone = o.optString("phone"),
                    phoneNormalized = normalized,
                    phone2 = phone2,
                    phone2Normalized = normalized2,
                    email = o.optString("email", ""),
                    notes = o.optString("notes", ""),
                    noteLog = o.optString("noteLog", ""),
                    status = o.optString("status", "interessent"),
                    followUpAt = if (o.isNull("followUpAt")) null else o.optLong("followUpAt"),
                    important = o.optBoolean("important", false),
                    missedCalls = o.optInt("missedCalls", 0),
                    lastContactAt = if (o.isNull("lastContactAt")) null else o.optLong("lastContactAt")
                )
            )
            dao.deletePropertiesForCustomer(id)
            val props = o.optJSONArray("properties") ?: JSONArray()
            val propertyList = mutableListOf<PropertyEntity>()
            for (j in 0 until props.length()) {
                val po = props.getJSONObject(j)
                propertyList += PropertyEntity(
                    customerId = id, typ = po.optString("typ", "Wohnung"),
                    adresse = po.optString("adresse", ""), ort = po.optString("ort", ""),
                    preis = po.optString("preis", "")
                )
            }
            if (propertyList.isNotEmpty()) dao.insertProperties(propertyList)
        }
        return arr.length()
    }
}
