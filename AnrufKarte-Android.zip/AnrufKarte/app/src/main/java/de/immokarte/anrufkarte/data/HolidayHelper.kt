package de.immokarte.anrufkarte.data

import java.util.Calendar
import java.util.GregorianCalendar

/** Prüft, ob ein Datum auf einen deutschlandweiten Feiertag oder einen
 *  Sonntag fällt — nützlich, um vor Wiedervorlagen/Besichtigungen an
 *  Terminen zu warnen, die ohnehin ausfallen dürften.
 *
 *  Bewusst nur die neun BUNDESWEIT einheitlichen Feiertage (nicht die
 *  je nach Bundesland unterschiedlichen, z. B. Fronleichnam, Allerheiligen,
 *  Heilige Drei Könige) — die App kennt dein Bundesland nicht. */
object HolidayHelper {

    /** Gibt einen Warnhinweis zurück, falls das Datum ein Sonntag oder
     *  bundesweiter Feiertag ist — sonst null. */
    fun checkDate(millis: Long): String? {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) return "Sonntag"

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)

        val easter = calculateEasterSunday(year)
        val holidays = mapOf(
            (1 to 1) to "Neujahr",
            (5 to 1) to "Tag der Arbeit",
            (10 to 3) to "Tag der Deutschen Einheit",
            (12 to 25) to "1. Weihnachtsfeiertag",
            (12 to 26) to "2. Weihnachtsfeiertag",
            dateOf(easter, -2) to "Karfreitag",
            dateOf(easter, 1) to "Ostermontag",
            dateOf(easter, 39) to "Christi Himmelfahrt",
            dateOf(easter, 50) to "Pfingstmontag",
        )
        return holidays[month to day]
    }

    private fun dateOf(easter: Calendar, offsetDays: Int): Pair<Int, Int> {
        val c = easter.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, offsetDays)
        return (c.get(Calendar.MONTH) + 1) to c.get(Calendar.DAY_OF_MONTH)
    }

    /** Gauß'sche Osterformel. */
    private fun calculateEasterSunday(year: Int): Calendar {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = (h + l - 7 * m + 114) % 31 + 1
        return GregorianCalendar(year, month - 1, day)
    }
}
