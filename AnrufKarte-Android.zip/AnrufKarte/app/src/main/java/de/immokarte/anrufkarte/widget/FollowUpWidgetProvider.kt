package de.immokarte.anrufkarte.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.view.View
import android.widget.RemoteViews
import de.immokarte.anrufkarte.R
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Zeigt ALLE heutigen Termine direkt auf dem Homescreen, ohne die App zu
 *  öffnen — Wiedervorlagen, Besichtigungen, Vertragstermine und Jahrestage
 *  zusammen, vollständig aufgelistet (nicht auf eine feste Anzahl begrenzt)
 *  und mit Uhrzeit. Aktualisiert sich stündlich automatisch und zusätzlich
 *  sofort nach jeder Änderung in der App. */
class FollowUpWidgetProvider : AppWidgetProvider() {

    private data class WidgetEntry(val time: Long, val label: String, val hasRealTime: Boolean)

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, FollowUpWidgetProvider::class.java))
            ids.forEach { id -> updateWidget(context, manager, id) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            CoroutineScope(Dispatchers.IO).launch {
                val startOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val endOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
                }.timeInMillis

                val dao = AppDatabase.getInstance(context.applicationContext).customerDao()
                val allCustomers = dao.getAllWithProperties()

                // Alle vier Terminarten zusammenführen — Besichtigungen haben eine
                // echte Uhrzeit, die anderen sind reine Tagestermine (Standard 09:00,
                // passend zum Kalender-Sync).
                val entries = mutableListOf<WidgetEntry>()
                allCustomers.forEach { c ->
                    val customer: CustomerEntity = c.customer
                    customer.followUpAt?.let { if (it in startOfToday..endOfToday) entries += WidgetEntry(it + 9 * 60 * 60 * 1000L, "🔔 ${customer.name} — Wiedervorlage", false) }
                    customer.viewingAt?.let { if (it in startOfToday..endOfToday) entries += WidgetEntry(it, "🏠 ${customer.name} — Besichtigung", true) }
                    customer.contractDateAt?.let { if (it in startOfToday..endOfToday) entries += WidgetEntry(it + 9 * 60 * 60 * 1000L, "📝 ${customer.name} — Vertragstermin", false) }
                    customer.anniversaryAt?.let { if (it in startOfToday..endOfToday) entries += WidgetEntry(it + 9 * 60 * 60 * 1000L, "🎂 ${customer.name} — Jahrestag", false) }
                }
                entries.sortBy { it.time }

                val views = RemoteViews(context.packageName, R.layout.widget_followup)
                views.removeAllViews(R.id.widgetLinesContainer)

                val timeFmt = SimpleDateFormat("HH:mm", Locale.GERMANY)
                entries.forEach { entry ->
                    val line = RemoteViews(context.packageName, R.layout.widget_line)
                    line.setTextViewText(R.id.widgetLineTime, timeFmt.format(Date(entry.time)))
                    line.setTextViewText(R.id.widgetLineText, entry.label)
                    views.addView(R.id.widgetLinesContainer, line)
                }

                views.setViewVisibility(R.id.widgetEmpty, if (entries.isEmpty()) View.VISIBLE else View.GONE)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
