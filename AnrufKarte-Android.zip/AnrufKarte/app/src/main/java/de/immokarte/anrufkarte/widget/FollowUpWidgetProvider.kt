package de.immokarte.anrufkarte.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.view.View
import android.widget.RemoteViews
import de.immokarte.anrufkarte.R
import de.immokarte.anrufkarte.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/** Zeigt die heute fälligen Wiedervorlagen direkt auf dem Homescreen,
 *  ohne die App zu öffnen. Zeigt bis zu 3 Namen; aktualisiert sich stündlich
 *  automatisch und zusätzlich sofort nach jeder Änderung in der App. */
class FollowUpWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, FollowUpWidgetProvider::class.java))
            ids.forEach { id -> updateWidget(context, manager, id) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            CoroutineScope(Dispatchers.IO).launch {
                val endOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
                }.timeInMillis
                val due = AppDatabase.getInstance(context.applicationContext)
                    .customerDao().getDueFollowUps(endOfToday)

                val views = RemoteViews(context.packageName, R.layout.widget_followup)
                val lineIds = listOf(R.id.widgetLine1, R.id.widgetLine2, R.id.widgetLine3)
                lineIds.forEachIndexed { i, viewId ->
                    if (i < due.size) {
                        views.setViewVisibility(viewId, View.VISIBLE)
                        views.setTextViewText(viewId, due[i].name)
                    } else {
                        views.setViewVisibility(viewId, View.GONE)
                    }
                }
                views.setViewVisibility(R.id.widgetEmpty, if (due.isEmpty()) View.VISIBLE else View.GONE)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
