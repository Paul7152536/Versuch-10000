package de.immokarte.anrufkarte.data

data class StatusOption(val key: String, val label: String)

/** Zentrale, einzige Quelle für die Status-Liste — wird von der Kundenliste,
 *  dem Bearbeiten-Bildschirm, der Anruf-Karte und der Statistik-Seite
 *  gemeinsam genutzt, damit sie garantiert nie auseinanderlaufen. */
object StatusInfo {
    val options = listOf(
        StatusOption("potenziell", "Potenzieller Kunde"),
        StatusOption("kunde", "Kunde"),
        StatusOption("interessent", "Interessent"),
        StatusOption("besichtigung", "Besichtigung vereinbart"),
        StatusOption("angebot", "Angebot abgegeben"),
        StatusOption("pendent", "Pendent (Entscheidung offen)"),
        StatusOption("abgelehnt", "Abgelehnt"),
        StatusOption("abschluss", "Kauf abgeschlossen"),
    )

    val keys: List<String> = options.map { it.key }
    val labels: List<String> = options.map { it.label }
    private val labelByKey: Map<String, String> = options.associate { it.key to it.label }

    /** Status, bei denen der Kontakt nicht mehr aktiv "in Bearbeitung" ist —
     *  wird für Filter/Vorschläge genutzt, die nur offene Fälle zeigen sollen. */
    val closedStatuses = setOf("kunde", "abgelehnt", "abschluss")

    fun label(key: String): String = labelByKey[key] ?: key

    /** Eine Farbe je Status — für die kleinen Farbpunkte in der Kontaktliste,
     *  auf einen Blick erfassbar statt den Text lesen zu müssen. */
    fun color(key: String): Int = when (key) {
        "potenziell" -> 0xFF9CA3AF.toInt()   // Grau — noch ganz am Anfang
        "kunde" -> 0xFF3FB950.toInt()        // Grün — schon Kunde
        "interessent" -> 0xFF6366F1.toInt()  // Indigo
        "besichtigung" -> 0xFFA9823D.toInt() // Messing
        "angebot" -> 0xFFF97316.toInt()      // Orange
        "pendent" -> 0xFFEAB308.toInt()      // Gelb — Entscheidung offen
        "abgelehnt" -> 0xFF8C3B2B.toInt()    // Rotbraun
        "abschluss" -> 0xFF16A34A.toInt()    // Dunkelgrün — abgeschlossen
        else -> 0xFF8B93A0.toInt()
    }
}
