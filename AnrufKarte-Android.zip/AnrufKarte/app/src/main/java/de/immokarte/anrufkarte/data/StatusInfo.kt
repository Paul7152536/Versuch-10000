package de.immokarte.anrufkarte.data

data class StatusOption(val key: String, val label: String)

/** Zentrale, einzige Quelle für die Status-Liste — wird von der Kundenliste,
 *  dem Bearbeiten-Bildschirm, der Anruf-Karte und der Statistik-Seite
 *  gemeinsam genutzt, damit sie garantiert nie auseinanderlaufen. */
object StatusInfo {
    val options = listOf(
        StatusOption("interessent", "Interessent"),
        StatusOption("besichtigung", "Besichtigung vereinbart"),
        StatusOption("angebot", "Angebot abgegeben"),
        StatusOption("pendent", "Pendent (Entscheidung offen)"),
        StatusOption("kunde", "Kunde"),
        StatusOption("abgelehnt", "Abgelehnt"),
        StatusOption("abschluss", "Kauf abgeschlossen"),
    )

    val keys: List<String> = options.map { it.key }
    val labels: List<String> = options.map { it.label }
    private val labelByKey: Map<String, String> = options.associate { it.key to it.label }

    /** Status, bei denen der Kontakt nicht mehr aktiv "in Bearbeitung" ist —
     *  wird für Filter/Vorschläge genutzt, die nur offene Fälle zeigen sollen. */
    val closedStatuses = setOf("kunde", "abgelehnt", "abschluss")

    fun label(key: String): String = labelByKey[key] ?: key
}
