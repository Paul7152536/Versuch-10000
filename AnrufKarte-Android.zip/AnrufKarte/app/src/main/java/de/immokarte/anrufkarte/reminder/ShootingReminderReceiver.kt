package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.CustomerEditActivity
import de.immokarte.anrufkarte.data.WhatsAppTemplates

/** Feuert 1 Tag vor einem Shooting-Termin (siehe ShootingReminderScheduler) —
 *  erinnert daran, den Kunden selbst nochmal zu benachrichtigen, mit einer
 *  vorgefertigten Nachricht direkt als Knopf in der Benachrichtigung. */
class ShootingReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_CUSTOMER_ID = "extra_customer_id"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_DATE_LABEL = "extra_date_label"
        const val EXTRA_TIME_LABEL = "extra_time_label"
        private const val CHANNEL_ID = "shooting_reminder"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val customerId = intent.getLongExtra(EXTRA_CUSTOMER_ID, -1L)
        val name = intent.getStringExtra(EXTRA_NAME) ?: return
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        val dateLabel = intent.getStringExtra(EXTRA_DATE_LABEL).orEmpty()
        val timeLabel = intent.getStringExtra(EXTRA_TIME_LABEL).orEmpty()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Shooting-Erinnerung", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            context, customerId.toInt(),
            Intent(context, CustomerEditActivity::class.java).apply {
                putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, customerId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val messageIntent = if (phone.isNotBlank()) {
            val text = "Kurze Erinnerung: Morgen, $dateLabel, ist unser Shooting-Termin um $timeLabel Uhr geplant. Bis dann!\n\nMit freundlichen Grüßen\nPaul Görner"
            val digits = phone.filter { it.isDigit() || it == '+' }.removePrefix("+")
            val link = WhatsAppTemplates.buildLinkFromText(digits, text)
            PendingIntent.getActivity(
                context, customerId.toInt() + 800_000, Intent(Intent.ACTION_VIEW, Uri.parse(link)),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("📸 Shooting morgen: $name")
            .setContentText("Kunden noch selbst benachrichtigen — Termin um $timeLabel Uhr")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        if (messageIntent != null) builder.addAction(android.R.drawable.ic_menu_send, "Nachricht senden", messageIntent)

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(3005 + customerId.toInt(), builder.build())
    }
}
