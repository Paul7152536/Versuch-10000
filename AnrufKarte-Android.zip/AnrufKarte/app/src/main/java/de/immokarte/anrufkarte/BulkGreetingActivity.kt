package de.immokarte.anrufkarte

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.WhatsAppTemplates
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Liste aller offenen Kontakte (nicht "Kauf abgeschlossen") mit gewählter
 * Vorlage ODER frei geschriebenem Text. WhatsApp erlaubt keinen echten
 * Massenversand per App — daher wird hier Kontakt für Kontakt einzeln der
 * vorausgefüllte Chat geöffnet, du bestätigst den Versand jeweils selbst.
 * Bereits geöffnete Kontakte werden mit einem Häkchen markiert.
 */
class BulkGreetingActivity : AppCompatActivity() {

    private val greetingTemplates = listOf(
        "✏️ Eigener Text" to "",
        "🎄 Weihnachtsgruß" to "Hallo {name}, ich wünsche Ihnen und Ihren Liebsten ein frohes Weihnachtsfest und einen guten Rutsch ins neue Jahr!",
        "🎆 Neujahrsgruß" to "Hallo {name}, alles Gute für das neue Jahr! Falls sich bei Ihnen etwas in Sachen Immobilien tut, bin ich gerne für Sie da.",
        "☀️ Sommergruß" to "Hallo {name}, ich wünsche Ihnen einen schönen Sommer! Melden Sie sich gerne, falls es Neuigkeiten bei Ihnen gibt.",
    )
    private val sentIds = mutableSetOf<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_bulk_greeting)

        val spinner = findViewById<android.widget.Spinner>(R.id.spinnerGreetingTemplate)
        val etMessage = findViewById<EditText>(R.id.etCustomMessage)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, greetingTemplates.map { it.first })
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val template = greetingTemplates[position].second
                if (template.isNotBlank()) etMessage.setText(template)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        val container = findViewById<LinearLayout>(R.id.greetingContainer)

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val customers = withContext(Dispatchers.IO) { dao.getAllWithProperties() }
                .filter { it.customer.status !in de.immokarte.anrufkarte.data.StatusInfo.closedStatuses }

            if (customers.isEmpty()) {
                container.addView(TextView(this@BulkGreetingActivity).apply {
                    text = "Keine offenen Kontakte gefunden."
                    setTextColor(0xFF8B93A0.toInt())
                })
                return@launch
            }

            customers.forEach { c ->
                val row = LinearLayout(this@BulkGreetingActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(24, 24, 24, 24)
                    setBackgroundResource(R.drawable.bg_card)
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    params.bottomMargin = 8
                    layoutParams = params
                }
                val tvName = TextView(this@BulkGreetingActivity).apply {
                    text = c.customer.name
                    textSize = 14f
                    setTextColor(0xFF20242B.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvStatus = TextView(this@BulkGreetingActivity).apply {
                    text = if (sentIds.contains(c.customer.id)) "✓ Geöffnet" else "WhatsApp öffnen"
                    textSize = 12f
                    setTextColor(if (sentIds.contains(c.customer.id)) 0xFF3E6B4F.toInt() else 0xFF1E2C3B.toInt())
                }
                row.addView(tvName)
                row.addView(tvStatus)
                row.setOnClickListener {
                    val messageText = etMessage.text.toString()
                    if (messageText.isBlank()) {
                        android.widget.Toast.makeText(this@BulkGreetingActivity, "Bitte zuerst eine Nachricht schreiben oder Vorlage wählen.", android.widget.Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    val digits = c.customer.phone.filter { it.isDigit() }
                    val link = WhatsAppTemplates.buildLink(digits, c.customer.name, messageText)
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    }
                    sentIds += c.customer.id
                    tvStatus.text = "✓ Geöffnet"
                    tvStatus.setTextColor(0xFF3E6B4F.toInt())
                }
                container.addView(row)
            }
        }
    }
}
