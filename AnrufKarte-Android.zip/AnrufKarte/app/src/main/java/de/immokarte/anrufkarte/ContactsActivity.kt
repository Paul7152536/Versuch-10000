package de.immokarte.anrufkarte

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.PhoneUtils
import de.immokarte.anrufkarte.data.StatusInfo
import de.immokarte.anrufkarte.databinding.ActivityContactsBinding
import de.immokarte.anrufkarte.ui.CustomerAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Eigene, vollflächige Seite für die komplette Kontaktliste — größere,
 * besser lesbare Karten als in der kompakten Vorschau auf dem
 * Hauptbildschirm, mit eigener Suche und eigenen Status-Filtern.
 */
class ContactsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactsBinding
    private var allCustomers: List<CustomerWithProperties> = emptyList()
    private var filter: String = "alle"
    private lateinit var adapter: CustomerAdapter

    private val editCustomer =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) loadCustomers()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CustomerAdapter(
            onClick = { id ->
                editCustomer.launch(Intent(this, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, id))
            },
            onToggleStar = { id, important ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().setImportant(id, important) }
                    loadCustomers()
                }
            },
            onCall = { phone -> startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) },
            onDismissMissed = { },
            expanded = true
        )
        binding.recyclerContacts.layoutManager = LinearLayoutManager(this)
        binding.recyclerContacts.adapter = adapter

        setupFilterChips()

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applyFilters() }
            override fun afterTextChanged(s: Editable?) {}
        })

        loadCustomers()
    }

    override fun onResume() {
        super.onResume()
        loadCustomers()
    }

    private fun setupFilterChips() {
        val filters = listOf("alle" to getString(R.string.filter_alle)) + StatusInfo.options.map { it.key to it.label }
        binding.filterContainer.removeAllViews()
        filters.forEach { (key, label) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12.5f
                setPadding(28, 16, 28, 16)
                setTextColor(if (key == filter) 0xFFF5F1E7.toInt() else 0xFF5C6470.toInt())
                setBackgroundResource(if (key == filter) R.drawable.bg_navy_pill else R.drawable.bg_card)
                setOnClickListener { filter = key; setupFilterChips(); applyFilters() }
            }
            val params = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 8
            tv.layoutParams = params
            binding.filterContainer.addView(tv)
        }
    }

    private fun loadCustomers() {
        lifecycleScope.launch {
            allCustomers = withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).customerDao().getAllWithProperties() }
            applyFilters()
        }
    }

    private fun applyFilters() {
        val query = binding.etSearch.text.toString().trim()
        var list = allCustomers
        if (filter != "alle") list = list.filter { it.customer.status == filter }
        if (query.isNotBlank()) {
            list = list.filter { c ->
                c.customer.name.contains(query, ignoreCase = true) ||
                    c.customer.phone.contains(query) ||
                    c.customer.phone2.contains(query) ||
                    c.customer.tags.contains(query, ignoreCase = true) ||
                    c.customer.notes.contains(query, ignoreCase = true) ||
                    de.immokarte.anrufkarte.data.NoteLogUtils.parse(c.customer.noteLog).any { it.text.contains(query, ignoreCase = true) }
            }
        }
        adapter.submit(list, query)
        binding.tvCount.text = "${list.size} Kontakt${if (list.size == 1) "" else "e"}"
    }
}
