package de.immokarte.anrufkarte.call

import android.telecom.Call
import android.telecom.CallScreeningService

/**
 * Zuverlässigste SIM-Erkennung: Android-Telecom teilt uns hier direkt mit,
 * über welches "PhoneAccount" (= welche SIM) ein eingehender Anruf läuft.
 * Anders als die Zusatzfelder im allgemeinen "es klingelt"-Signal ist diese
 * Angabe herstellerunabhängig korrekt — sie kommt aus derselben Quelle, aus
 * der auch die Telefon-App selbst weiß, welche SIM gerade klingelt.
 *
 * WICHTIG: Dieser Dienst blockiert oder filtert NICHTS. Jeder Anruf wird
 * unverändert durchgelassen; wir lesen ausschließlich die SIM-Information
 * mit. Damit Android den Dienst überhaupt aufruft, muss die App einmalig als
 * "Anrufe filtern"-App zugelassen werden (siehe Einstellungen in der App).
 */
class SimScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        runCatching {
            if (callDetails.callDirection == Call.Details.DIRECTION_INCOMING) {
                val subId = SimDetection.subIdForAccount(this, callDetails.accountHandle)
                if (subId >= 0) SimDetection.record(subId, SimDetection.CONFIDENCE_SURE)
            }
        }

        // Anruf IMMER unverändert durchlassen — wir sind hier nur Mitleser.
        runCatching {
            respondToCall(
                callDetails,
                CallResponse.Builder()
                    .setDisallowCall(false)
                    .setRejectCall(false)
                    .setSilenceCall(false)
                    .setSkipCallLog(false)
                    .setSkipNotification(false)
                    .build()
            )
        }
    }
}
