package de.immokarte.anrufkarte.call

import android.content.Context
import android.os.Build
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Zentrale Sammelstelle für die Frage "über welche SIM kommt der Anruf gerade
 * rein?".
 *
 * Hintergrund: Android liefert diese Information NICHT verlässlich über einen
 * einzelnen Weg. Deshalb füttern hier mehrere Quellen parallel ein, und die
 * jeweils verlässlichste gewinnt:
 *
 *   SICHER  (CallScreeningService) — Telecom sagt uns direkt das PhoneAccount,
 *           über das der Anruf läuft. Das ist die einzige Quelle, die
 *           herstellerunabhängig wirklich stimmt. Setzt voraus, dass der
 *           Nutzer die App einmalig als "Anrufe filtern"-App zulässt.
 *   GUT     (SimCallStateService) — pro SIM eigener Zustands-Lauscher. Klappt
 *           meistens, kann aber bei gleichzeitigen Ereignissen danebenliegen.
 *   SCHWACH (Broadcast-Zusatzfelder) — herstellerabhängig, oft gar nicht da.
 *
 * Ein neuer Wert überschreibt einen alten nur, wenn er mindestens gleich
 * verlässlich ist — sonst würde eine schwache Quelle eine sichere Erkennung
 * wieder kaputtmachen.
 */
object SimDetection {

    const val CONFIDENCE_NONE = 0
    const val CONFIDENCE_WEAK = 1
    const val CONFIDENCE_GOOD = 2
    const val CONFIDENCE_SURE = 3

    /** Wie lange eine Erkennung als "zum aktuellen Anruf gehörend" gilt. */
    private const val VALID_FOR_MS = 12_000L

    @Volatile private var subId: Int = -1
    @Volatile private var confidence: Int = CONFIDENCE_NONE
    @Volatile private var recordedAt: Long = 0L

    /** Meldet eine erkannte SIM. Schwächere Quellen überschreiben eine noch
     *  gültige, stärkere Erkennung bewusst nicht. */
    fun record(newSubId: Int, newConfidence: Int) {
        if (newSubId < 0) return
        val stillValid = System.currentTimeMillis() - recordedAt < VALID_FOR_MS
        if (stillValid && newConfidence < confidence) return
        subId = newSubId
        confidence = newConfidence
        recordedAt = System.currentTimeMillis()
    }

    /** Setzt die Erkennung zurück — wird beim Anrufende aufgerufen, damit ein
     *  Folgeanruf nicht versehentlich den alten Wert erbt. */
    fun clear() {
        subId = -1
        confidence = CONFIDENCE_NONE
        recordedAt = 0L
    }

    /** Aktuell erkannte SIM (oder -1). */
    fun currentSubId(): Int =
        if (System.currentTimeMillis() - recordedAt < VALID_FOR_MS) subId else -1

    /** Verlässlichkeit der aktuellen Erkennung. */
    fun currentConfidence(): Int =
        if (System.currentTimeMillis() - recordedAt < VALID_FOR_MS) confidence else CONFIDENCE_NONE

    /**
     * Übersetzt ein PhoneAccount (das, was Telecom uns gibt) in eine
     * Subscription-ID (das, was wir gespeichert haben).
     *
     * Ab Android 11 gibt es dafür eine offizielle Methode. Darunter hilft ein
     * bewährter Umweg: die ID des PhoneAccounts ist auf sehr vielen Geräten
     * schlicht die Subscription-ID als Text — und falls nicht, vergleichen wir
     * mit der ICCID (der eindeutigen Kennung der SIM-Karte), die ebenfalls
     * häufig als PhoneAccount-ID verwendet wird.
     */
    fun subIdForAccount(context: Context, handle: PhoneAccountHandle?): Int {
        if (handle == null) return -1
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return -1

        // Offizieller Weg ab Android 11
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching {
                val tm = context.getSystemService(TelephonyManager::class.java)
                val telecom = context.getSystemService(TelecomManager::class.java)
                val account = telecom?.getPhoneAccount(handle)
                if (account != null && tm != null) {
                    val id = tm.getSubscriptionId(handle)
                    if (id >= 0 && id != SubscriptionManager.INVALID_SUBSCRIPTION_ID) return id
                }
            }
        }

        val accountId = handle.id ?: return -1

        // Umweg 1: PhoneAccount-ID ist direkt die Subscription-ID
        accountId.toIntOrNull()?.let { asInt ->
            runCatching {
                val sm = context.getSystemService(SubscriptionManager::class.java)
                val active = sm?.activeSubscriptionInfoList.orEmpty()
                if (active.any { it.subscriptionId == asInt }) return asInt
            }
        }

        // Umweg 2: PhoneAccount-ID ist die ICCID der SIM-Karte
        runCatching {
            val sm = context.getSystemService(SubscriptionManager::class.java)
            val active = sm?.activeSubscriptionInfoList.orEmpty()
            active.forEach { info ->
                val iccId = info.iccId
                if (!iccId.isNullOrBlank() && (accountId == iccId || accountId.startsWith(iccId) || iccId.startsWith(accountId))) {
                    return info.subscriptionId
                }
            }
        }

        return -1
    }
}
