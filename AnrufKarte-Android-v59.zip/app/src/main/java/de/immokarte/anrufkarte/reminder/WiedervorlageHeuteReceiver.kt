package de.immokarte.anrufkarte.reminder

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.PhoneUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Reagiert auf "Wiedervorlage heute" in der Verpasster-Anruf-Benachrichtigung:
 *  trägt für den Kontakt automatisch eine Wiedervorlage für heute Nachmittag/
 *  Abend ein (ab 17 Uhr — ist es schon später, dann für jetzt gleich). */
class WiedervorlageHeuteReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_NOTIF_ID = "extra_notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val phone = intent.getStringExtra(EXTRA_PHONE) ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, phone.hashCode())
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId)

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(context.applicationContext).customerDao()
            val match = dao.findByPhone(PhoneUtils.normalize(phone))
            if (match != null) {
                val now = Calendar.getInstance()
                val heute17Uhr = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 17); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
                val zielzeit = if (now.before(heute17Uhr)) heute17Uhr.timeInMillis else now.timeInMillis
                dao.setFollowUp(match.customer.id, zielzeit)
                val label = SimpleDateFormat("HH:mm", Locale.GERMANY).format(zielzeit)
                withContext(Dispatchers.Main) { Toast.makeText(context, "Wiedervorlage für heute, $label Uhr eingetragen.", Toast.LENGTH_SHORT).show() }
            } else {
                withContext(Dispatchers.Main) { Toast.makeText(context, "Kein Kontakt mit dieser Nummer gefunden.", Toast.LENGTH_SHORT).show() }
            }
            pending.finish()
        }
    }
}
