package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.MainActivity
import de.immokarte.anrufkarte.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/** Prüft täglich (per AlarmScheduler ausgelöst), ob Wiedervorlagen fällig sind,
 *  und zeigt dafür eine System-Benachrichtigung. */
class FollowUpReminderReceiver : BroadcastReceiver() {

    companion object {
        private const val CHANNEL_ID = "followup_reminder"
        private const val NOTIF_ID = 2001
        private const val NOTIF_ID_ANNIVERSARY = 2002
        private const val NOTIF_ID_CONTRACT = 2003
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val endOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
                }.timeInMillis
                val dao = AppDatabase.getInstance(context.applicationContext).customerDao()

                val due = dao.getDueFollowUps(endOfToday)
                if (due.isNotEmpty()) {
                    showNotification(
                        context, NOTIF_ID,
                        "${due.size} Wiedervorlage${if (due.size == 1) "" else "n"} heute fällig",
                        due.take(3).joinToString(", ") { it.name }
                    )
                } else {
                    // Nichts (mehr) fällig -> alte Benachrichtigung entfernen.
                    // Fehlte bisher, dadurch blieb eine einmal gezeigte Meldung
                    // hängen, auch wenn die Wiedervorlage längst erledigt war.
                    cancelNotification(context, NOTIF_ID)
                }

                val anniversaries = dao.getDueAnniversaries(endOfToday)
                if (anniversaries.isNotEmpty()) {
                    showNotification(
                        context, NOTIF_ID_ANNIVERSARY,
                        "🎉 Zeit für ein Update-Gespräch",
                        "${anniversaries.take(3).joinToString(", ") { it.name }} — vor 1 Jahr gekauft/gemietet"
                    )
                } else {
                    cancelNotification(context, NOTIF_ID_ANNIVERSARY)
                }

                val contracts = dao.getDueContracts(endOfToday)
                if (contracts.isNotEmpty()) {
                    showNotification(
                        context, NOTIF_ID_CONTRACT,
                        "📝 Vertragstermin heute",
                        contracts.take(3).joinToString(", ") { it.name }
                    )
                } else {
                    cancelNotification(context, NOTIF_ID_CONTRACT)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(context: Context, notifId: Int, title: String, text: String) {
        createChannel(context)
        val openIntent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context, notifId, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(notifId, notification)
    }

    private fun cancelNotification(context: Context, notifId: Int) {
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Wiedervorlage-Erinnerungen", NotificationManager.IMPORTANCE_DEFAULT
            )
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
