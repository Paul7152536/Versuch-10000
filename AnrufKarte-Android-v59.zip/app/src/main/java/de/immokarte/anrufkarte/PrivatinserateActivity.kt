package de.immokarte.anrufkarte

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CalendarSync
import de.immokarte.anrufkarte.data.PrivatinseratEntity
import de.immokarte.anrufkarte.data.PrivatinseratParser
import de.immokarte.anrufkarte.data.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Privatinserate — private Zeitungs-/Kleinanzeigen, die Paul entdeckt und
 * nachverfolgen will. Schema: Name (Anbieter) / Objekt / Lage / Preis /
 * Telefon / E-Mail / Eingestellt am / Privat eindeutig (🟢) oder unklar (🟡).
 * Ganzen Anzeigentext einfügen → wird automatisch zerlegt, auch mehrere
 * Anzeigen auf einmal. Karten sind bewusst groß/übersichtlich gehalten.
 * Für jeden Eintrag lässt sich optional eine Kalender-Erinnerung setzen.
 */
class PrivatinserateActivity : AppCompatActivity() {

    private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)
    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_privatinserate)
        val c = findViewById<LinearLayout>(R.id.privatinserateContainer)

        // ---- Einklappbarer "Neues Inserat erfassen"-Bereich ----
        val toggleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundResource(R.drawable.bg_card)
            isClickable = true; isFocusable = true
        }
        toggleRow.addView(TextView(this).apply {
            text = "➕ Neues Inserat erfassen"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val chevron = TextView(this).apply {
            text = "▸"
            textSize = 14f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
        }
        toggleRow.addView(chevron)
        c.addView(toggleRow)

        val formSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = android.view.View.GONE
        }
        c.addView(formSection)

        toggleRow.setOnClickListener {
            val expand = formSection.visibility != android.view.View.VISIBLE
            formSection.visibility = if (expand) android.view.View.VISIBLE else android.view.View.GONE
            chevron.text = if (expand) "▾" else "▸"
        }

        // ---- Einfügen & automatisch zerlegen ----
        sectionHeader(formSection, "Anzeigentext einfügen")
        hint(formSection, "Ganzen Text aus der Zeitung/Kleinanzeige hier reinkopieren — wird automatisch in die Felder unten aufgeteilt. Auch mehrere Anzeigen auf einmal möglich (mit Leerzeile getrennt).")
        val pasteBox = EditText(this).apply {
            hint = "Name: Familie Bauer\nObjekt: 118 m², 5 Zimmer, Bj. 2005, Doppelgarage, Garten\nLage: Bayern / bei Passau\nPreis: 525.000 €\nTelefon: 0851 1234567\nE-Mail: …\nEingestellt am: 29.08.2026\nPrivat eindeutig: 🟢"
            minLines = 7
            gravity = Gravity.TOP
            ThemeManager.styleDialogField(this@PrivatinserateActivity, this)
        }
        formSection.addView(pasteBox)

        // ---- Einzelfelder (werden beim Einfügen automatisch befüllt, bleiben editierbar) ----
        sectionHeader(formSection, "Eckdaten")
        val etName = fieldInput(formSection, "Name (Anbieter)")
        val etObjekt = fieldInput(formSection, "Objekt")
        val etLage = fieldInput(formSection, "Lage")
        val etPreis = fieldInput(formSection, "Preis")
        val etTelefon = fieldInput(formSection, "Telefon")
        val etEmail = fieldInput(formSection, "E-Mail")
        var eingestelltAt: Long? = null
        val tvEingestellt = TextView(this).apply {
            text = "Eingestellt am: —"
            textSize = 12.5f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 10
            layoutParams = p
            setOnClickListener {
                val cal = Calendar.getInstance()
                DatePickerDialog(this@PrivatinserateActivity, { _, y, m, d ->
                    cal.set(y, m, d, 0, 0, 0)
                    eingestelltAt = cal.timeInMillis
                    text = "Eingestellt am: ${dateFmt.format(cal.time)}"
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        formSection.addView(tvEingestellt)

        // ---- "Privat eindeutig?" — 🟢/🟡 statt Freitext-Hinweis ----
        sectionHeader(formSection, "Privat eindeutig?")
        var privatStatus = ""
        val privatRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 6
            layoutParams = p
        }
        lateinit var btnGruen: TextView
        lateinit var btnGelb: TextView
        fun refreshPrivatButtons() {
            btnGruen.setBackgroundResource(if (privatStatus == "eindeutig") R.drawable.bg_navy_pill else R.drawable.bg_paper_pill)
            btnGruen.setTextColor(if (privatStatus == "eindeutig") 0xFFFFFFFF.toInt() else ThemeManager.resolveColor(this, R.attr.colorInk))
            btnGelb.setBackgroundResource(if (privatStatus == "unklar") R.drawable.bg_navy_pill else R.drawable.bg_paper_pill)
            btnGelb.setTextColor(if (privatStatus == "unklar") 0xFFFFFFFF.toInt() else ThemeManager.resolveColor(this, R.attr.colorInk))
        }
        btnGruen = TextView(this).apply {
            text = "🟢 Eindeutig privat"
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { privatStatus = "eindeutig"; refreshPrivatButtons() }
        }
        btnGelb = TextView(this).apply {
            text = "🟡 Unklar"
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = 6 }
            setOnClickListener { privatStatus = "unklar"; refreshPrivatButtons() }
        }
        privatRow.addView(btnGruen); privatRow.addView(btnGelb)
        formSection.addView(privatRow)
        refreshPrivatButtons()

        // Klappt den Erfassungsbereich wieder zu, sobald etwas gespeichert
        // wurde — danach will man ja meist die Liste sehen, nicht das Formular.
        fun collapseForm() {
            formSection.visibility = android.view.View.GONE
            chevron.text = "▸"
        }
        fun clearForm() {
            pasteBox.text.clear(); etName.text.clear(); etObjekt.text.clear(); etLage.text.clear(); etPreis.text.clear()
            etTelefon.text.clear(); etEmail.text.clear()
            eingestelltAt = null; tvEingestellt.text = "Eingestellt am: —"
            privatStatus = ""; refreshPrivatButtons()
        }

        primaryButton(formSection, "Anzeigentext übernehmen") {
            val blocks = PrivatinseratParser.parseMultiple(pasteBox.text.toString())
            when {
                blocks.isEmpty() -> Toast.makeText(this, "Konnte nichts erkennen — bitte Felder unten von Hand ausfüllen.", Toast.LENGTH_SHORT).show()
                blocks.size == 1 -> {
                    val p = blocks[0]
                    etName.setText(p.name); etObjekt.setText(p.objekt); etLage.setText(p.lage); etPreis.setText(p.preis)
                    etTelefon.setText(p.telefon); etEmail.setText(p.email)
                    eingestelltAt = p.eingestelltAt
                    tvEingestellt.text = "Eingestellt am: ${p.eingestelltAt?.let { dateFmt.format(it) } ?: "—"}"
                    privatStatus = p.privatStatus
                    refreshPrivatButtons()
                }
                else -> {
                    // Mehrere Inserate auf einmal reinkopiert — jedes einzeln
                    // zum Anpassen wäre umständlich, deswegen direkt alle
                    // speichern; einzelne Korrekturen macht man danach an
                    // der jeweiligen Karte.
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) {
                            val dao = AppDatabase.getInstance(applicationContext).privatinseratDao()
                            blocks.forEach { p ->
                                dao.upsert(PrivatinseratEntity(name = p.name, objekt = p.objekt, lage = p.lage, preis = p.preis, telefon = p.telefon, email = p.email, eingestelltAt = p.eingestelltAt, privatStatus = p.privatStatus))
                            }
                        }
                        clearForm()
                        Toast.makeText(this@PrivatinserateActivity, "${blocks.size} Inserate übernommen und gespeichert.", Toast.LENGTH_SHORT).show()
                        collapseForm()
                        loadList()
                    }
                }
            }
        }

        primaryButton(formSection, "Inserat speichern") {
            if (etObjekt.text.isBlank() && etLage.text.isBlank() && etPreis.text.isBlank() && etName.text.isBlank()) {
                Toast.makeText(this, "Bitte mindestens Name, Objekt, Lage oder Preis ausfüllen.", Toast.LENGTH_SHORT).show()
                return@primaryButton
            }
            val entity = PrivatinseratEntity(
                name = etName.text.toString().trim(), objekt = etObjekt.text.toString().trim(), lage = etLage.text.toString().trim(),
                preis = etPreis.text.toString().trim(), telefon = etTelefon.text.toString().trim(), email = etEmail.text.toString().trim(),
                eingestelltAt = eingestelltAt, privatStatus = privatStatus
            )
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().upsert(entity) }
                clearForm()
                collapseForm()
                loadList()
            }
        }

        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        sectionHeader(c, "Erfasste Inserate")

        // Sortierung — Karten zeigen jetzt nur noch das Wichtigste auf einen
        // Blick, den Rest gibt's antippen im Detail-Fenster.
        val sortRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        val sortOptions = listOf("neueste" to "Neueste", "preis" to "Preis", "ort" to "Ort")
        val sortButtons = mutableMapOf<String, TextView>()
        fun refreshSortButtons() {
            sortOptions.forEach { (key, _) ->
                val btn = sortButtons[key] ?: return@forEach
                btn.setBackgroundResource(if (sortMode == key) R.drawable.bg_navy_pill else R.drawable.bg_paper_pill)
                btn.setTextColor(if (sortMode == key) 0xFFFFFFFF.toInt() else ThemeManager.resolveColor(this, R.attr.colorInk))
            }
        }
        sortOptions.forEachIndexed { i, (key, label) ->
            val btn = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(14, 14, 14, 14)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i > 0) marginStart = 6
                }
                setOnClickListener { sortMode = key; refreshSortButtons(); loadList() }
            }
            sortButtons[key] = btn
            sortRow.addView(btn)
        }
        c.addView(sortRow)
        refreshSortButtons()

        c.addView(listContainer)
        loadList()
    }

    private var sortMode: String = "neueste"

    private fun loadList() {
        lifecycleScope.launch {
            var items = withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().getAll() }
            items = when (sortMode) {
                "preis" -> items.sortedBy { it.preis.filter { c -> c.isDigit() }.toLongOrNull() ?: Long.MAX_VALUE }
                "ort" -> items.sortedBy { it.lage.lowercase() }
                else -> items // "neueste" — bereits so von der Datenbank sortiert (offene zuerst, dann neueste zuerst)
            }
            listContainer.removeAllViews()
            if (items.isEmpty()) {
                hint(listContainer, "Noch keine Inserate erfasst.")
                return@launch
            }
            items.forEach { item -> listContainer.addView(buildCard(item)) }
        }
    }

    /** Kompakte Karte — nur das Wichtigste auf einen Blick (Name, Preis,
     *  Lage, Status). Antippen öffnet das Detail-Fenster mit allem
     *  weiteren (Objekt, Kontakt, Datum …). */
    private fun buildCard(item: PrivatinseratEntity): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundResource(R.drawable.bg_card)
            alpha = if (item.kontaktiert) 0.55f else 1f
            isClickable = true; isFocusable = true
            setOnClickListener { showDetailDialog(item) }
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.bottomMargin = 12
            layoutParams = p
        }

        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(TextView(this).apply {
            text = item.preis.ifBlank { "Preis unbekannt" }
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, android.R.attr.colorPrimary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (item.privatStatus.isNotBlank()) {
            topRow.addView(TextView(this).apply {
                text = if (item.privatStatus == "eindeutig") "🟢" else "🟡"
                textSize = 15f
            })
        }
        if (item.kontaktiert) {
            topRow.addView(TextView(this).apply {
                text = "  ✓ kontaktiert"
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorSuccess))
            })
        }
        card.addView(topRow)

        if (item.name.isNotBlank()) {
            card.addView(TextView(this).apply {
                text = item.name
                textSize = 14.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
                val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                p.topMargin = 4
                layoutParams = p
            })
        }

        card.addView(TextView(this).apply {
            text = item.lage.ifBlank { "Lage unbekannt" }
            textSize = 13f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 2
            layoutParams = p
        })

        // Objekt/Kontakt/Datum stehen jetzt nur noch im Detail-Fenster
        // (Karte antippen) — hier nur eine knappe Zusammenfassungszeile,
        // damit die Liste auf einen Blick übersichtlich bleibt.
        if (item.objekt.isNotBlank()) {
            card.addView(TextView(this).apply {
                text = item.objekt
                textSize = 11.5f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
                val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                p.topMargin = 6
                layoutParams = p
            })
        }
        val hasKontaktinfo = item.telefon.isNotBlank() || item.email.isNotBlank()
        if (hasKontaktinfo || item.erinnerungAt != null) {
            card.addView(TextView(this).apply {
                text = listOfNotNull(
                    if (item.telefon.isNotBlank()) "📞" else null,
                    if (item.email.isNotBlank()) "✉️" else null,
                    item.erinnerungAt?.let { "📅 ${SimpleDateFormat("dd.MM., HH:mm", Locale.GERMANY).format(it)}" }
                ).joinToString("   ")
                textSize = 11f
                setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
                val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                p.topMargin = 4
                layoutParams = p
            })
        }
        hint(card, "Antippen für alle Details")

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 16
            layoutParams = p
        }
        actions.addView(actionButton("📅 Erinnerung") { pickReminder(item) })
        actions.addView(actionButton(if (item.kontaktiert) "↩︎ Wieder offen" else "✓ Kontaktiert") {
            if (item.kontaktiert) {
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().setKontaktiert(item.id, false) }
                    loadList()
                }
            } else {
                showUebernahmeDialog(item)
            }
        })
        actions.addView(actionButton("🗑") {
            AlertDialog.Builder(this)
                .setTitle("Inserat löschen?")
                .setMessage("Dieses Inserat wird endgültig gelöscht. Das lässt sich nicht rückgängig machen.")
                .setPositiveButton("Endgültig löschen") { _, _ ->
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().delete(item.id) }
                        loadList()
                    }
                }
                .setNegativeButton("Abbrechen", null)
                .show()
        })
        card.addView(actions)
        return card
    }

    /** Öffnet sich beim Markieren als "kontaktiert" — Name/Telefon/E-Mail
     *  sind schon aus dem Inserat bekannt, nur Adresse muss noch ergänzt
     *  werden. "Nur markieren" geht auch ohne, falls (noch) kein Kontakt
     *  draus werden soll. */
    private fun showUebernahmeDialog(item: PrivatinseratEntity) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }
        fun label(text: String) {
            container.addView(TextView(this@PrivatinserateActivity).apply {
                this.text = text
                textSize = 12f
                setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
                val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                p.topMargin = 12; p.bottomMargin = 4
                layoutParams = p
            })
        }
        fun field(text: String = ""): EditText {
            val et = EditText(this@PrivatinserateActivity).apply { setText(text); ThemeManager.styleDialogField(this@PrivatinserateActivity, this) }
            container.addView(et)
            return et
        }

        label("Name (Eigentümer/potenzieller Kunde)")
        val etName = field(item.name)
        label("Telefon")
        val etTelefon = field(item.telefon)
        label("E-Mail")
        val etEmail = field(item.email)
        label("Straße & Hausnr.")
        val etAdresse = field()
        val plzOrtRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val plzCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f) }
        val ortCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = 8 } }
        container.addView(TextView(this).apply { text = "PLZ / Ort"; textSize = 12f; setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint)); val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); p.topMargin = 12; p.bottomMargin = 4; layoutParams = p })
        val etPlz = EditText(this).apply { ThemeManager.styleDialogField(this@PrivatinserateActivity, this) }
        val etOrt = EditText(this).apply { setText(item.lage); ThemeManager.styleDialogField(this@PrivatinserateActivity, this) }
        plzCol.addView(etPlz); ortCol.addView(etOrt)
        plzOrtRow.addView(plzCol); plzOrtRow.addView(ortCol)
        container.addView(plzOrtRow)

        // Direkt bei der Übernahme schon eine Wiedervorlage und/oder ein
        // Shooting einstellen können, statt danach extra den neuen Kontakt
        // wieder öffnen zu müssen.
        var followUpAt: Long? = null
        var shootingAt: Long? = null
        label("Weiteres Vorgehen (optional)")
        val followUpBtn = TextView(this).apply {
            text = "🔔 Wiedervorlage setzen"
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            setBackgroundResource(R.drawable.bg_paper_pill)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        val shootingBtn = TextView(this).apply {
            text = "📸 Shooting setzen"
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            setBackgroundResource(R.drawable.bg_paper_pill)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        fun pickDateTimeInto(target: TextView, prefix: String, onPicked: (Long) -> Unit) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1) }
            DatePickerDialog(this, { _, y, m, d ->
                TimePickerDialog(this, { _, h, min ->
                    cal.set(y, m, d, h, min, 0)
                    onPicked(cal.timeInMillis)
                    target.text = "$prefix ${SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(cal.time)} ✓"
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        followUpBtn.setOnClickListener { pickDateTimeInto(followUpBtn, "🔔") { followUpAt = it } }
        shootingBtn.setOnClickListener { pickDateTimeInto(shootingBtn, "📸") { shootingAt = it } }
        container.addView(followUpBtn)
        container.addView(shootingBtn)

        AlertDialog.Builder(this)
            .setTitle("Als kontaktiert markieren")
            .setMessage("Daten übernehmen und daraus einen neuen potenziellen Kunden anlegen?")
            .setView(container)
            .setPositiveButton("Kontakt anlegen") { _, _ ->
                val name = etName.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, "Bitte einen Namen eintragen.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val notiz = listOfNotNull(
                    item.objekt.takeIf { it.isNotBlank() }?.let { "Objekt: $it" },
                    "Quelle: Privatinserat" + (item.eingestelltAt?.let { " vom ${dateFmt.format(it)}" } ?: "")
                ).joinToString("\n")
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        val dao = AppDatabase.getInstance(applicationContext).customerDao()
                        val phone = etTelefon.text.toString().trim()
                        val newId = dao.insertCustomer(
                            de.immokarte.anrufkarte.data.CustomerEntity(
                                name = name, phone = phone, phoneNormalized = de.immokarte.anrufkarte.data.PhoneUtils.normalize(phone),
                                email = etEmail.text.toString().trim(), status = "potenziell", notes = notiz,
                                followUpAt = followUpAt, shootingAt = shootingAt
                            )
                        )
                        val adresse = etAdresse.text.toString().trim()
                        val plz = etPlz.text.toString().trim()
                        val ort = etOrt.text.toString().trim()
                        if (adresse.isNotBlank() || ort.isNotBlank()) {
                            dao.insertProperties(listOf(
                                de.immokarte.anrufkarte.data.PropertyEntity(
                                    customerId = newId, typ = "Haus", adresse = adresse, ort = ort, plz = plz,
                                    preis = item.preis.filter { it.isDigit() }, status = "interessiert"
                                )
                            ))
                        }
                        // Kalender nachziehen: Wiedervorlagen laufen gesammelt
                        // pro Tag, Shooting bekommt einen eigenen Termin.
                        followUpAt?.let { de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
                        shootingAt?.let { at ->
                            val eventId = CalendarSync.syncEvent(applicationContext, null, "Shooting: $name", "Anruf-Karte — $phone", at, at + 60 * 60 * 1000L, colorOverride = CalendarSync.COLOR_SHOOTING_RED)
                            dao.setShootingEventId(newId, eventId)
                        }
                        AppDatabase.getInstance(applicationContext).privatinseratDao().setKontaktiert(item.id, true)
                    }
                    Toast.makeText(this@PrivatinserateActivity, "Neuer potenzieller Kunde \"$name\" angelegt.", Toast.LENGTH_SHORT).show()
                    loadList()
                }
            }
            .setNeutralButton("Nur markieren") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().setKontaktiert(item.id, true) }
                    loadList()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    /** Setzt/ändert eine Kalender-Erinnerung "Privatinserat kontaktieren" —
     *  landet als echter Termin im Gerätekalender, mit allen Eckdaten in der
     *  Beschreibung. */
    private fun pickReminder(item: PrivatinseratEntity) {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0) }
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                cal.set(y, m, d, h, min, 0)
                val beschreibung = listOfNotNull(
                    item.name.takeIf { it.isNotBlank() }?.let { "Name: $it" },
                    item.objekt.takeIf { it.isNotBlank() }?.let { "Objekt: $it" },
                    item.preis.takeIf { it.isNotBlank() }?.let { "Preis: $it" },
                    item.telefon.takeIf { it.isNotBlank() }?.let { "Telefon: $it" },
                    item.email.takeIf { it.isNotBlank() }?.let { "E-Mail: $it" }
                ).joinToString("\n")
                lifecycleScope.launch {
                    val eventId = withContext(Dispatchers.IO) {
                        CalendarSync.syncEvent(
                            applicationContext, item.erinnerungEventId, "Privatinserat kontaktieren: ${item.lage.ifBlank { item.name.ifBlank { "?" } }}",
                            beschreibung, cal.timeInMillis, cal.timeInMillis + 30 * 60 * 1000L
                        )
                    }
                    withContext(Dispatchers.IO) { AppDatabase.getInstance(applicationContext).privatinseratDao().setErinnerung(item.id, cal.timeInMillis, eventId) }
                    loadList()
                }
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---- kleine UI-Bausteine ----
    private fun sectionHeader(container: LinearLayout, text: String) {
        container.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 24
            layoutParams = p
        })
    }

    private fun hint(container: LinearLayout, text: String) {
        container.addView(TextView(this).apply {
            this.text = text
            textSize = 11.5f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 2
            layoutParams = p
        })
    }

    private fun fieldInput(container: LinearLayout, label: String): EditText {
        container.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 12; p.bottomMargin = 4
            layoutParams = p
        })
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT; ThemeManager.styleDialogField(this@PrivatinserateActivity, this) }
        container.addView(et)
        return et
    }

    private fun primaryButton(container: LinearLayout, text: String, onClick: () -> Unit) {
        container.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundResource(R.drawable.bg_navy_pill)
            setPadding(20, 26, 20, 26)
            isClickable = true; isFocusable = true
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 16
            layoutParams = p
            setOnClickListener { onClick() }
        })
    }

    private fun actionButton(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
        setBackgroundResource(R.drawable.bg_paper_pill)
        setPadding(16, 14, 16, 14)
        val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        p.marginEnd = 6
        layoutParams = p
        setOnClickListener { onClick() }
    }

    private fun kv(label: String, value: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 11.5f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(this).apply {
            text = value
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
        })
        return row
    }

    /** Telefon-Zeile mit direktem 📞-Button — Wähler öffnet sich sofort mit
     *  der Nummer, ohne extra in die Kontakte wechseln zu müssen. */
    private fun kvCall(telefon: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        row.addView(TextView(this).apply {
            text = "Telefon"
            textSize = 11.5f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(this).apply {
            text = telefon
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
        })
        row.addView(TextView(this).apply {
            text = "📞"
            textSize = 15f
            setPadding(16, 0, 0, 0)
            setOnClickListener {
                startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$telefon")))
            }
        })
        return row
    }

    /** E-Mail-Zeile mit 📋-Button — kopiert die Adresse in die
     *  Zwischenablage, statt gleich einen Mail-Client zu öffnen. */
    private fun kvCopyEmail(email: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.topMargin = 8
            layoutParams = p
        }
        row.addView(TextView(this).apply {
            text = "E-Mail"
            textSize = 11.5f
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInkFaint))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(this).apply {
            text = email
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ThemeManager.resolveColor(this@PrivatinserateActivity, R.attr.colorInk))
        })
        row.addView(TextView(this).apply {
            text = "📋"
            textSize = 15f
            setPadding(16, 0, 0, 0)
            setOnClickListener {
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("E-Mail", email))
                Toast.makeText(this@PrivatinserateActivity, "E-Mail kopiert.", Toast.LENGTH_SHORT).show()
            }
        })
        return row
    }

    /** Öffnet ein zentriertes Fenster mit allen Details zum Inserat — per
     *  Antippen der Karte selbst (die Aktions-Buttons unten reagieren
     *  weiterhin unabhängig davon auf ihre eigenen Klicks). */
    private fun showDetailDialog(item: PrivatinseratEntity) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 10)
        }
        if (item.objekt.isNotBlank()) container.addView(kv("Objekt", item.objekt))
        if (item.preis.isNotBlank()) container.addView(kv("Preis", item.preis))
        if (item.lage.isNotBlank()) container.addView(kv("Lage", item.lage))
        if (item.telefon.isNotBlank()) container.addView(kvCall(item.telefon))
        if (item.email.isNotBlank()) container.addView(kvCopyEmail(item.email))
        container.addView(kv("Eingestellt am", item.eingestelltAt?.let { dateFmt.format(it) } ?: "unbekannt"))
        if (item.privatStatus.isNotBlank()) {
            container.addView(kv("Privat", if (item.privatStatus == "eindeutig") "🟢 Eindeutig" else "🟡 Unklar"))
        }
        if (item.erinnerungAt != null) {
            container.addView(kv("Erinnerung", SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.GERMANY).format(item.erinnerungAt)))
        }
        AlertDialog.Builder(this)
            .setTitle(item.name.ifBlank { "Privatinserat" })
            .setView(container)
            .setPositiveButton("Schließen", null)
            .show()
    }

    private fun divider(): android.view.View = android.view.View(this).apply {
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2)
        p.topMargin = 12; p.bottomMargin = 4
        layoutParams = p
        setBackgroundColor(0x14000000)
    }
}
