package de.immokarte.anrufkarte

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.StatusInfo
import de.immokarte.anrufkarte.data.WhatsAppTemplates
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Liste aller offenen Kontakte (nicht "Kauf abgeschlossen") mit gewählter
 * Vorlage ODER frei geschriebenem Text. WhatsApp erlaubt keinen echten
 * Massenversand per App — daher wird hier Kontakt für Kontakt einzeln der
 * vorausgefüllte Chat geöffnet, du bestätigst den Versand jeweils selbst.
 * Bereits geöffnete Kontakte werden mit einem Häkchen markiert.
 *
 * Nach Status filterbar (Chips) und sortierbar (Name / Status / zuletzt
 * kontaktiert) — praktisch, um z. B. nur "Interessent" anzuschreiben statt
 * alle offenen Kontakte auf einmal.
 */
class BulkGreetingActivity : AppCompatActivity() {

    private val greetingTemplates = listOf(
        "✏️ Eigener Text" to "",
        "🎄 Weihnachtsgruß" to "Hallo {name}, ich wünsche Ihnen und Ihren Liebsten ein frohes Weihnachtsfest und einen guten Rutsch ins neue Jahr!",
        "🎆 Neujahrsgruß" to "Hallo {name}, alles Gute für das neue Jahr! Falls sich bei Ihnen etwas in Sachen Immobilien tut, bin ich gerne für Sie da.",
        "☀️ Sommergruß" to "Hallo {name}, ich wünsche Ihnen einen schönen Sommer! Melden Sie sich gerne, falls es Neuigkeiten bei Ihnen gibt.",
    )
    private val sentIds = mutableSetOf<Long>()
    private var allCustomers: List<CustomerWithProperties> = emptyList()

    // Standardmäßig alle offenen (nicht abgeschlossenen) Status ausgewählt —
    // entspricht dem bisherigen Verhalten, jetzt aber einzeln abwählbar.
    private val selectedStatuses = mutableSetOf<String>().apply {
        addAll(StatusInfo.keys.filter { it !in StatusInfo.closedStatuses })
    }
    private val sortModes = listOf("name" to "⇅ Name A–Z", "status" to "⇅ Status", "recent" to "⇅ Zuletzt kontaktiert")
    private var sortModeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_bulk_greeting)

        val spinner = findViewById<android.widget.Spinner>(R.id.spinnerGreetingTemplate)
        val etMessage = findViewById<EditText>(R.id.etCustomMessage)
        val customTemplates = de.immokarte.anrufkarte.data.CustomTemplateStore.getAll(this)
        val allTemplates = greetingTemplates + customTemplates.map { "💾 ${it.name}" to it.text }
        spinner.adapter = de.immokarte.anrufkarte.data.ThemeManager.themedArrayAdapter(this, allTemplates.map { it.first })
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val template = allTemplates[position].second
                if (template.isNotBlank()) etMessage.setText(template)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        findViewById<android.widget.Button>(R.id.btnSortGreeting).setOnClickListener {
            sortModeIndex = (sortModeIndex + 1) % sortModes.size
            it as android.widget.Button
            it.text = sortModes[sortModeIndex].second
            renderList(etMessage)
        }
        findViewById<android.widget.Button>(R.id.btnSaveGreetingTemplate).setOnClickListener {
            val text = etMessage.text.toString()
            if (text.isBlank()) {
                android.widget.Toast.makeText(this, "Erst einen Text schreiben, dann speichern.", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val nameInput = EditText(this).apply { hint = "z. B. Sommergruß eigen"; de.immokarte.anrufkarte.data.ThemeManager.styleDialogField(this@BulkGreetingActivity, this) }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Als Vorlage speichern")
                .setView(nameInput)
                .setPositiveButton("Speichern") { _, _ ->
                    val name = nameInput.text.toString().trim()
                    if (name.isNotBlank()) {
                        de.immokarte.anrufkarte.data.CustomTemplateStore.save(this, name, text)
                        android.widget.Toast.makeText(this, "Vorlage „$name“ gespeichert.", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Abbrechen", null)
                .show()
        }

        setupStatusFilterChips(etMessage)

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            allCustomers = withContext(Dispatchers.IO) { dao.getAllWithProperties() }
            renderList(etMessage)
        }
    }

    private fun setupStatusFilterChips(etMessage: EditText) {
        val container = findViewById<LinearLayout>(R.id.statusFilterContainer)
        container.removeAllViews()
        StatusInfo.options.forEach { option ->
            val chip = TextView(this).apply {
                text = option.label
                textSize = 11.5f
                setPadding(24, 14, 24, 14)
                val isOn = selectedStatuses.contains(option.key)
                setTextColor(if (isOn) 0xFFFFFFFF.toInt() else de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, R.attr.colorInkFaint))
                setBackgroundResource(if (isOn) R.drawable.bg_navy_pill else R.drawable.bg_card)
                setOnClickListener {
                    if (selectedStatuses.contains(option.key)) selectedStatuses.remove(option.key) else selectedStatuses.add(option.key)
                    setupStatusFilterChips(etMessage) // Chip-Farben neu setzen
                    renderList(etMessage)
                }
            }
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.marginEnd = 8
            container.addView(chip, params)
        }
    }

    private fun renderList(etMessage: EditText) {
        val container = findViewById<LinearLayout>(R.id.greetingContainer)
        val tvCount = findViewById<TextView>(R.id.tvGreetingCount)
        container.removeAllViews()

        var filtered = allCustomers.filter { it.customer.status in selectedStatuses }
        filtered = when (sortModes[sortModeIndex].first) {
            "status" -> {
                val order = StatusInfo.keys.withIndex().associate { (i, k) -> k to i }
                filtered.sortedBy { order[it.customer.status] ?: 99 }
            }
            "recent" -> filtered.sortedByDescending { it.customer.lastContactAt ?: 0L }
            else -> filtered.sortedBy { it.customer.name.lowercase() }
        }

        tvCount.text = "${filtered.size} Kontakt${if (filtered.size == 1) "" else "e"}"

        if (filtered.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Keine Kontakte mit den gewählten Status-Filtern."
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, R.attr.colorInkFaint))
            })
            return
        }

        filtered.forEach { c ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
                setBackgroundResource(R.drawable.bg_card)
                gravity = android.view.Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = 8
                layoutParams = params
            }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(this).apply {
                text = c.customer.name
                textSize = 14f
                setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, R.attr.colorInk))
            })
            textCol.addView(TextView(this).apply {
                text = StatusInfo.label(c.customer.status)
                textSize = 10.5f
                setTextColor(StatusInfo.color(c.customer.status))
            })
            val tvStatus = TextView(this).apply {
                text = if (sentIds.contains(c.customer.id)) "✓ Geöffnet" else "WhatsApp öffnen"
                textSize = 12f
                setTextColor(if (sentIds.contains(c.customer.id)) de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, R.attr.colorSuccess) else de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, android.R.attr.colorPrimary))
            }
            row.addView(textCol)
            row.addView(tvStatus)
            row.setOnClickListener {
                val messageText = etMessage.text.toString()
                if (messageText.isBlank()) {
                    android.widget.Toast.makeText(this, "Bitte zuerst eine Nachricht schreiben oder Vorlage wählen.", android.widget.Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val digits = c.customer.phone.filter { it.isDigit() }
                val link = WhatsAppTemplates.buildLink(digits, c.customer.name, messageText)
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                }
                sentIds += c.customer.id
                tvStatus.text = "✓ Geöffnet"
                tvStatus.setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@BulkGreetingActivity, R.attr.colorSuccess))
            }
            container.addView(row)
        }
    }
}
