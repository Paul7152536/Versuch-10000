package de.immokarte.anrufkarte

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.immokarte.anrufkarte.data.AppDatabase
import de.immokarte.anrufkarte.data.CustomerDao
import de.immokarte.anrufkarte.data.CustomerWithProperties
import de.immokarte.anrufkarte.data.FollowUpDayCalendarSync
import de.immokarte.anrufkarte.widget.FollowUpWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Führt Wiedervorlagen, Shootings, Besichtigungen, Notar-/Mietvertrags-
 * Termine und Jahrestage aus
 * allen Kontakten chronologisch zusammen — bisher waren diese nur getrennt
 * je Kontakt sichtbar. Zeigt überfällige Einträge sowie die kommenden
 * 30 Tage, gruppiert nach Tag.
 *
 * Jeder Tag startet eingeklappt und zeigt nur "Tag — n Termine" — antippen
 * klappt die einzelnen Einträge auf, nochmal antippen klappt wieder zu.
 * Verhindert, dass die Liste bei vielen Terminen unübersichtlich wird.
 *
 * Überfällige Einträge lassen sich per Haken als "bestätigt" markieren —
 * sie verschwinden dann aus der Übersicht, statt dauerhaft als überfällig
 * angezeigt zu werden. Wiedervorlagen lassen sich zusätzlich per Checkbox
 * mehrfach auswählen und gesammelt auf den jeweils folgenden Tag verschieben.
 */
class WeekPlanActivity : AppCompatActivity() {

    private data class PlanEntry(val date: Long, val typeLabel: String, val icon: String, val customer: CustomerWithProperties)

    private val selectedFollowUps = mutableSetOf<PlanEntry>()
    private lateinit var bulkMoveBar: LinearLayout
    private lateinit var tvBulkMoveLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        de.immokarte.anrufkarte.data.ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_week_plan)

        val container = findViewById<LinearLayout>(R.id.planContainer)
        bulkMoveBar = findViewById(R.id.bulkMoveBar)
        tvBulkMoveLabel = findViewById(R.id.tvBulkMoveLabel)
        findViewById<View>(R.id.btnBulkMoveTomorrow).setOnClickListener { moveSelectedFollowUpsToNextDay() }

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            val allCustomers = withContext(Dispatchers.IO) { dao.getAllWithProperties() }

            val now = System.currentTimeMillis()
            val startWindow = now - 3L * 24 * 60 * 60 * 1000
            val endWindow = now + 30L * 24 * 60 * 60 * 1000

            val entries = mutableListOf<PlanEntry>()
            allCustomers.forEach { c ->
                val cu = c.customer
                // Bestätigte Termine, deren Datum bereits verstrichen ist, tauchen
                // gar nicht erst auf — das ist der Zweck der Bestätigung.
                fun keep(at: Long?, confirmed: Boolean) = at != null && at in startWindow..endWindow && !(at < now && confirmed)
                if (keep(cu.followUpAt, cu.followUpConfirmed)) entries += PlanEntry(cu.followUpAt!!, "Wiedervorlage", "🔔", c)
                if (keep(cu.shootingAt, cu.shootingConfirmed)) entries += PlanEntry(cu.shootingAt!!, "Shooting", "📸", c)
                if (keep(cu.viewingAt, cu.viewingConfirmed)) entries += PlanEntry(cu.viewingAt!!, "Besichtigung", "🏠", c)
                if (keep(cu.contractDateAt, cu.contractConfirmed)) entries += PlanEntry(cu.contractDateAt!!, "Notar/Mietvertrag", "📝", c)
                if (keep(cu.anniversaryAt, cu.anniversaryConfirmed)) entries += PlanEntry(cu.anniversaryAt!!, "Jahrestag", "🎂", c)
            }
            entries.sortBy { it.date }

            if (entries.isEmpty()) {
                container.addView(TextView(this@WeekPlanActivity).apply {
                    text = "Keine Termine in den nächsten 30 Tagen."
                    setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInkFaint))
                    setPadding(0, 20, 0, 0)
                })
                return@launch
            }

            // Nach Tag gruppieren, Reihenfolge bleibt chronologisch (entries ist bereits sortiert)
            val grouped = LinkedHashMap<String, MutableList<PlanEntry>>()
            entries.forEach { grouped.getOrPut(dayLabel(it.date)) { mutableListOf() }.add(it) }

            grouped.forEach { (label, list) ->
                val isOverdue = label == "Überfällig"
                val headerRow = LinearLayout(this@WeekPlanActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(18, 16, 18, 16)
                    setBackgroundResource(R.drawable.bg_card)
                    isClickable = true
                    isFocusable = true
                    val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    params.topMargin = 14
                    layoutParams = params
                }
                val tvLabel = TextView(this@WeekPlanActivity).apply {
                    text = label
                    textSize = 13.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isOverdue) de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorBrick) else de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInk))
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvCount = TextView(this@WeekPlanActivity).apply {
                    text = "${list.size} Termin${if (list.size == 1) "" else "e"}"
                    textSize = 11.5f
                    setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInkFaint))
                }
                val tvChevron = TextView(this@WeekPlanActivity).apply {
                    text = "▸"
                    textSize = 13f
                    setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInkFaint))
                    setPadding(10, 0, 0, 0)
                }
                headerRow.addView(tvLabel)
                headerRow.addView(tvCount)
                headerRow.addView(tvChevron)
                container.addView(headerRow)

                val detailContainer = LinearLayout(this@WeekPlanActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                    setPadding(0, 8, 0, 0)
                }

                // Entfernt einen Eintrag nach dem Bestätigen aus dieser Gruppe —
                // verschwindet die Gruppe dabei komplett, wird auch ihr Header entfernt.
                fun removeEntry(entry: PlanEntry, card: View) {
                    list.remove(entry)
                    selectedFollowUps.remove(entry)
                    updateBulkBar()
                    detailContainer.removeView(card)
                    tvCount.text = "${list.size} Termin${if (list.size == 1) "" else "e"}"
                    if (list.isEmpty()) {
                        container.removeView(headerRow)
                        container.removeView(detailContainer)
                    }
                }

                list.forEach { entry ->
                    detailContainer.addView(buildEntryCard(entry, isOverdue) { e, card ->
                        lifecycleScope.launch {
                            val dao = AppDatabase.getInstance(applicationContext).customerDao()
                            withContext(Dispatchers.IO) { markConfirmed(dao, e) }
                            removeEntry(e, card)
                        }
                    })
                }
                container.addView(detailContainer)

                headerRow.setOnClickListener {
                    val expand = detailContainer.visibility != View.VISIBLE
                    detailContainer.visibility = if (expand) View.VISIBLE else View.GONE
                    tvChevron.text = if (expand) "▾" else "▸"
                }
            }
        }
    }

    /** Ordnet den Bestätigen-Klick der richtigen Spalte in der Datenbank zu. */
    private suspend fun markConfirmed(dao: CustomerDao, entry: PlanEntry) {
        val id = entry.customer.customer.id
        when (entry.typeLabel) {
            "Wiedervorlage" -> dao.setFollowUpConfirmed(id, true)
            "Shooting" -> dao.setShootingConfirmed(id, true)
            "Besichtigung" -> dao.setViewingConfirmed(id, true)
            "Notar/Mietvertrag" -> dao.setContractConfirmed(id, true)
            "Jahrestag" -> dao.setAnniversaryConfirmed(id, true)
        }
    }

    private fun updateBulkBar() {
        val n = selectedFollowUps.size
        if (n == 0) {
            bulkMoveBar.visibility = View.GONE
        } else {
            bulkMoveBar.visibility = View.VISIBLE
            tvBulkMoveLabel.text = "$n Wiedervorlage${if (n == 1) "" else "n"} ausgewählt"
        }
    }

    /** Verschiebt alle ausgewählten Wiedervorlagen um genau einen Tag nach
     *  hinten (gleiche Uhrzeit bleibt erhalten) und baut die gemeinsamen
     *  Tages-Kalendertermine für die betroffenen Tage neu auf. */
    private fun moveSelectedFollowUpsToNextDay() {
        if (selectedFollowUps.isEmpty()) return
        val toMove = selectedFollowUps.toList()
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).customerDao()
            withContext(Dispatchers.IO) {
                val affectedDays = mutableSetOf<Long>()
                toMove.forEach { entry ->
                    affectedDays += entry.date
                    val newDate = Calendar.getInstance().apply { timeInMillis = entry.date; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
                    dao.setFollowUp(entry.customer.customer.id, newDate)
                    affectedDays += newDate
                }
                affectedDays.forEach { FollowUpDayCalendarSync.resyncDay(applicationContext, dao, it) }
            }
            FollowUpWidgetProvider.updateAll(applicationContext)
            Toast.makeText(this@WeekPlanActivity, "${toMove.size} Wiedervorlage${if (toMove.size == 1) "" else "n"} auf morgen verschoben.", Toast.LENGTH_SHORT).show()
            selectedFollowUps.clear()
            updateBulkBar()
            // Einfachster zuverlässiger Weg, die verschobenen Einträge aus ihren
            // alten Tages-Gruppen zu entfernen und in den neuen einsortiert
            // wieder anzuzeigen: den Bildschirm neu aufbauen.
            recreate()
        }
    }

    private fun buildEntryCard(entry: PlanEntry, isOverdue: Boolean, onConfirm: (PlanEntry, LinearLayout) -> Unit): LinearLayout {
        val hasTime = entry.typeLabel == "Besichtigung" || entry.typeLabel == "Shooting" || entry.typeLabel == "Wiedervorlage"
        val timeFmt = if (hasTime) SimpleDateFormat("HH:mm", Locale.GERMANY) else SimpleDateFormat("dd.MM.", Locale.GERMANY)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundResource(R.drawable.bg_card)
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = 6
            layoutParams = params
            setOnClickListener {
                startActivity(Intent(this@WeekPlanActivity, CustomerEditActivity::class.java).putExtra(CustomerEditActivity.EXTRA_CUSTOMER_ID, entry.customer.customer.id))
            }
        }

        // Mehrfachauswahl nur bei Wiedervorlagen — zum gesammelten Verschieben.
        if (entry.typeLabel == "Wiedervorlage") {
            card.addView(CheckBox(this).apply {
                isChecked = entry in selectedFollowUps
                setPadding(0, 0, 10, 0)
                setOnClickListener {
                    if (isChecked) selectedFollowUps.add(entry) else selectedFollowUps.remove(entry)
                    updateBulkBar()
                }
            })
        }

        card.addView(TextView(this).apply {
            text = entry.icon
            textSize = 17f
            setPadding(0, 0, 14, 0)
        })
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textCol.addView(TextView(this).apply {
            text = entry.customer.customer.name
            textSize = 13.5f
            setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInk))
            setTypeface(typeface, Typeface.BOLD)
        })
        textCol.addView(TextView(this).apply {
            text = entry.typeLabel
            textSize = 11f
            setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInkFaint))
        })
        card.addView(textCol)
        card.addView(TextView(this).apply {
            text = timeFmt.format(Date(entry.date))
            textSize = 12.5f
            setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorInk))
            setTypeface(typeface, Typeface.BOLD)
        })

        // Bestätigen-Haken jetzt bei JEDEM Eintrag (nicht mehr nur bei
        // überfälligen) — markiert den Termin als erledigt/bestätigt.
        card.addView(TextView(this).apply {
            text = "✓"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(de.immokarte.anrufkarte.data.ThemeManager.resolveColor(this@WeekPlanActivity, R.attr.colorSuccess))
            setPadding(16, 6, 6, 6)
            setOnClickListener { onConfirm(entry, card) }
        })

        // Verschieben — bei jeder Termin-Art, nicht nur bei Wiedervorlagen
        // (die haben zusätzlich die Mehrfachauswahl oben für den Sammel-Move).
        card.addView(TextView(this).apply {
            text = "📅"
            textSize = 16f
            setPadding(10, 6, 6, 6)
            setOnClickListener { pickNewDateFor(entry) }
        })

        // Termin ganz entfernen (Datum löschen) — mit Rückfrage, damit nichts
        // aus Versehen verschwindet.
        card.addView(TextView(this).apply {
            text = "🗑"
            textSize = 15f
            setPadding(10, 6, 4, 6)
            setOnClickListener { confirmDelete(entry) }
        })

        card.addView(TextView(this).apply {
            text = "📞"
            textSize = 16f
            setPadding(16, 6, 6, 6)
            setOnClickListener {
                val phone = entry.customer.customer.phone
                de.immokarte.anrufkarte.data.PhoneUtils.withChosenNumber(this@WeekPlanActivity, phone, entry.customer.customer.phone2) { chosen ->
                    startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$chosen")))
                }
            }
        })
        return card
    }

    /** Entfernt einen Termin vollständig (Datum wird geleert) — nach
     *  Rückfrage. Anders als das Abhaken verschwindet der Eintrag damit
     *  komplett, nicht nur aus der Fällig-Anzeige. */
    private fun confirmDelete(entry: PlanEntry) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("${entry.typeLabel} entfernen?")
            .setMessage("Der Termin bei ${entry.customer.customer.name} wird gelöscht. Der Kontakt selbst bleibt erhalten.")
            .setPositiveButton("Entfernen") { _, _ ->
                val id = entry.customer.customer.id
                val cu = entry.customer.customer
                val altesDatum = entry.date
                lifecycleScope.launch {
                    val dao = AppDatabase.getInstance(applicationContext).customerDao()
                    withContext(Dispatchers.IO) {
                        when (entry.typeLabel) {
                            "Wiedervorlage" -> {
                                dao.clearFollowUp(id)
                                // Wiedervorlagen laufen als gemeinsamer Tages-Termin:
                                // den Tag neu aufbauen, dann verschwindet der Eintrag
                                // dort (bzw. der ganze Termin, wenn er leer wird).
                                de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, altesDatum)
                            }
                            "Shooting" -> {
                                cu.shootingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                                dao.setShootingEventId(id, null)
                                dao.clearShooting(id)
                            }
                            "Besichtigung" -> {
                                cu.viewingEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                                dao.setViewingEventId(id, null)
                                dao.clearViewing(id)
                            }
                            "Notar/Mietvertrag" -> {
                                cu.contractEventId?.let { de.immokarte.anrufkarte.data.CalendarSync.deleteEvent(applicationContext, it) }
                                dao.setContractEventId(id, null)
                                dao.clearContract(id)
                            }
                            "Jahrestag" -> dao.clearAnniversary(id)
                        }
                    }
                    de.immokarte.anrufkarte.widget.FollowUpWidgetProvider.updateAll(applicationContext)
                    recreate()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    /** Verschiebt einen einzelnen Termin (egal welcher Art) auf ein neues
     *  Datum/Uhrzeit — setzt dabei automatisch den "bestätigt"-Status
     *  zurück, da es ja ein neuer Termin ist. */
    private fun pickNewDateFor(entry: PlanEntry) {
        val cal = Calendar.getInstance().apply { timeInMillis = entry.date }
        android.app.DatePickerDialog(this, { _, y, m, d ->
            android.app.TimePickerDialog(this, { _, h, min ->
                cal.set(y, m, d, h, min, 0)
                val id = entry.customer.customer.id
                val cu = entry.customer.customer
                val neuesDatum = cal.timeInMillis
                val altesDatum = entry.date
                val ersteAdresse = entry.customer.properties.firstOrNull()
                    ?.let { listOf(it.adresse, it.ort).filter { t -> t.isNotBlank() }.joinToString(", ") }
                    ?.takeIf { it.isNotBlank() }
                fun titel(basis: String) = basis + (ersteAdresse?.let { " — $it" } ?: "")
                val beschreibung = (ersteAdresse?.let { "📍 $it\n\n" } ?: "") + "Anruf-Karte — ${cu.phone}"

                lifecycleScope.launch {
                    val dao = AppDatabase.getInstance(applicationContext).customerDao()
                    withContext(Dispatchers.IO) {
                        // Datum in der App setzen UND den Kalendereintrag mitziehen,
                        // sonst bliebe der alte Termin im Kalender stehen.
                        when (entry.typeLabel) {
                            "Wiedervorlage" -> {
                                dao.setFollowUp(id, neuesDatum)
                                // Beide betroffenen Tage neu aufbauen (alter + neuer)
                                de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, altesDatum)
                                de.immokarte.anrufkarte.data.FollowUpDayCalendarSync.resyncDay(applicationContext, dao, neuesDatum)
                            }
                            "Shooting" -> {
                                dao.setShootingAt(id, neuesDatum)
                                val neueId = de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                                    applicationContext, cu.shootingEventId, titel("Shooting: ${cu.name}"), beschreibung,
                                    neuesDatum, neuesDatum + 60 * 60 * 1000L,
                                    location = ersteAdresse,
                                    colorOverride = de.immokarte.anrufkarte.data.CalendarSync.COLOR_SHOOTING_RED
                                )
                                dao.setShootingEventId(id, neueId)
                            }
                            "Besichtigung" -> {
                                dao.setViewingAt(id, neuesDatum)
                                val neueId = de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                                    applicationContext, cu.viewingEventId, titel("Besichtigung: ${cu.name}"), beschreibung,
                                    neuesDatum, neuesDatum + 45 * 60 * 1000L,
                                    location = ersteAdresse,
                                    colorOverride = de.immokarte.anrufkarte.data.CalendarSync.COLOR_VIEWING_GRAY
                                )
                                dao.setViewingEventId(id, neueId)
                            }
                            "Notar/Mietvertrag" -> {
                                dao.setContractDateAt(id, neuesDatum)
                                val neueId = de.immokarte.anrufkarte.data.CalendarSync.syncEvent(
                                    applicationContext, cu.contractEventId, titel("Notar/Mietvertrag: ${cu.name}"), beschreibung,
                                    neuesDatum, neuesDatum + 60 * 60 * 1000L,
                                    location = ersteAdresse
                                )
                                dao.setContractEventId(id, neueId)
                            }
                            "Jahrestag" -> dao.setAnniversaryAt(id, neuesDatum)
                        }
                    }
                    de.immokarte.anrufkarte.widget.FollowUpWidgetProvider.updateAll(applicationContext)
                    recreate()
                }
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun dayLabel(date: Long): String {
        val target = Calendar.getInstance().apply { timeInMillis = date }
        val today = Calendar.getInstance()
        val targetDay = target.get(Calendar.YEAR) * 1000 + target.get(Calendar.DAY_OF_YEAR)
        val todayDay = today.get(Calendar.YEAR) * 1000 + today.get(Calendar.DAY_OF_YEAR)
        val diff = targetDay - todayDay
        return when {
            diff < 0 -> "Überfällig"
            diff == 0 -> "Heute"
            diff == 1 -> "Morgen"
            else -> SimpleDateFormat("EEEE, dd.MM.", Locale.GERMANY).format(Date(date))
        }
    }
}
