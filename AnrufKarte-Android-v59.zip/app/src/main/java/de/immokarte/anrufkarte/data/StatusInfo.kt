package de.immokarte.anrufkarte.data

data class StatusOption(val key: String, val label: String)

/** Zentrale, einzige Quelle für die Status-Liste — wird von der Kundenliste,
 *  dem Bearbeiten-Bildschirm, der Anruf-Karte und der Statistik-Seite
 *  gemeinsam genutzt, damit sie garantiert nie auseinanderlaufen. */
object StatusInfo {
    // Bewusst auf drei Stufen reduziert (vorher acht) — entlang des
    // Verkaufsverlaufs: erster Kontakt -> Interessent -> Kunde.
    val options = listOf(
        StatusOption("potenziell", "Potenzieller Kunde"),
        StatusOption("interessent", "Interessent"),
        StatusOption("kunde", "Kunde"),
    )

    val keys: List<String> = options.map { it.key }
    val labels: List<String> = options.map { it.label }
    private val labelByKey: Map<String, String> = options.associate { it.key to it.label }

    /**
     * Ordnet frühere, nicht mehr verwendete Status der passenden neuen Stufe
     * zu. Wichtig für bestehende Kontakte und für das Einspielen älterer
     * Sicherungen — sonst hätten die einen Status, den es nicht mehr gibt,
     * und würden in Listen/Filtern durchfallen.
     */
    fun normalize(key: String): String = when (key) {
        "potenziell", "interessent", "kunde" -> key
        // War schon im Gespräch/Prozess -> Interessent
        "besichtigung", "angebot", "pendent" -> "interessent"
        // Abschluss erfolgt -> Kunde
        "abschluss" -> "kunde"
        // Abgelehnt: bleibt als Kontakt erhalten, aber ganz am Anfang der Stufe
        "abgelehnt" -> "potenziell"
        else -> "potenziell"
    }

    /** Sortier-Rang je Status (Reihenfolge wie oben). Wird für die Sortierung
     *  der Kontaktliste genutzt. */
    private val sortRank: Map<String, Int> = options.withIndex().associate { (i, o) -> o.key to i }
    fun sortIndex(key: String): Int = sortRank[normalize(key)] ?: options.size

    /** Status, bei denen der Kontakt nicht mehr aktiv "in Bearbeitung" ist —
     *  wird für Filter/Vorschläge genutzt, die nur offene Fälle zeigen sollen. */
    val closedStatuses = setOf("kunde")

    fun label(key: String): String = labelByKey[normalize(key)] ?: key

    /** Eine Farbe je Status — für die kleinen Farbpunkte in der Kontaktliste,
     *  auf einen Blick erfassbar statt den Text lesen zu müssen. */
    fun color(key: String): Int = when (normalize(key)) {
        "potenziell" -> 0xFF5DCAA5.toInt()   // Türkis — noch ganz am Anfang
        "interessent" -> 0xFFEF9F27.toInt()  // Orange — im Gespräch
        "kunde" -> 0xFF97C459.toInt()        // Grün — schon Kunde
        else -> 0xFF8A8A8A.toInt()
    }
}
