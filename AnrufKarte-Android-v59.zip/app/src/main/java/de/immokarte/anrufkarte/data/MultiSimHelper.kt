package de.immokarte.anrufkarte.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

data class SimChoice(
    val subscriptionId: Int,
    val label: String,
    val slotIndex: Int,
    /** Rufnummer, falls sie sich auslesen ließ — sonst leer. */
    val number: String = "",
    /** Anbieter (z. B. "Telekom"), falls bekannt — sonst leer. */
    val carrier: String = ""
)

/** Liest die auf dem Gerät aktiven SIM-Karten/eSIMs aus, damit der Nutzer bei
 *  Mehr-SIM-Geräten (z. B. privat + dienstlich) eine davon als "die, bei der
 *  das Overlay erscheinen soll" auswählen kann. */
object MultiSimHelper {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasNumberPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_NUMBERS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Versucht die Rufnummer einer SIM über mehrere Wege zu ermitteln.
     *
     * Wichtig zu wissen: Ob das klappt, liegt NICHT an der App — die Nummer
     * ist nur dann auslesbar, wenn der Mobilfunkanbieter sie tatsächlich auf
     * der SIM hinterlegt hat. Gerade bei deutschen Anbietern ist das oft
     * nicht der Fall. Deshalb hier mehrere Quellen nacheinander, und wenn
     * keine davon etwas liefert, bleibt die Nummer eben leer (dann hilft der
     * selbst vergebene Name weiter).
     */
    private fun readNumber(context: Context, subscriptionId: Int, info: android.telephony.SubscriptionInfo?): String {
        if (!hasNumberPermission(context)) return ""

        // Weg 1: offizieller, neuester Weg (ab Android 13) — kann die Nummer
        // zusätzlich vom Anbieter-Profil beziehen, nicht nur von der SIM.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runCatching {
                val sm = context.getSystemService(SubscriptionManager::class.java)
                sm?.getPhoneNumber(subscriptionId)?.takeIf { it.isNotBlank() }?.let { return it }
            }
        }

        // Weg 2: direkt aus den SIM-Infos
        runCatching {
            @Suppress("DEPRECATION")
            info?.number?.takeIf { it.isNotBlank() }?.let { return it }
        }

        // Weg 3: klassischer Weg über die Telefonie-Schnittstelle
        runCatching {
            val tm = context.getSystemService(TelephonyManager::class.java)
                ?.createForSubscriptionId(subscriptionId)
            @Suppress("DEPRECATION")
            tm?.line1Number?.takeIf { it.isNotBlank() }?.let { return it }
        }

        return ""
    }

    /** Macht aus einer Rohnummer eine gut lesbare Anzeige (z. B. +4917612345678
     *  -> +49 176 12345678). Unbekannte Formate bleiben unverändert. */
    private fun prettyNumber(raw: String): String {
        val cleaned = raw.replace(" ", "").replace("-", "")
        return when {
            cleaned.startsWith("+49") && cleaned.length > 6 ->
                "+49 ${cleaned.substring(3, 6)} ${cleaned.substring(6)}"
            cleaned.startsWith("0") && cleaned.length > 4 ->
                "${cleaned.substring(0, 4)} ${cleaned.substring(4)}"
            else -> raw
        }
    }

    fun listSims(context: Context): List<SimChoice> {
        if (!hasPermission(context)) return emptyList()
        return runCatching {
            val sm = context.getSystemService(SubscriptionManager::class.java) ?: return@runCatching emptyList()
            val list = sm.activeSubscriptionInfoList ?: return@runCatching emptyList()
            list.map { info ->
                val carrier = info.carrierName?.toString()?.takeIf { it.isNotBlank() }.orEmpty()
                val displayName = info.displayName?.toString()?.takeIf { it.isNotBlank() }.orEmpty()
                val rawNumber = readNumber(context, info.subscriptionId, info)
                val number = if (rawNumber.isNotBlank()) prettyNumber(rawNumber) else ""

                // Beschriftung nach Nützlichkeit aufgebaut: Rufnummer ist am
                // hilfreichsten, dann Anbieter/Name, Steckplatz immer als
                // eindeutige Absicherung hintendran (zwei SIMs beim selben
                // Anbieter wären sonst nicht unterscheidbar).
                val basis = when {
                    number.isNotBlank() && carrier.isNotBlank() -> "$number ($carrier)"
                    number.isNotBlank() -> number
                    displayName.isNotBlank() -> displayName
                    carrier.isNotBlank() -> carrier
                    else -> "SIM"
                }
                SimChoice(
                    subscriptionId = info.subscriptionId,
                    label = "$basis — Steckplatz ${info.simSlotIndex + 1}",
                    slotIndex = info.simSlotIndex,
                    number = number,
                    carrier = carrier
                )
            }
        }.getOrDefault(emptyList())
    }
}
