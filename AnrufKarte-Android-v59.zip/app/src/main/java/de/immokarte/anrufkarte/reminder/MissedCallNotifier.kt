package de.immokarte.anrufkarte.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import de.immokarte.anrufkarte.MainActivity

/** Zeigt direkt nach einem verpassten/abgelehnten Anruf eine Benachrichtigung
 *  mit "Anrufen" und "In 1 Stunde erinnern" (Rückruf-Snooze). */
object MissedCallNotifier {

    private const val CHANNEL_ID = "missed_call"

    fun show(context: Context, name: String, phone: String) {
        createChannel(context)
        val notifId = phone.hashCode()

        val callIntent = PendingIntent.getActivity(
            context, notifId,
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, SnoozeReceiver::class.java).apply {
            putExtra(SnoozeReceiver.EXTRA_NAME, name)
            putExtra(SnoozeReceiver.EXTRA_PHONE, phone)
            putExtra(SnoozeReceiver.EXTRA_NOTIF_ID, notifId)
        }
        val snoozePending = PendingIntent.getBroadcast(
            context, notifId, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Ein Antippen trägt direkt eine Wiedervorlage für heute Nachmittag/
        // Abend (ab 17 Uhr) beim Kontakt ein — ohne extra in die App zu müssen.
        val wiedervorlageIntent = Intent(context, WiedervorlageHeuteReceiver::class.java).apply {
            putExtra(WiedervorlageHeuteReceiver.EXTRA_PHONE, phone)
            putExtra(WiedervorlageHeuteReceiver.EXTRA_NOTIF_ID, notifId)
        }
        val wiedervorlagePending = PendingIntent.getBroadcast(
            context, notifId + 1, wiedervorlageIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = PendingIntent.getActivity(
            context, notifId, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("Verpasster Anruf: $name")
            .setContentText(phone)
            .setSmallIcon(android.R.drawable.sym_call_missed)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.sym_action_call, "Anrufen", callIntent)
            .addAction(android.R.drawable.ic_popup_reminder, "Wiedervorlage heute", wiedervorlagePending)
            .addAction(android.R.drawable.ic_popup_reminder, "In 1 Std. erinnern", snoozePending)
            .build()

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notifId, notification)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Verpasste Anrufe", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
